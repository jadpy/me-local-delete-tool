function a()
   function b()
        local v = "test.lua"
        print(v)
    end
    b()
    local av = true
    print("test" .. av)
end
a()
local a = 10
print(a)