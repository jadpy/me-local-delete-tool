# lua-local-deleted-tool

Luaソースコードから指定した `local` キーワードを削除するツールです。  
元のコードのインデント・空行・コメントをできるだけ保持しながら処理します。  
`fom` による整形、`coml` による1行圧縮、`nmbun` による数式簡約、`rename` によるローカル変数名ランダム化、`deleteout` による高精度コメント削除、`nocode` による未使用ローカルコード削除、`lint` による静的解析、`rrequire` による依存解析、`preset` による段階実行に対応しています。`localnum` による数値代入の local 削除にも対応しています。全コマンドで実行前後の安全チェック（parse/compile/lint要約）を行い、`output/*.safety.json` を出力します。

内部仕様の詳細: `ARCHITECTURE.md`

## 🎯 主な用途

- **関数宣言の `local` 削除**: `local function foo()` → `function foo()`
- **代入式の `local` 削除**: 特定の型の代入のみをターゲット
  - テーブル: `local a = {}` → `a = {}`
  - 文字列: `local s = "text"` → `s = "text"`
  - ブール値: `local b = true` → `b = true`
  - 数値: `local n = 123` → `n = 123`
- **コメントアウトコードの削除**: `--[[ ... ]]` 内のコード行を検出・削除
- **高精度コメント削除**: `deleteout` で `--` / `--[[...]]` を安全に削除
- **コード整形**: `fom` でインデントを整形（Luau / Lua 5.1 対応）
- **1行圧縮**: `coml` で1行に圧縮（定数畳み込み・不要コード削除・安全検証つき）
- **数式簡約**: `nmbun` で計算可能な式を答えへ簡約
- **変数名ランダム化**: `rename` でローカル変数/引数/for変数を参照含めて短名に変換
- **未使用コード削除**: `nocode` で未使用ローカル宣言/ローカル関数を削除
- **静的解析**: `lint` で未使用変数・未定義参照・型不一致ヒント・不要式を検出
- **依存解析**: `rrequire` で `require(...)` 関係を追跡しグラフ化
- **段階実行**: `preset` で JSON 定義した複数コマンドを順番実行
- **安全レポート**: 全コマンドで `output/<file>.safety.json` を生成（before/after比較、フォールバック有無）
- **local削除の高精度化**: ASTベースで関数/グローバル判定を実施し、誤削除を抑制

---

## 🚀 クイックスタート

### インストール

Lua 5.4 が必要です。以下のコマンドで実行可能です：

```bash
# 基本的な使用方法
lua54 main.lua <コマンド> [スコープ] <入力ファイル>
```

### 出力

入力ファイル: `test.lua`  
出力ファイル: `output/test.lua`

---

## 📋 コマンド一覧表

| コマンド | スコープ | 対象 | 例 |
|---------|---------|------|-----|
| `functionlocal` | ✅ | 関数宣言 | `lua54 main.lua functionlocal test.lua` |
| `localkw` | ✅ | すべての local | `lua54 main.lua localkw global test.lua` |
| `localtabke` | ✅ | テーブル初期化 | `lua54 main.lua localtabke function test.lua` |
| `localcyt` | ✅ | 文字列代入 | `lua54 main.lua localcyt test.lua` |
| `localnum` | ✅ | 数値代入 | `lua54 main.lua localnum function test.lua` |
| `localte` | ✅ | ブール値代入 | `lua54 main.lua localte function test.lua` |
| `outcode` | ❌ | コメントアウトコード | `lua54 main.lua outcode test.lua` |
| `deleteout` | ❌ | 高精度コメント削除 | `lua54 main.lua deleteout test.lua` |
| `nocode` | ❌ | 未使用ローカルコード削除 | `lua54 main.lua nocode test.lua` |
| `fom` | ❌ | コード整形（Luau / Lua 5.1） | `lua54 main.lua fom test.lua` |
| `coml` | ❌ | 1行圧縮＋定数畳み込み＋不要コード削除 | `lua54 main.lua coml test.lua` |
| `nmbun` | ❌ | 計算可能な式を答えに簡約 | `lua54 main.lua nmbun test.lua` |
| `rename` | ❌ | ローカル変数名ランダム化（宣言/参照対応） | `lua54 main.lua rename test.lua` |
| `lint` | ❌ | 静的解析レポート出力 | `lua54 main.lua lint test.lua` |
| `rrequire` | ❌ | `require` 依存解析レポート出力 | `lua54 main.lua rrequire test.lua` |
| `preset` | ❌ | JSON プリセットの段階実行 | `lua54 main.lua preset test.lua` |

**✅ = スコープ指定可能 (デフォルト: 両方)**  
**❌ = スコープ指定不可**

---

## 📖 コマンド別クイックリファレンス

### `functionlocal` - 関数宣言の local を削除

```bash
lua54 main.lua functionlocal test.lua              # 両方のスコープ
lua54 main.lua functionlocal function test.lua     # 関数内のみ
lua54 main.lua functionlocal global test.lua       # グローバルのみ
```

### `localkw` - すべての local を削除

```bash
lua54 main.lua localkw test.lua                    # 両方のスコープ
lua54 main.lua localkw function test.lua           # 関数内のみ
lua54 main.lua localkw global test.lua             # グローバルのみ
```

### `localtabke` - テーブル初期化の local を削除 ⭐

```bash
lua54 main.lua localtabke test.lua                 # 両方のスコープ
lua54 main.lua localtabke function test.lua        # 関数内のみ
lua54 main.lua localtabke global test.lua          # グローバルのみ
```

### `localcyt` - 文字列代入の local を削除

```bash
lua54 main.lua localcyt test.lua                   # 両方のスコープ
lua54 main.lua localcyt function test.lua          # 関数内のみ
lua54 main.lua localcyt global test.lua            # グローバルのみ
```

### `localte` - ブール値代入の local を削除

```bash
lua54 main.lua localte test.lua                    # 両方のスコープ
lua54 main.lua localte function test.lua           # 関数内のみ
lua54 main.lua localte global test.lua             # グローバルのみ
```

### `localnum` - 数値代入の local を削除

```bash
lua54 main.lua localnum test.lua                   # 両方のスコープ
lua54 main.lua localnum function test.lua          # 関数内のみ
lua54 main.lua localnum global test.lua            # グローバルのみ
```

### `outcode` - コメントアウトコードの削除

```bash
lua54 main.lua outcode test.lua
```

### `deleteout` - 高精度コメント削除

```bash
lua54 main.lua deleteout test.lua
```

### `nocode` - 未使用ローカルコード削除

```bash
lua54 main.lua nocode test.lua
```

仕様:
- 未使用の `local` 宣言（副作用のない初期化のみ）を削除
- 未使用の `local function` を削除
- 安全チェック（再トークン化/再解析/必要時の構文検証）で壊れた出力を回避

### `fom` - コード整形（Luau / Lua 5.1 対応）

```bash
lua54 main.lua fom test.lua
```

### `coml` - 1行圧縮（Luau / Lua 5.1 対応）

```bash
lua54 main.lua coml test.lua
```

仕様:
- 定数畳み込み（例: `1+2` → `3`）
- 単純な不要コード削除（例: `if false then ... end` 削除、`if true then ... end` 展開、`return` / `break` 以降の文削除）
- 最後に安全チェック（トークン化・AST再解析可能性・必要時の構文検証）を行い、不正化を検知した場合は安全側へフォールバック

### `nmbun` - 数式簡約（答え化）

```bash
lua54 main.lua nmbun test.lua
```

仕様:
- ASTベースで定数畳み込み（算術/比較/論理/文字列連結）を反復適用
- 計算可能な式は結果リテラルへ変換
- 構文/コンパイル安全チェック付き。危険な場合は元コードを返す

### `rename` - ローカル変数名ランダム化

```bash
lua54 main.lua rename test.lua
```

仕様:
- ローカル変数 / 関数引数 / `for` 変数を宣言と参照の両方で変換
- 1文字名を優先し、衝突がある場合は2文字以上へ自動拡張
- 予約語や既存識別子との衝突を回避

### `lint` - 静的解析

```bash
lua54 main.lua lint test.lua
```

仕様:
- `output/test.lua.lint.json` に JSON レポートを出力
- 検出対象: 未使用ローカル、未定義参照、型不一致ヒント、不要な式文、到達不能コード、未宣言グローバル代入

### `rrequire` - require 依存解析

```bash
lua54 main.lua rrequire test.lua
```

仕様:
- エントリーファイルから `require("...")` を再帰追跡
- `output/test.lua.rrequire.json` に依存関係レポートを出力
- 解決不能 require / 動的 require / 解析エラー / 依存サイクルを一覧化

### `preset` - JSON プリセット段階実行

```bash
lua54 main.lua preset test.lua
lua54 main.lua preset test.lua preset.json
```

仕様:
- `preset.json`（または指定した JSON）を読み込み、`steps` を順番実行
- 各ステップは「直前ステップの結果」をそのまま上書きで引き継ぐ
- 最終出力: `output/<入力ファイル名>`
- 段階出力（`write_step_outputs: true` のときのみ）: `output/preset_steps/<入力ファイル名>.stepXX_<name>.lua`
- 実行レポート: `output/<入力ファイル名>.preset.json`

### エンジン指定（オプション）

```bash
# 行ベース処理（デフォルト・推奨）
lua54 main.lua localtabke test.lua

# 明示的に指定する場合
lua54 main.lua --engine=line localtabke test.lua

# AST ベース処理（フォールバック）
lua54 main.lua --engine=ast functionlocal test.lua
```

※ `fom` / `coml` / `nmbun` / `rename` / `deleteout` / `nocode` / `lint` / `rrequire` / `preset` は `--engine` 指定の影響を受けません（`preset` は JSON 側の `engine` または各 step の `engine` を優先）。

---

## 🔍 機能説明

### 1️⃣ `functionlocal` - 関数宣言の local を削除

**対象**:
- `local function name() ... end`
- `local name = function() ... end`

**変換例**:

```lua
-- 入力
local add = function(a, b)
  return a + b
end

function main()
  local helper = function(x) return x * 2 end
end

-- 出力（デフォルト）
add = function(a, b)
  return a + b
end

function main()
  helper = function(x) return x * 2 end
end
```

---

### 2️⃣ `localkw` - すべての local キーワードを削除

**対象**: すべての `local` 宣言

**変換例**:

```lua
-- 入力
local x = 10
local y = 20

function test()
  local a = 100
  local b = 200
end

-- 出力
x = 10
y = 20

function test()
  a = 100
  b = 200
end
```

---

### 3️⃣ `localtabke` - テーブル初期化の local を削除 ⭐ **新機能**

**対象**: テーブル代入のみ
- `local a = {}`
- `local config = {x = 1, y = 2}`

**削除されない例**:
- `local e = "string"` （文字列）
- `local f = 123` （数値）
- `local g = true` （ブール値）

**変換例**:

```lua
-- 入力
local config = {}
local colors = {red = 1, green = 2}

function init()
  local cache = {}
  local data = {a = 1}
end

local message = "hello"

-- 出力（全スコープ削除）
config = {}
colors = {red = 1, green = 2}

function init()
  cache = {}
  data = {a = 1}
end

local message = "hello"
```

**スコープ指定例**:

```lua
-- 入力
local config = {}

function init()
  local cache = {}
end

-- lua54 main.lua localtabke function test.lua
-- 出力（関数内のみ削除）
local config = {}

function init()
  cache = {}
end
```

---

### 4️⃣ `localcyt` - 文字列代入の local を削除

**対象**: 文字列値の代入のみ
- `local s = "text"`
- `local name = 'John'`

**削除されない例**:
- `local n = 42` （数値）
- `local t = {}` （テーブル）

**変換例**:

```lua
-- 入力
local greeting = "Hello"
local version = "1.0"

function getMessage()
  local msg = "Processing..."
  local error_text = "Error occurred"
  local count = 42
end

-- 出力（全スコープ削除）
greeting = "Hello"
version = "1.0"

function getMessage()
  msg = "Processing..."
  error_text = "Error occurred"
  local count = 42
end
```

---

### 5️⃣ `localte` - ブール値代入の local を削除

**対象**: ブール値（`true` / `false`）の代入のみ
- `local enabled = true`
- `local debug = false`

**削除されない例**:
- `local count = 10` （数値）
- `local data = {}` （テーブル）

**変換例**:

```lua
-- 入力
local debug_mode = true
local is_active = false

function setup()
  local initialized = true
  local ready = false
  local count = 10
end

-- 出力（全スコープ削除）
debug_mode = true
is_active = false

function setup()
  initialized = true
  ready = false
  local count = 10
end
```

---

### 6️⃣ `outcode` - コメントアウトコードの削除

**対象**:
- 単行コメント内のコード行: `-- local x = 10`
- ブロックコメント内のコード: `--[[ function() ... ]]`

**検出対象キーワード**: `local`, `function`, `=`, `return` など

**変換例**:

```lua
-- 入力
local x = 10
-- local old_code = 20
-- function deprecated() end
--[[ 
local unused_var = 30
function removed() end
]]
local y = 40

-- 出力
local x = 10
local y = 40
```

---

### 7️⃣ `fom` - コード整形（Luau / Lua 5.1 対応）

**内容**:
- インデントを整形して読みやすくします
- Luau / Lua 5.1 の文法をトークン解析し、ASTベースでインデントを再計算

**例**:

```lua
-- 入力
function test()
if ok then
print("ok")
end
end

-- 出力
function test()
  if ok then
    print("ok")
  end
end
```

---

### 8️⃣ `coml` - 1行圧縮（Luau / Lua 5.1 対応）

**内容**:
- 余分な空白とコメントを除去して1行に圧縮
- 定数畳み込み（`1+2` → `3` など）
- 単純な不要コード削除（`if false then ... end` 削除、`if true then ... end` 展開）
- 改行由来の文境界で安全な場合は `;` を挿入して区切りを明確化
- 安全チェック（トークン検証・必要時の構文検証）で壊れた出力を回避

**例**:

```lua
-- 入力
local x = 1  -- sample
local y = x + 2

-- 出力
local x=3
```

---

### 9️⃣ `rename` - ローカル変数名ランダム化

**内容**:
- ローカル変数・関数引数・`for` 変数をランダム短名へ変換
- 参照側も同時に置換
- 1文字名を優先、衝突時は2文字以上へ自動拡張

**例**:

```lua
-- 入力
local playerCount = 10
local function addOne(value)
  local nextValue = value + 1
  return nextValue
end

-- 出力（例）
local a = 10
local function b(c)
  local d = c + 1
  return d
end
```

---

### 1️⃣1️⃣ `lint` - 静的解析

**内容**:
- 未使用ローカル変数/引数/for変数の検出
- 未定義参照の検出（既知グローバルは除外）
- 算術/連結まわりの型不一致ヒント
- 副作用のない式文の検出
- 到達不能コード（`return`/`break` 後）の検出
- 未宣言グローバル代入/保護グローバル上書きの検出

**出力**:
- 元コードはそのまま `output/<入力ファイル名>`
- レポートは `output/<入力ファイル名>.lint.json`

---

### 1️⃣2️⃣ `rrequire` - require 依存解析

**内容**:
- `require(\"module.path\")` をASTから抽出
- `local rq = require` のようなエイリアス呼び出しを追跡
- `pcall(require, \"...\")` / `xpcall(require, ..., \"...\")` を検出
- エントリーファイル起点で依存を再帰追跡し、依存サイクルも検出
- 解決不能 require / 動的 require / 解析失敗を一覧化

**出力**:
- 元コードはそのまま `output/<入力ファイル名>`
- レポートは `output/<入力ファイル名>.rrequire.json`

---

### 1️⃣3️⃣ `preset` - JSON プリセット段階実行

**内容**:
- `preset.json` の `steps` 配列に記載したコマンドを上から順に実行
- 各ステップごとに中間成果物を保存可能
- 最後に最終結果と実行レポート JSON を出力

**標準の `preset.json` 例**:

```json
{
  "version": 1,
  "name": "default-clean-format-minify",
  "description": "コメント削除 -> 整形 -> 圧縮 を段階的に実行するプリセット",
  "engine": "line",
  "write_step_outputs": false,
  "stop_on_error": true,
  "steps": [
    {
      "name": "strip-comments",
      "mode": "deleteout",
      "enabled": true
    },
    {
      "name": "format-readable",
      "mode": "fom",
      "enabled": true
    },
    {
      "name": "compress-final",
      "mode": "coml",
      "enabled": true
    }
  ]
}
```

**使い方**:

```bash
lua54 main.lua preset file.lua
```

---

## 📊 スコープ指定について

ほとんどのコマンドで、削除対象を限定できます：
※ `fom` / `coml` / `nmbun` / `rename` / `deleteout` / `nocode` / `lint` / `rrequire` / `preset` はスコープ指定不可です。

| オプション | 説明 | 削除対象 |
|-----------|------|---------|
| （なし）   | 両方のスコープ（デフォルト） | グローバル ＋ 関数内 |
| `function` | 関数内のみ | 関数内のみ |
| `global`   | グローバルスコープのみ | グローバル（トップレベル）のみ |

**使用例**:

```bash
# グローバルスコープのテーブル初期化のみ削除
lua54 main.lua localtabke global test.lua

# 関数内の文字列代入のみ削除
lua54 main.lua localcyt function test.lua

# 両方削除（デフォルト）
lua54 main.lua localtabke test.lua
```

---

## 💡 実践例・シナリオ

### シナリオ1: 関数を外部化する

**目的**: ローカル関数をグローバルに昇格

```lua
-- 元のコード
function module()
  local helper = function() return "help" end
  return helper()
end

-- 実行: lua54 main.lua functionlocal test.lua
-- 結果
function module()
  helper = function() return "help" end
  return helper()
end
```

### シナリオ2: グローバル変数の初期化をクリーンアップ

**目的**: グローバルテーブルのみクリーンアップ

```lua
-- 元のコード
local config = {version = "1.0"}
local active = true

-- 実行: lua54 main.lua localtabke global test.lua
-- 結果
config = {version = "1.0"}
local active = true
```

### シナリオ3: デバッグコードの削除

**目的**: コメント内のコード行を削除

```lua
-- 元のコード
local x = 10
-- local debug_x = x * 2
--[[ 
local old_version = "0.9"
function test() end
]]
local y = 20

-- 実行: lua54 main.lua outcode test.lua
-- 結果
local x = 10
local y = 20
```

### シナリオ4: 複数コマンドの組み合わせ

```bash
# 1. 関数宣言の local を削除
lua54 main.lua functionlocal source.lua

# 2. 出力をコピーして、次にグローバルテーブルをクリーンアップ
cp output/source.lua source2.lua
lua54 main.lua localtabke global source2.lua
```

---

## 🔧 入出力

### 入力形式

```bash
lua54 main.lua <コマンド> [スコープ] <入力ファイル>
```

| 部分 | 説明 |
|------|------|
| `<コマンド>` | `functionlocal`, `localkw`, `localtabke`, `localcyt`, `localnum`, `localte`, `outcode`, `deleteout`, `nocode`, `fom`, `coml`, `nmbun`, `rename`, `lint`, `rrequire`, `preset` |
| `[スコープ]` | 省略可。`function` または `global`（コマンドによって対応状況が異なる） |
| `<入力ファイル>` | Luaソースファイルパス |

### 出力形式

変換されたファイルは `output/` ディレクトリに保存されます：

```
output/<入力ファイル名>
```

**例**:
- 入力: `test.lua`
- 出力: `output/test.lua`
- 安全レポート: `output/test.lua.safety.json`

### ステータス出力

コマンド実行時、以下の情報が `stderr` に出力されます：

```
loading test.lua
mode: remove_local_table_all
scope: global

complete: output/test.lua

total local variables: 0
in functions: 0
global: 0
```

---

## ⚠️ トラブルシューティング

### Q: 想定と異なる行が削除されました

**A**: 行ベース処理では、複数行にまたがる複雑な式で誤検出する可能性があります。  
出力ファイル（`output/`）で確認して、必要に応じてコマンドを変更してください。

### Q: インデントが変わってしまった

**A**: 行ベースエンジンは元のインデントを保持します。AST エンジン（`--engine=ast`）を試してみてください。

### Q: コメント内の local も削除されてしまった

**A**: `outcode` コマンドはコメント内のコードを削除します。  
それ以外のコマンドではコメント内容は保持されます。

### Q: テーブル以外の代入も削除されてしまった

**A**: `localtabke` はテーブル初期化（`{}`）のみを対象としています。  
他の型（文字列・数値・ブール値）には反応しません。

### Q: 複数の異なる local を別のコマンドで処理したい

**A**: 出力ファイルを入力として再度処理できます：

```bash
lua54 main.lua functionlocal test.lua
cp output/test.lua test2.lua
lua54 main.lua localtabke test2.lua
```

---

## ✅ 全コマンドテスト

全コマンドを1つずつ実行し、出力のコンパイル可否と JSON レポートの妥当性を検証します。

```bash
lua54 tests/run_all_commands.lua
```

ローカル削除の精度（関数スコープ/グローバルスコープの判定）専用テスト:

```bash
lua54 tests/local_precision.lua
```

---

## 🎓 内部構造（開発者向け）

### ファイル構成

```
.
├── main.lua                    # メインエントリーポイント
├── src/
│   ├── lexer.lua             # トークン化処理
│   ├── lexer_full.lua        # Luau / Lua 5.1 対応トークナイザ
│   ├── parser.lua            # AST解析
│   ├── analyzer.lua          # コード分析
│   ├── transformer.lua       # AST変換
│   ├── transformer_line.lua  # 行ベース変換（推奨）
│   ├── codegen.lua           # コード生成
│   ├── formatter.lua         # コード整形（fom）
│   ├── compressor.lua        # 1行圧縮（coml）
│   ├── nmbun.lua             # 数式簡約（nmbun）
│   ├── deleteout.lua         # 高精度コメント削除（deleteout）
│   ├── nocode.lua            # 未使用ローカルコード削除（nocode）
│   ├── renamer.lua           # 変数名ランダム化（rename）
│   ├── linter.lua            # 静的解析（lint）
│   ├── rrequire.lua          # 依存解析（rrequire）
│   ├── preset.lua            # JSONプリセット段階実行（preset）
│   └── ast.lua               # AST定義
├── output/                    # 出力先ディレクトリ
└── README.md                  # このファイル
```

### 処理フロー

#### 1. トークン化

`src/lexer.lua` がソースコードをトークンに分割します。

**例**: `local a = {}`

```
LOCAL → IDENT(a) → ASSIGN → LBRACE → RBRACE
```

#### 2. 行ベース変換（推奨エンジン）

`src/transformer_line.lua` がトークン列を参照しながら、削除対象の `local` を特定します。

**検出ロジック**:

```lua
-- テーブル初期化の検出
if valtok.type == 'LBRACE' then 
  remove = true
end

-- 文字列代入の検出
if valtok.type == 'STRING' then 
  remove = true
end

-- ブール値代入の検出
if valtok.type == 'TRUE' or valtok.type == 'FALSE' then 
  remove = true
end
```

#### 3. スコープ判定

```lua
-- 関数内か判定
local in_function = function_depth > 0

-- スコープに応じて削除判定
if mode == 'remove_local_table_function' then
  scope_ok = in_function
elseif mode == 'remove_local_table_global' then
  scope_ok = not in_function
end
```

#### 4. 出力生成

変換済みコードは行ごとに `replacements` テーブルに格納され、最終的に `output/` に書き込まれます。

### エンジン選択

| エンジン | 速度 | 精度 | インデント保持 | 推奨用途 |
|---------|------|------|---------------|---------|
| `line` | 高速 | 高 | ✅ | **通常の使用** |
| `ast` | 低速 | 最高 | △ | 複雑な構文の処理 |

---

## 📝 ライセンス

このプロジェクトはMITライセンス下で公開されています。

---

## 🤝 フィードバック

不具合や機能リクエストは、ログ出力（`stderr`）を参照して、  
テストケース（例: `test_localtabke.lua`）の出力と照合してください。
