local x = 1
local t = { value = x }

local function add(a, b)
  local c = a + b
  return c
end

if t.value > 0 then
  x = add(x, 2)
else
  x = 0
end

for i = 1, 3 do
  x = x + i
end

for k, v in pairs(t) do
  print(k, v)
end

return x