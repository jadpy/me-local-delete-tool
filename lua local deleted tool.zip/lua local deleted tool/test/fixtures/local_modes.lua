local g_bool = true
local g_str = "hello"
local g_num = 123
local g_tab = { x = 1 }

local function outer(p)
  local f_bool = false
  local f_str = "inside"
  local f_num = 456
  local f_tab = {}
  local keep = p + 1
  return f_bool, f_str, f_num, f_tab, keep
end

return outer(10), g_bool, g_str, g_num, g_tab