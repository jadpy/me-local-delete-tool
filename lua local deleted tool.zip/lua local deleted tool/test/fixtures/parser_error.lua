local x =

if true then
  print(x)