local input = arg[1] or 'test.lua'

local function read_file(path)
  local f = io.open(path, 'rb')
  if not f then
    return nil, 'cannot open: ' .. path
  end
  local s = f:read('*a')
  f:close()
  return s
end

local function sorted_keys(t)
  local ks = {}
  for k in pairs(t) do
    ks[#ks + 1] = k
  end
  table.sort(ks, function(a, b)
    return tostring(a) < tostring(b)
  end)
  return ks
end

local source, read_err = read_file(input)
if not source then
  io.stderr:write(read_err .. '\n')
  os.exit(1)
end

local Lexer = require('src.lexer')
local Parser = require('src.parser')

local ok_lex, tokens_or_err = pcall(function()
  return Lexer.new(source):tokenize()
end)
if not ok_lex then
  io.stderr:write('lexer error: ' .. tostring(tokens_or_err) .. '\n')
  os.exit(1)
end
local tokens = tokens_or_err

local ok_parse, ast_or_err = pcall(function()
  return Parser.new(tokens):parse()
end)
if not ok_parse then
  io.stderr:write('parser error: ' .. tostring(ast_or_err) .. '\n')
  os.exit(1)
end
local ast = ast_or_err

local stats = {
  total_nodes = 0,
  by_type = {},
  local_decl = 0,
  local_func = 0
}
local seen = {}

local function walk(node)
  if type(node) ~= 'table' then
    return
  end
  if seen[node] then
    return
  end
  seen[node] = true
  if node.type then
    stats.total_nodes = stats.total_nodes + 1
    stats.by_type[node.type] = (stats.by_type[node.type] or 0) + 1
    if node.type == 'LocalDecl' then
      stats.local_decl = stats.local_decl + 1
    elseif node.type == 'LocalFunc' then
      stats.local_func = stats.local_func + 1
    end
  end
  for _, v in pairs(node) do
    walk(v)
  end
end

walk(ast)

print('input: ' .. input)
print('tokens: ' .. tostring(#tokens))
print('ast_total_nodes: ' .. tostring(stats.total_nodes))
print('local_decl: ' .. tostring(stats.local_decl))
print('local_func: ' .. tostring(stats.local_func))
print('')
print('node_counts:')
for _, k in ipairs(sorted_keys(stats.by_type)) do
  print(string.format('  %-16s %d', k, stats.by_type[k]))
end
