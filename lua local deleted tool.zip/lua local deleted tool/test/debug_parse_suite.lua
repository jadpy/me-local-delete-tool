local Lexer = require('src.lexer')
local Parser = require('src.parser')

local function read_file(path)
  local f = io.open(path, 'rb')
  if not f then
    return nil, 'cannot open: ' .. path
  end
  local s = f:read('*a')
  f:close()
  return s
end

local function parse_source(source)
  local tokens = Lexer.new(source):tokenize()
  local ast = Parser.new(tokens):parse()
  return ast
end

local cases = {
  { path = 'test/fixtures/parser_ok.lua', expect_ok = true },
  { path = 'test/fixtures/parser_error.lua', expect_ok = false }
}

local pass = 0
local fail = 0

print('parser suite start')
for _, case in ipairs(cases) do
  local source, read_err = read_file(case.path)
  if not source then
    fail = fail + 1
    print(string.format('[FAIL] %s (%s)', case.path, read_err))
  else
    local ok, result = pcall(function()
      return parse_source(source)
    end)
    local matched = ok == case.expect_ok
    if matched then
      pass = pass + 1
      print(string.format('[PASS] %s (expect_ok=%s, actual_ok=%s)', case.path, tostring(case.expect_ok), tostring(ok)))
    else
      fail = fail + 1
      print(string.format('[FAIL] %s (expect_ok=%s, actual_ok=%s)', case.path, tostring(case.expect_ok), tostring(ok)))
      print('       detail: ' .. tostring(result))
    end
  end
end

print('')
print(string.format('summary: pass=%d fail=%d total=%d', pass, fail, pass + fail))
if fail > 0 then
  os.exit(1)
end
