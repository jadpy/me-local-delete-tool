#!/usr/bin/env lua

local Lexer = require('src.lexer')
local Parser = require('src.parser')
local Analyzer = require('src.analyzer')
local Transformer = require('src.transformer')
local CodeGen = require('src.codegen')
local TransformerLine = require('src.transformer_line')
local Formatter = require('src.formatter')
local Compressor = require('src.compressor')
local Nmbun = require('src.nmbun')
local Renamer = require('src.renamer')
local DeleteOut = require('src.deleteout')
local NoCode = require('src.nocode')
local Linter = require('src.linter')
local RRequire = require('src.rrequire')
local Safety = require('src.safety')
local Json = require('src.json')
local Preset = require('src.preset')
local Dialect = require('src.dialect')

function read_file(filepath)
  local file = io.open(filepath, 'rb')
  if not file then
    error('Cannot open file: ' .. filepath)
  end
  local content = file:read('*a')
  file:close()
  return content
end

function write_file(filepath, content)
  local file = io.open(filepath, 'wb')
  if not file then
    error('Cannot write file: ' .. filepath)
  end
  file:write(content)
  file:close()
end

function ensure_dir(dirpath)
  os.execute('if not exist "' .. dirpath .. '" mkdir "' .. dirpath .. '"')
end

function process_file(input_filepath, mode, engine, options)
  options = options or {}
  local dialect = Dialect.resolve(options.dialect)
  local source = read_file(input_filepath)
  local pre_analysis = Safety.analyze_source(source, { dialect = dialect.name })
  local function finalize(output_code, analyzer, meta)
    local guarded_output, safety_report = Safety.guard(mode, source, output_code, pre_analysis, { dialect = dialect.name })
    local final_meta = meta or {}
    final_meta.extra_reports = final_meta.extra_reports or {}
    final_meta.extra_reports[#final_meta.extra_reports + 1] = {
      suffix = '.safety.json',
      data = safety_report
    }
    return guarded_output, analyzer or { all_locals = {} }, final_meta
  end

  if mode == 'fom' then
    local output_code = Formatter.format(source, { dialect = dialect.name })
    local analyzer = { all_locals = {} }
    return finalize(output_code, analyzer)
  elseif mode == 'coml' then
    local output_code = Compressor.compress(source, { dialect = dialect.name })
    local analyzer = { all_locals = {} }
    return finalize(output_code, analyzer)
  elseif mode == 'nmbun' then
    local output_code, analyzer = Nmbun.run(source, { dialect = dialect.name })
    return finalize(output_code, analyzer)
  elseif mode == 'rename' then
    local output_code, analyzer = Renamer.rename(source, { dialect = dialect.name })
    return finalize(output_code, analyzer)
  elseif mode == 'deleteout' then
    local output_code = DeleteOut.strip(source, { dialect = dialect.name })
    local analyzer = { all_locals = {} }
    return finalize(output_code, analyzer)
  elseif mode == 'nocode' then
    local output_code, analyzer = NoCode.clean(source, { dialect = dialect.name })
    return finalize(output_code, analyzer)
  elseif mode == 'lint' then
    local result = Linter.run(source, {
      dialect = dialect.name,
      dynamic = options.lint_dynamic ~= false
    })
    local analyzer = { all_locals = {} }
    return finalize(source, analyzer, {
      report_data = {
        type = 'lint-report',
        file = input_filepath,
        generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        result = result
      },
      report_suffix = '.lint.json',
      lint_summary = result.summary
    })
  elseif mode == 'rrequire' then
    local result = RRequire.analyze(input_filepath, { dialect = dialect.name })
    local analyzer = { all_locals = {} }
    return finalize(source, analyzer, {
      report_data = {
        type = 'rrequire-report',
        file = input_filepath,
        generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        result = result
      },
      report_suffix = '.rrequire.json',
      rrequire_summary = result.summary
    })
  elseif mode == 'preset' then
    local preset_file = 'preset.json'
    if options and options.preset_file and options.preset_file ~= '' then
      preset_file = options.preset_file
    end
    local output_code, analyzer, meta = Preset.run(input_filepath, preset_file, engine, {
      dialect = dialect.name,
      lint_dynamic = options.lint_dynamic ~= false
    })
    return finalize(output_code, analyzer, meta)
  end
  local lexer = Lexer.new(source, { dialect = dialect.name })
  local tokens = lexer:tokenize()

  if engine == 'line' then
    local transformer = TransformerLine.new(source, tokens, { mode = mode, dialect = dialect.name })
    local output_code = transformer:apply()
    local analyzer = { all_locals = {} }
    return finalize(output_code, analyzer)
  end

  local parser = Parser.new(tokens, { dialect = dialect.name })
  local ast = parser:parse()

  local analyzer = Analyzer.new()
  analyzer:analyze(ast)

  local transformer = Transformer.new({ mode = mode })
  local transformed_ast = transformer:transform(ast)

  local codegen = CodeGen.new(source)
  local output_code = codegen:generate(transformed_ast)

  return finalize(output_code, analyzer)
end

function show_usage()
  print('Usage:')
  print('  lua54 main.lua [--engine=line|ast] [--lint-dynamic=on|off] <mode> [scope] <inputfile> [presetfile]')
  print()
  print('Modes:')
  print('  functionlocal        - Remove `local` from function declarations (`local function` or `local name = function`)')
  print('  localkw [scope]      - Remove only "local" keyword (preserve scope)')
  print('  localte <scope>      - Remove "local" from boolean assignments')
  print('  localc <scope>       - Remove "local" from string assignments')
  print('  localcyt [scope]     - Remove "local" for string assignments (alias of localc; default: both scopes)')
  print('  localnum [scope]     - Remove "local" from number assignments (default: both scopes)')
  print('  localtabke [scope]   - Remove "local" from table assignments (default: both scopes)')
  print('  outcode              - Remove commented-out code blocks/lines')
  print('  deleteout            - Remove all comments (-- and --[[ ]]) with safer token boundaries')
  print('  nocode               - Remove unused local code with conservative side-effect safety checks')
  print('  fom                  - Format code (Luau/Lua 5.1 aware, AST-based indentation)')
  print('  coml                 - Compress to one line with constant folding, dead code removal, and safety checks')
  print('  nmbun                - Fold numeric/string/boolean expressions and output simplified result')
  print('  rename               - Randomly rename local variables/params with collision-safe short names')
  print('  lint                 - Static + dynamic analysis with JSON report output')
  print('  rrequire             - Analyze require dependency graph with JSON report output')
  print('  preset               - Run multi-step pipeline from pretty JSON preset file')
  print()
  print('Scope options (for localkw):')
  print('  function             - Remove "local" from function scope only')
  print('  global               - Remove "local" from global scope only')
  print('  (default: both)      - Remove "local" from both scopes')
  print()
  print('Scope options (for localte/localc/localcyt/localnum):')
  print('  function             - Remove "local" from function assignments')
  print('  global               - Remove "local" from global assignments')
  print()
  print('Lint dynamic options:')
  print('  --lint-dynamic=on    - run sandboxed runtime lint checks (default)')
  print('  --lint-dynamic=off   - static lint only')
  print('  lint -on/-off        - per-command override for lint dynamic checks')
  print()
  print('Examples:')
  print('  lua main.lua coml test.lua')
  print('  lua main.lua lint test.lua')
  print('  lua main.lua --lint-dynamic=off lint test.lua')
  print('  lua main.lua functionlocal test.lua')
  print('  lua main.lua functionlocal function test.lua')
  print('  lua main.lua functionlocal global test.lua')
  print('  lua main.lua localkw test.lua')
  print('  lua main.lua localkw function test.lua')
  print('  lua main.lua localte global test.lua')
  print('  lua main.lua localc function test.lua')
  print('  lua main.lua localcyt test.lua')
  print('  lua main.lua localnum test.lua')
  print('  lua main.lua deleteout test.lua')
  print('  lua main.lua nocode test.lua')
  print('  lua main.lua nmbun test.lua')
  print('  lua main.lua rename test.lua')
  print('  lua main.lua lint test.lua')
  print('  lua main.lua lint -off test.lua')
  print('  lua main.lua lint -on test.lua')
  print('  lua main.lua rrequire test.lua')
  print('  lua main.lua preset test.lua')
  print('  lua main.lua preset test.lua preset.json')
end

function main()
  local raw_args = arg
  local args = {}
  local engine = 'line'
  local dialect = 'auto'
  local lint_dynamic = true
  local idx = 1

  while idx <= #raw_args do
    local opt = raw_args[idx]
    if opt and opt:match('^%-%-engine=') then
      engine = opt:match('^%-%-engine=(.+)')
      idx = idx + 1
    elseif opt and opt:match('^%-%-dialect=') then
      idx = idx + 1
    elseif opt and opt:match('^%-%-lint%-dynamic=') then
      local v = (opt:match('^%-%-lint%-dynamic=(.+)') or ''):lower()
      lint_dynamic = (v == 'on' or v == 'true' or v == '1' or v == '')
      idx = idx + 1
    else
      break
    end
  end

  for i = idx, #raw_args do table.insert(args, raw_args[i]) end

  if #args < 1 then
    show_usage()
    return
  end

  local mode_name = args[1]
  local scope = nil
  local input_file = nil
  local preset_file = nil
  
  if mode_name == 'functionlocal' then
    if #args == 1 then
      show_usage()
      return
    end

    if #args >= 3 then
      local potential_scope = args[2]
      if potential_scope == 'function' or potential_scope == 'global' then
        scope = potential_scope
        input_file = args[3]
      else
        input_file = args[2]
      end
    else
      input_file = args[2]
    end
  elseif mode_name == 'localkw' then
    if #args == 1 then
      show_usage()
      return
    end
    
    if #args >= 3 then
      local potential_scope = args[2]
      if potential_scope == 'function' or potential_scope == 'global' then
        scope = potential_scope
        input_file = args[3]
      else
        input_file = args[2]
      end
    else
      input_file = args[2]
    end
  elseif mode_name == 'localcyt' then
    if #args == 1 then
      show_usage()
      return
    end

    if #args >= 3 then
      local potential_scope = args[2]
      if potential_scope == 'function' or potential_scope == 'global' then
        scope = potential_scope
        input_file = args[3]
      else
        input_file = args[2]
      end
    else
      input_file = args[2]
    end
  elseif mode_name == 'localnum' then
    if #args == 1 then
      show_usage()
      return
    end

    if #args >= 3 then
      local potential_scope = args[2]
      if potential_scope == 'function' or potential_scope == 'global' then
        scope = potential_scope
        input_file = args[3]
      else
        input_file = args[2]
      end
    else
      input_file = args[2]
    end
  elseif mode_name == 'localtur' then
    if #args == 1 then
      show_usage()
      return
    end

    if #args >= 3 then
      local potential_scope = args[2]
      if potential_scope == 'function' or potential_scope == 'global' then
        scope = potential_scope
        input_file = args[3]
      else
        input_file = args[2]
      end
    else
      input_file = args[2]
    end
  elseif mode_name == 'localte' then
    if #args < 3 then
      show_usage()
      return
    end
    scope = args[2]
    if scope ~= 'function' and scope ~= 'global' then
      show_usage()
      return
    end
    input_file = args[3]
  elseif mode_name == 'localc' then
    if #args < 3 then
      show_usage()
      return
    end
    scope = args[2]
    if scope ~= 'function' and scope ~= 'global' then
      show_usage()
      return
    end
    input_file = args[3]
  elseif mode_name == 'localtabke' then
    if #args == 1 then
      show_usage()
      return
    end
    
    if #args >= 3 then
      local potential_scope = args[2]
      if potential_scope == 'function' or potential_scope == 'global' then
        scope = potential_scope
        input_file = args[3]
      else
        input_file = args[2]
      end
    else
      input_file = args[2]
    end
  elseif mode_name == 'outcode' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'deleteout' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'nocode' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'fom' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'coml' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'nmbun' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'rename' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'lint' then
    if #args == 1 then show_usage(); return end
    local lint_opt = args[2]
    if lint_opt == '-off' or lint_opt == 'off' then
      lint_dynamic = false
      input_file = args[3]
    elseif lint_opt == '-on' or lint_opt == 'on' then
      lint_dynamic = true
      input_file = args[3]
    else
      input_file = args[2]
    end
  elseif mode_name == 'rrequire' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
  elseif mode_name == 'preset' then
    if #args == 1 then show_usage(); return end
    input_file = args[2]
    preset_file = args[3]
  else
    show_usage()
    return
  end
  if not input_file then
    show_usage()
    return
  end
  
  local f = io.open(input_file, 'r')
  if not f then
    print('Error: File not found: ' .. input_file)
    return
  end
  f:close()
  
  local mode = 'remove_function_local'
  
  if mode_name == 'functionlocal' then
    if scope == 'function' then
      mode = 'remove_function_local_function'
    elseif scope == 'global' then
      mode = 'remove_function_local_global'
    else
      mode = 'remove_function_local_all'
    end
  elseif mode_name == 'localcyt' then
    if scope == 'function' then
      mode = 'remove_local_string_function'
    elseif scope == 'global' then
      mode = 'remove_local_string_global'
    else
      mode = 'remove_local_string_all'
    end
  elseif mode_name == 'localnum' then
    if scope == 'function' then
      mode = 'remove_local_number_function'
    elseif scope == 'global' then
      mode = 'remove_local_number_global'
    else
      mode = 'remove_local_number_all'
    end
  elseif mode_name == 'localtur' then
    if scope == 'function' then
      mode = 'remove_local_boolean_function'
    elseif scope == 'global' then
      mode = 'remove_local_boolean_global'
    else
      mode = 'remove_local_boolean_all'
    end
  elseif mode_name == 'localkw' then
    if scope == 'function' then
      mode = 'remove_local_keyword_function'
    elseif scope == 'global' then
      mode = 'remove_local_keyword_global'
    else
      mode = 'remove_local_keyword_all'
    end
  elseif mode_name == 'localte' then
    if scope == 'function' then
      mode = 'remove_local_boolean_function'
    elseif scope == 'global' then
      mode = 'remove_local_boolean_global'
    end
  elseif mode_name == 'localc' then
    if scope == 'function' then
      mode = 'remove_local_string_function'
    elseif scope == 'global' then
      mode = 'remove_local_string_global'
    end
  elseif mode_name == 'localtabke' then
    if scope == 'function' then
      mode = 'remove_local_table_function'
    elseif scope == 'global' then
      mode = 'remove_local_table_global'
    else
      mode = 'remove_local_table_all'
    end
  elseif mode_name == 'outcode' then
    mode = 'outcode'
  elseif mode_name == 'deleteout' then
    mode = 'deleteout'
  elseif mode_name == 'nocode' then
    mode = 'nocode'
  elseif mode_name == 'fom' then
    mode = 'fom'
  elseif mode_name == 'coml' then
    mode = 'coml'
  elseif mode_name == 'nmbun' then
    mode = 'nmbun'
  elseif mode_name == 'rename' then
    mode = 'rename'
  elseif mode_name == 'lint' then
    mode = 'lint'
  elseif mode_name == 'rrequire' then
    mode = 'rrequire'
  elseif mode_name == 'preset' then
    mode = 'preset'
  end
  
  io.stderr:write('loading ' .. input_file .. '\n')
  io.stderr:write('mode: ' .. mode .. '\n')
  if scope then
    io.stderr:write('scope:  ' .. scope .. '\n')
  end
  if mode == 'lint' then
    io.stderr:write('lint_dynamic: ' .. tostring(lint_dynamic) .. '\n')
  end
  if preset_file then
    io.stderr:write('preset: ' .. preset_file .. '\n')
  end
  io.stderr:write('\n')

  local output_code, analyzer, meta
  output_code, analyzer, meta = process_file(input_file, mode, engine, {
    preset_file = preset_file,
    dialect = dialect,
    lint_dynamic = lint_dynamic
  })
  
  ensure_dir('output')
  
  local filename = input_file:match('([^/\\]+)$')
  local output_filepath = 'output/' .. filename

  if output_code and mode ~= 'rename' and mode ~= 'deleteout' and mode ~= 'nocode' and mode ~= 'lint' and mode ~= 'rrequire' and mode ~= 'preset' then
    output_code = output_code:gsub('\n+$', '')
  end
  write_file(output_filepath, output_code)

  io.stderr:write('complete: ' .. output_filepath .. '\n\n')
  if meta and (meta.report_data or meta.report_text) then
    local report_path = 'output/' .. filename .. (meta.report_suffix or '.report.json')
    local report_body = meta.report_text
    if meta.report_data then
      report_body = Json.encode(meta.report_data, true)
    end
    write_file(report_path, report_body)
    io.stderr:write('report: ' .. report_path .. '\n')
    if meta.lint_summary then
      io.stderr:write(string.format(
        'lint summary: total=%d error=%d warning=%d info=%d\n',
        meta.lint_summary.total or 0,
        meta.lint_summary.error or 0,
        meta.lint_summary.warning or 0,
        meta.lint_summary.info or 0
      ))
    end
    if meta.rrequire_summary then
      io.stderr:write(string.format(
        'rrequire summary: files=%d edges=%d unresolved=%d dynamic=%d parse_errors=%d\n',
        meta.rrequire_summary.files or 0,
        meta.rrequire_summary.edges or 0,
        meta.rrequire_summary.unresolved or 0,
        meta.rrequire_summary.dynamic or 0,
        meta.rrequire_summary.parse_errors or 0
      ))
    end
    io.stderr:write('\n')
  end
  if meta and type(meta.extra_reports) == 'table' then
    for _, extra in ipairs(meta.extra_reports) do
      if type(extra) == 'table' and extra.data then
        local suffix = extra.suffix or '.extra.json'
        local extra_path = 'output/' .. filename .. suffix
        write_file(extra_path, Json.encode(extra.data, true))
      end
    end
  end
  local total = 0
  local func_count = 0
  local global_count = 0
  for _, entry in ipairs(analyzer.all_locals) do
    total = total + 1
    if entry.is_in_function then
      func_count = func_count + 1
    else
      global_count = global_count + 1
    end
  end
  io.stderr:write('total local variables: ' .. total .. '\n')
  io.stderr:write('in functions: ' .. func_count .. '\n')
  io.stderr:write('global: ' .. global_count .. '\n')
end

main()
