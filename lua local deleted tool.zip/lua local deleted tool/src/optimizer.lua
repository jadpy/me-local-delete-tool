local AST = require('src.ast')

local Optimizer = {}

local function truthy(v)
  return not (v == false or v == nil)
end

local function const_value(node)
  if not node or type(node) ~= 'table' then
    return false, nil
  end
  if node.type == 'Number' then
    return true, node.value
  end
  if node.type == 'String' then
    return true, node.value
  end
  if node.type == 'Boolean' then
    return true, node.value
  end
  if node.type == 'Nil' then
    return true, nil
  end
  return false, nil
end

local function literal_from_value(v)
  local tv = type(v)
  if tv == 'number' then
    return AST.Number(v)
  end
  if tv == 'string' then
    return AST.String(v)
  end
  if tv == 'boolean' then
    return AST.Boolean(v)
  end
  if v == nil then
    return AST.Nil()
  end
  return nil
end

local function eval_binary(op, a, b)
  if op == '+' then return a + b end
  if op == '-' then return a - b end
  if op == '*' then return a * b end
  if op == '/' then return a / b end
  if op == '//' then return a // b end
  if op == '%' then return a % b end
  if op == '^' then return a ^ b end
  if op == '..' then return a .. b end
  if op == '<' then return a < b end
  if op == '<=' then return a <= b end
  if op == '>' then return a > b end
  if op == '>=' then return a >= b end
  if op == '==' then return a == b end
  if op == '~=' then return a ~= b end
  if op == 'and' then
    if truthy(a) then return b end
    return a
  end
  if op == 'or' then
    if truthy(a) then return a end
    return b
  end
  return nil
end

local optimize_expr
local optimize_block
local optimize_stmt

optimize_expr = function(node)
  if not node or type(node) ~= 'table' then
    return node
  end
  local t = node.type

  if t == 'BinaryOp' then
    node.left = optimize_expr(node.left)
    node.right = optimize_expr(node.right)

    local left_const, left_val = const_value(node.left)
    local right_const, right_val = const_value(node.right)

    if node.op == 'and' and left_const then
      if truthy(left_val) then
        return node.right
      end
      return literal_from_value(left_val) or node
    end

    if node.op == 'or' and left_const then
      if truthy(left_val) then
        return literal_from_value(left_val) or node
      end
      return node.right
    end

    if left_const and right_const then
      local ok, result = pcall(eval_binary, node.op, left_val, right_val)
      if ok then
        local lit = literal_from_value(result)
        if lit then
          return lit
        end
      end
    end
    return node
  end

  if t == 'UnaryOp' then
    node.operand = optimize_expr(node.operand)
    local is_const, value = const_value(node.operand)
    if is_const then
      if node.op == 'not' then
        return AST.Boolean(not truthy(value))
      end
      if node.op == '-' and type(value) == 'number' then
        return AST.Number(-value)
      end
      if node.op == '#' and type(value) == 'string' then
        return AST.Number(#value)
      end
    end
    return node
  end

  if t == 'FunctionCall' then
    node.callee = optimize_expr(node.callee)
    for i, arg in ipairs(node.args or {}) do
      node.args[i] = optimize_expr(arg)
    end
    return node
  end

  if t == 'MethodCall' then
    node.object = optimize_expr(node.object)
    for i, arg in ipairs(node.args or {}) do
      node.args[i] = optimize_expr(arg)
    end
    return node
  end

  if t == 'IndexExpr' then
    node.object = optimize_expr(node.object)
    node.index = optimize_expr(node.index)
    return node
  end

  if t == 'PropertyExpr' then
    node.object = optimize_expr(node.object)
    return node
  end

  if t == 'Table' then
    for _, field in ipairs(node.fields or {}) do
      if field.key then
        field.key = optimize_expr(field.key)
      end
      field.value = optimize_expr(field.value)
    end
    return node
  end

  if t == 'Function' then
    node.body = optimize_block(node.body)
    return node
  end

  return node
end

local function simplify_if_node(node)
  node.condition = optimize_expr(node.condition)
  node.then_body = optimize_block(node.then_body)
  if node.else_body then
    node.else_body = optimize_block(node.else_body)
  end
  for _, p in ipairs(node.elseif_parts or {}) do
    p.condition = optimize_expr(p.condition)
    p.body = optimize_block(p.body)
  end

  local cond_const, cond_val = const_value(node.condition)
  if cond_const then
    if truthy(cond_val) then
      return node.then_body.statements or {}
    end

    local parts = node.elseif_parts or {}
    for i = 1, #parts do
      local part = parts[i]
      local cst, v = const_value(part.condition)
      if cst then
        if truthy(v) then
          return part.body.statements or {}
        end
      else
        node.condition = part.condition
        node.then_body = part.body
        local rest = {}
        local forced_else = nil
        for j = i + 1, #parts do
          local q = parts[j]
          local qcst, qv = const_value(q.condition)
          if qcst then
            if truthy(qv) then
              forced_else = q.body
              break
            end
          else
            rest[#rest + 1] = q
          end
        end
        node.elseif_parts = rest
        if forced_else then
          node.else_body = forced_else
        end
        return { node }
      end
    end

    if node.else_body then
      return node.else_body.statements or {}
    end
    return {}
  end

  local filtered = {}
  local forced_else = nil
  for _, part in ipairs(node.elseif_parts or {}) do
    local cst, v = const_value(part.condition)
    if cst then
      if truthy(v) then
        forced_else = part.body
        break
      end
    else
      filtered[#filtered + 1] = part
    end
  end
  node.elseif_parts = filtered
  if forced_else then
    node.else_body = forced_else
  end

  return { node }
end

optimize_stmt = function(node)
  if not node or type(node) ~= 'table' then
    return {}
  end

  local t = node.type

  if t == 'LocalDecl' then
    for i, v in ipairs(node.values or {}) do
      node.values[i] = optimize_expr(v)
    end
    return { node }
  end

  if t == 'Assignment' then
    for i, target in ipairs(node.targets or {}) do
      node.targets[i] = optimize_expr(target)
    end
    for i, v in ipairs(node.values or {}) do
      node.values[i] = optimize_expr(v)
    end
    return { node }
  end

  if t == 'Return' then
    for i, v in ipairs(node.values or {}) do
      node.values[i] = optimize_expr(v)
    end
    return { node }
  end

  if t == 'If' then
    return simplify_if_node(node)
  end

  if t == 'While' then
    node.condition = optimize_expr(node.condition)
    node.body = optimize_block(node.body)
    local cst, v = const_value(node.condition)
    if cst and not truthy(v) then
      return {}
    end
    return { node }
  end

  if t == 'Repeat' then
    node.body = optimize_block(node.body)
    node.condition = optimize_expr(node.condition)
    return { node }
  end

  if t == 'For' then
    node.start = optimize_expr(node.start)
    node.finish = optimize_expr(node.finish)
    if node.step then
      node.step = optimize_expr(node.step)
    end
    node.body = optimize_block(node.body)
    return { node }
  end

  if t == 'ForIn' then
    for i, v in ipairs(node.iterators or {}) do
      node.iterators[i] = optimize_expr(v)
    end
    node.body = optimize_block(node.body)
    return { node }
  end

  if t == 'Do' then
    node.body = optimize_block(node.body)
    if not node.body.statements or #node.body.statements == 0 then
      return {}
    end
    return { node }
  end

  if t == 'LocalFunc' then
    if node.body and node.body.body then
      node.body.body = optimize_block(node.body.body)
    end
    return { node }
  end

  if t == 'FunctionDecl' then
    if node.body then
      node.body = optimize_block(node.body)
    end
    return { node }
  end

  if t == 'FunctionCall' or t == 'MethodCall' then
    return { optimize_expr(node) }
  end

  return { node }
end

optimize_block = function(block)
  if not block or type(block) ~= 'table' then
    return block
  end
  local out = {}
  for _, stmt in ipairs(block.statements or {}) do
    local repl = optimize_stmt(stmt)
    for _, s in ipairs(repl or {}) do
      out[#out + 1] = s
      if s.type == 'Return' or s.type == 'Break' then
        block.statements = out
        return block
      end
    end
  end
  block.statements = out
  return block
end

function Optimizer.optimize(chunk)
  if not chunk or type(chunk) ~= 'table' then
    return chunk
  end
  if chunk.type == 'Chunk' and chunk.body then
    chunk.body = optimize_block(chunk.body)
  end
  return chunk
end

return Optimizer
