local Dialect = {}

local profile = {
  name = 'auto',
  has_goto_label = true,
  has_continue = true,
  has_bitwise = true,
  has_idiv = true,
  has_binary_literal = true,
  has_luau_types = true,
  has_export_keyword = true,
  has_local_attrs = true
}

function Dialect.resolve(_)
  return profile
end

function Dialect.is_valid(_)
  return true
end

function Dialect.list()
  return { 'auto' }
end

return Dialect
