local Parser = require('src.parser')

local TransformerLine = {}

local metadata_fields = {
  source_line = true,
  local_token = true,
  name_token = true,
  name_tokens = true,
  param_tokens = true,
  token = true
}

local statement_types = {
  LocalDecl = true,
  LocalFunc = true,
  FunctionDecl = true,
  If = true,
  While = true,
  Repeat = true,
  For = true,
  ForIn = true,
  Do = true,
  Assignment = true,
  Return = true,
  Break = true,
  Goto = true,
  Label = true
}

local function scope_match(scope, in_function)
  if scope == 'all' then
    return true
  end
  if scope == 'function' then
    return in_function
  end
  if scope == 'global' then
    return not in_function
  end
  return false
end

local function get_scope_mode(mode, base)
  if mode == base .. '_all' then
    return 'all'
  end
  if mode == base .. '_function' then
    return 'function'
  end
  if mode == base .. '_global' then
    return 'global'
  end
  return nil
end

local function decl_values_match_type(node, expected_type)
  local names = node.names or {}
  local values = node.values or {}
  if #names == 0 then
    return false
  end
  if #values == 0 then
    return false
  end

  local function is_number_expr(expr)
    if not expr or type(expr) ~= 'table' then
      return false
    end
    if expr.type == 'Number' then
      return true
    end
    if expr.type == 'UnaryOp' and (expr.op == '-' or expr.op == '+') then
      return expr.operand and expr.operand.type == 'Number'
    end
    return false
  end

  for i = 1, #values do
    local v = values[i]
    if expected_type == 'Number' then
      if not is_number_expr(v) then
        return false
      end
    else
      if not v or v.type ~= expected_type then
        return false
      end
    end
  end
  return true
end

local function is_statement_starter(tok)
  if not tok or tok.type == nil then
    return false
  end
  local t = tok.type
  return t == 'LOCAL' or t == 'FUNCTION' or t == 'IF' or t == 'WHILE'
    or t == 'REPEAT' or t == 'FOR' or t == 'DO' or t == 'BREAK'
    or t == 'RETURN' or t == 'GOTO' or t == 'CONTINUE'
end

local function has_function_scope(stack)
  for i = #stack, 1, -1 do
    if stack[i] == 'function' then
      return true
    end
  end
  return false
end

local function push_block(stack, kind)
  stack[#stack + 1] = kind
end

local function pop_non_repeat(stack)
  for i = #stack, 1, -1 do
    if stack[i] ~= 'repeat' then
      table.remove(stack, i)
      return
    end
  end
end

local function pop_repeat(stack)
  for i = #stack, 1, -1 do
    if stack[i] == 'repeat' then
      table.remove(stack, i)
      return
    end
  end
end

local function classify_simple_expr(tokens, start_idx, end_idx)
  if start_idx > end_idx then
    return 'Other'
  end
  local first = tokens[start_idx]
  if not first then
    return 'Other'
  end
  if (first.type == 'TRUE' or first.type == 'FALSE') and start_idx == end_idx then
    return 'Boolean'
  end
  if first.type == 'STRING' and start_idx == end_idx then
    return 'String'
  end
  if first.type == 'NUMBER' and start_idx == end_idx then
    return 'Number'
  end
  if (first.type == 'MINUS' or first.type == 'PLUS')
    and start_idx + 1 == end_idx
    and tokens[start_idx + 1]
    and tokens[start_idx + 1].type == 'NUMBER' then
    return 'Number'
  end
  if first.type == 'LBRACE' and tokens[end_idx] and tokens[end_idx].type == 'RBRACE' then
    local depth = 0
    for i = start_idx, end_idx do
      local tt = tokens[i].type
      if tt == 'LBRACE' then
        depth = depth + 1
      elseif tt == 'RBRACE' then
        depth = depth - 1
        if depth < 0 then
          return 'Other'
        end
      end
    end
    if depth == 0 then
      return 'Table'
    end
  end
  return 'Other'
end

local function scan_expression_end(tokens, start_idx)
  local paren = 0
  local bracket = 0
  local brace = 0
  local i = start_idx
  while i <= #tokens do
    local tok = tokens[i]
    if not tok then
      break
    end
    local t = tok.type
    if t == 'LPAREN' then
      paren = paren + 1
    elseif t == 'RPAREN' then
      if paren == 0 then
        break
      end
      paren = paren - 1
    elseif t == 'LBRACKET' then
      bracket = bracket + 1
    elseif t == 'RBRACKET' then
      if bracket == 0 then
        break
      end
      bracket = bracket - 1
    elseif t == 'LBRACE' then
      brace = brace + 1
    elseif t == 'RBRACE' then
      if brace == 0 then
        break
      end
      brace = brace - 1
    elseif paren == 0 and bracket == 0 and brace == 0 then
      if t == 'COMMA' or t == 'SEMICOLON' or t == 'EOF'
        or t == 'END' or t == 'ELSE' or t == 'ELSEIF' or t == 'UNTIL' then
        break
      end
      if is_statement_starter(tok) then
        break
      end
    end
    i = i + 1
  end
  return i
end

local function parse_local_value_types(tokens, start_idx)
  local types = {}
  local i = start_idx
  while i <= #tokens do
    local tok = tokens[i]
    if not tok then
      break
    end
    local t = tok.type
    if t == 'SEMICOLON' or t == 'EOF' or t == 'END' or t == 'ELSE' or t == 'ELSEIF' or t == 'UNTIL' then
      break
    end
    if is_statement_starter(tok) then
      break
    end
    local expr_end = scan_expression_end(tokens, i)
    local expr_type = classify_simple_expr(tokens, i, expr_end - 1)
    types[#types + 1] = expr_type
    local stop = tokens[expr_end]
    if not stop or stop.type ~= 'COMMA' then
      return types, expr_end
    end
    i = expr_end + 1
  end
  return types, i
end

local function token_decl_match_type(value_types, expected_type)
  if #value_types == 0 then
    return false
  end
  for i = 1, #value_types do
    if value_types[i] ~= expected_type then
      return false
    end
  end
  return true
end

local function is_local_statement(node)
  return node and (node.type == 'LocalDecl' or node.type == 'LocalFunc')
end

local function is_function_local_form(node)
  if not node then
    return false
  end
  if node.type == 'LocalFunc' then
    return true
  end
  if node.type == 'LocalDecl' then
    return decl_values_match_type(node, 'Function')
  end
  return false
end

local function should_remove_local(node, mode, in_function)
  if not is_local_statement(node) then
    return false
  end

  if mode == 'remove_all_local' then
    return true
  end
  if mode == 'remove_global_local' then
    return not in_function
  end

  local fn_scope = get_scope_mode(mode, 'remove_function_local')
  if mode == 'remove_function_local' then
    fn_scope = 'function'
  end
  if fn_scope then
    return is_function_local_form(node) and scope_match(fn_scope, in_function)
  end

  local kw_scope = get_scope_mode(mode, 'remove_local_keyword')
  if kw_scope then
    return scope_match(kw_scope, in_function)
  end

  local bool_scope = get_scope_mode(mode, 'remove_local_boolean')
  if bool_scope then
    return node.type == 'LocalDecl'
      and decl_values_match_type(node, 'Boolean')
      and scope_match(bool_scope, in_function)
  end

  local str_scope = get_scope_mode(mode, 'remove_local_string')
  if str_scope then
    return node.type == 'LocalDecl'
      and decl_values_match_type(node, 'String')
      and scope_match(str_scope, in_function)
  end

  local num_scope = get_scope_mode(mode, 'remove_local_number')
  if num_scope then
    return node.type == 'LocalDecl'
      and decl_values_match_type(node, 'Number')
      and scope_match(num_scope, in_function)
  end

  local table_scope = get_scope_mode(mode, 'remove_local_table')
  if table_scope then
    return node.type == 'LocalDecl'
      and decl_values_match_type(node, 'Table')
      and scope_match(table_scope, in_function)
  end

  return false
end

local walk_expr
local walk_stmt
local walk_block
local walk_dynamic
local walk_unknown_fields

local function split_lines_preserve_layout(source)
  local lines = {}
  local start = 1
  while true do
    local nl = source:find('\n', start, true)
    if not nl then
      table.insert(lines, source:sub(start))
      break
    end
    table.insert(lines, source:sub(start, nl - 1))
    start = nl + 1
  end
  return lines
end

local function mark_seen(seen, node)
  seen = seen or {}
  if seen[node] then
    return seen, true
  end
  seen[node] = true
  return seen, false
end

walk_dynamic = function(value, in_function, callback, seen)
  if type(value) ~= 'table' then
    return
  end
  local t = value.type
  if t == 'Block' then
    walk_block(value, in_function, callback, seen)
    return
  end
  if t and statement_types[t] then
    walk_stmt(value, in_function, callback, seen)
    return
  end
  if t then
    walk_expr(value, in_function, callback, seen)
    return
  end
  local already
  seen, already = mark_seen(seen, value)
  if already then
    return
  end
  for _, child in pairs(value) do
    walk_dynamic(child, in_function, callback, seen)
  end
end

walk_unknown_fields = function(node, in_function, callback, seen)
  for key, child in pairs(node) do
    if not metadata_fields[key] then
      walk_dynamic(child, in_function, callback, seen)
    end
  end
end

walk_expr = function(node, in_function, callback, seen)
  if not node or type(node) ~= 'table' then
    return
  end
  local already
  seen, already = mark_seen(seen, node)
  if already then
    return
  end
  local t = node.type
  if t == 'Function' then
    walk_block(node.body, true, callback, seen)
    return
  end
  if t == 'BinaryOp' then
    walk_expr(node.left, in_function, callback, seen)
    walk_expr(node.right, in_function, callback, seen)
    return
  end
  if t == 'UnaryOp' then
    walk_expr(node.operand, in_function, callback, seen)
    return
  end
  if t == 'FunctionCall' then
    walk_expr(node.callee, in_function, callback, seen)
    for _, arg in ipairs(node.args or {}) do
      walk_expr(arg, in_function, callback, seen)
    end
    return
  end
  if t == 'MethodCall' then
    walk_expr(node.object, in_function, callback, seen)
    for _, arg in ipairs(node.args or {}) do
      walk_expr(arg, in_function, callback, seen)
    end
    return
  end
  if t == 'IndexExpr' then
    walk_expr(node.object, in_function, callback, seen)
    walk_expr(node.index, in_function, callback, seen)
    return
  end
  if t == 'PropertyExpr' then
    walk_expr(node.object, in_function, callback, seen)
    return
  end
  if t == 'Table' then
    for _, field in ipairs(node.fields or {}) do
      if field.key then
        walk_expr(field.key, in_function, callback, seen)
      end
      walk_expr(field.value, in_function, callback, seen)
    end
    return
  end
  walk_unknown_fields(node, in_function, callback, seen)
end

walk_stmt = function(node, in_function, callback, seen)
  if not node then
    return
  end
  local already
  seen, already = mark_seen(seen, node)
  if already then
    return
  end

  callback(node, in_function)

  local t = node.type
  if t == 'LocalDecl' then
    for _, value in ipairs(node.values or {}) do
      walk_expr(value, in_function, callback, seen)
    end
    return
  end
  if t == 'LocalFunc' then
    if node.body and node.body.type == 'Block' then
      walk_block(node.body, true, callback, seen)
    else
      walk_expr(node.body, true, callback, seen)
    end
    return
  end
  if t == 'FunctionDecl' then
    walk_block(node.body, true, callback, seen)
    return
  end
  if t == 'If' then
    walk_expr(node.condition, in_function, callback, seen)
    walk_block(node.then_body, in_function, callback, seen)
    for _, part in ipairs(node.elseif_parts or {}) do
      walk_expr(part.condition, in_function, callback, seen)
      walk_block(part.body, in_function, callback, seen)
    end
    if node.else_body then
      walk_block(node.else_body, in_function, callback, seen)
    end
    return
  end
  if t == 'While' then
    walk_expr(node.condition, in_function, callback, seen)
    walk_block(node.body, in_function, callback, seen)
    return
  end
  if t == 'Repeat' then
    walk_block(node.body, in_function, callback, seen)
    walk_expr(node.condition, in_function, callback, seen)
    return
  end
  if t == 'For' then
    walk_expr(node.start, in_function, callback, seen)
    walk_expr(node.finish, in_function, callback, seen)
    if node.step then
      walk_expr(node.step, in_function, callback, seen)
    end
    walk_block(node.body, in_function, callback, seen)
    return
  end
  if t == 'ForIn' then
    for _, iter in ipairs(node.iterators or {}) do
      walk_expr(iter, in_function, callback, seen)
    end
    walk_block(node.body, in_function, callback, seen)
    return
  end
  if t == 'Do' then
    walk_block(node.body, in_function, callback, seen)
    return
  end
  if t == 'Assignment' then
    for _, target in ipairs(node.targets or {}) do
      walk_expr(target, in_function, callback, seen)
    end
    for _, value in ipairs(node.values or {}) do
      walk_expr(value, in_function, callback, seen)
    end
    return
  end
  if t == 'Return' then
    for _, value in ipairs(node.values or {}) do
      walk_expr(value, in_function, callback, seen)
    end
    return
  end
  walk_unknown_fields(node, in_function, callback, seen)
end

walk_block = function(block, in_function, callback, seen)
  if not block then
    return
  end
  local already
  seen, already = mark_seen(seen, block)
  if already then
    return
  end
  for _, stmt in ipairs(block.statements or {}) do
    walk_stmt(stmt, in_function, callback, seen)
  end
end

function TransformerLine.new(source, tokens, options)
  local self = {
    source = source,
    lines = split_lines_preserve_layout(source),
    tokens = tokens,
    options = options or {},
    replacements = {}
  }
  return setmetatable(self, { __index = TransformerLine })
end

function TransformerLine:remove_local_at_col(line, col)
  if type(line) ~= 'string' or line == '' then
    return line
  end
  if type(col) ~= 'number' then
    col = 1
  end
  col = math.max(1, math.min(#line + 1, col))
  local before = line:sub(1, col - 1)
  local rest = line:sub(col)

  local newrest, n = rest:gsub('^local%f[^%w_]%s*', '', 1)
  if n == 0 then
    newrest, n = rest:gsub('^%s+local%f[^%w_]%s*', '', 1)
  end
  if n == 0 then
    return line
  end
  return before .. newrest
end

function TransformerLine:collect_local_removals(mode)
  local removals = {}
  local ok, ast = pcall(function()
    local parser = Parser.new(self.tokens, { dialect = self.options.dialect })
    return parser:parse()
  end)
  if ok and ast and ast.body then
    local function callback(stmt, in_function)
      if not should_remove_local(stmt, mode, in_function) then
        return
      end
      local tok = stmt.local_token
      if not tok or type(tok.line) ~= 'number' or type(tok.col) ~= 'number' then
        return
      end
      if tok.line < 1 or tok.line > #self.lines then
        return
      end
      removals[tok.line] = removals[tok.line] or {}
      table.insert(removals[tok.line], tok.col)
    end

    walk_block(ast.body, false, callback, {})
    return removals
  end

  local tokens = self.tokens or {}
  local stack = {}
  local i = 1
  while i <= #tokens do
    local tok = tokens[i]
    local in_function = has_function_scope(stack)

    if tok and tok.type == 'LOCAL' then
      local should_remove = false
      local next_tok = tokens[i + 1]
      if next_tok and next_tok.type == 'FUNCTION' then
        local fn_scope = get_scope_mode(mode, 'remove_function_local')
        if mode == 'remove_function_local' then
          fn_scope = 'function'
        end
        local kw_scope = get_scope_mode(mode, 'remove_local_keyword')
        if mode == 'remove_all_local' then
          should_remove = true
        elseif mode == 'remove_global_local' then
          should_remove = not in_function
        elseif fn_scope then
          should_remove = scope_match(fn_scope, in_function)
        elseif kw_scope then
          should_remove = scope_match(kw_scope, in_function)
        end
      else
        local j = i + 1
        if tokens[j] and tokens[j].type == 'IDENT' then
          j = j + 1
          while tokens[j] and tokens[j].type == 'COMMA' and tokens[j + 1] and tokens[j + 1].type == 'IDENT' do
            j = j + 2
          end

          local value_types = {}
          if tokens[j] and tokens[j].type == 'ASSIGN' then
            value_types, j = parse_local_value_types(tokens, j + 1)
          end

          local kw_scope = get_scope_mode(mode, 'remove_local_keyword')
          local bool_scope = get_scope_mode(mode, 'remove_local_boolean')
          local str_scope = get_scope_mode(mode, 'remove_local_string')
          local num_scope = get_scope_mode(mode, 'remove_local_number')
          local table_scope = get_scope_mode(mode, 'remove_local_table')
          if mode == 'remove_all_local' then
            should_remove = true
          elseif mode == 'remove_global_local' then
            should_remove = not in_function
          elseif kw_scope then
            should_remove = scope_match(kw_scope, in_function)
          elseif bool_scope then
            should_remove = scope_match(bool_scope, in_function) and token_decl_match_type(value_types, 'Boolean')
          elseif str_scope then
            should_remove = scope_match(str_scope, in_function) and token_decl_match_type(value_types, 'String')
          elseif num_scope then
            should_remove = scope_match(num_scope, in_function) and token_decl_match_type(value_types, 'Number')
          elseif table_scope then
            should_remove = scope_match(table_scope, in_function) and token_decl_match_type(value_types, 'Table')
          end
          i = j - 1
        end
      end

      if should_remove and type(tok.line) == 'number' and type(tok.col) == 'number'
        and tok.line >= 1 and tok.line <= #self.lines then
        removals[tok.line] = removals[tok.line] or {}
        table.insert(removals[tok.line], tok.col)
      end
    end

    if tok then
      local t = tok.type
      if t == 'FUNCTION' then
        push_block(stack, 'function')
      elseif t == 'DO' then
        push_block(stack, 'do')
      elseif t == 'THEN' then
        push_block(stack, 'if')
      elseif t == 'REPEAT' then
        push_block(stack, 'repeat')
      elseif t == 'END' then
        pop_non_repeat(stack)
      elseif t == 'UNTIL' then
        pop_repeat(stack)
      end
    end
    i = i + 1
  end

  return removals
end

function TransformerLine:apply()
  local mode = self.options.mode or 'remove_function_local'

  if mode == 'outcode' then
    local out_lines = {}
    local i = 1

    local function strip_inline_comment(line)
      local res = {}
      local in_str = false
      local qchar = nil
      local esc = false
      local n = #line
      local idx = 1
      while idx <= n do
        local ch = line:sub(idx, idx)
        if in_str then
          if esc then
            esc = false
            table.insert(res, ch)
          elseif ch == '\\' then
            esc = true
            table.insert(res, ch)
          elseif ch == qchar then
            in_str = false
            qchar = nil
            table.insert(res, ch)
          else
            table.insert(res, ch)
          end
          idx = idx + 1
        else
          if ch == '"' or ch == "'" then
            in_str = true
            qchar = ch
            table.insert(res, ch)
            idx = idx + 1
          else
            local two = line:sub(idx, idx + 1)
            if two == '--' then
              break
            else
              table.insert(res, ch)
              idx = idx + 1
            end
          end
        end
      end
      return table.concat(res)
    end

    while i <= #self.lines do
      local line = self.lines[i]
      local s = line:match('^(%s*)%-%-%[%[')
      if s then
        local j = i
        local found = false
        while j <= #self.lines do
          if self.lines[j]:find('%]%]') then
            found = true
            break
          end
          j = j + 1
        end
        if found then
          i = j + 1
        else
          break
        end
      else
        local trimmed = line:match('^%s*(.*)') or ''
        if trimmed:sub(1, 2) ~= '--' then
          local newl = strip_inline_comment(line)
          newl = newl:gsub('%s+$', '')
          table.insert(out_lines, newl)
        end
        i = i + 1
      end
    end

    return table.concat(out_lines, '\n')
  end

  local removals = self:collect_local_removals(mode)
  for line_no, cols in pairs(removals) do
    table.sort(cols, function(a, b) return a > b end)
    local text = self.lines[line_no] or ''
    for _, col in ipairs(cols) do
      text = self:remove_local_at_col(text, col)
    end
    self.replacements[line_no] = text
  end

  local out = {}
  for idx, ln in ipairs(self.lines) do
    if self.replacements[idx] then
      table.insert(out, self.replacements[idx])
    else
      table.insert(out, ln)
    end
  end
  return table.concat(out, '\n')
end

return TransformerLine
