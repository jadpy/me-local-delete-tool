local LintDynamic = {}
local LintSandbox = require('src.lint_sandbox')
local Lexer = require('src.lexer')
local Parser = require('src.parser')
local CodeGen = require('src.codegen')
local AST = require('src.ast')

local TIMEOUT_SENTINEL = '__LINT_DYNAMIC_TIMEOUT__'

local function summarize_key_counts(map, max_items)
  local out = {}
  for k, v in pairs(map or {}) do
    out[#out + 1] = { name = tostring(k), count = tonumber(v) or 0 }
  end
  table.sort(out, function(a, b)
    if a.count ~= b.count then
      return a.count > b.count
    end
    return a.name < b.name
  end)
  local total_keys = #out
  local omitted = 0
  if max_items and max_items > 0 and #out > max_items then
    omitted = #out - max_items
    for i = #out, max_items + 1, -1 do
      out[i] = nil
    end
  end
  return out, total_keys, omitted
end

local function summarize_events(events, max_items)
  local out = {}
  for _, e in ipairs(events or {}) do
    out[#out + 1] = {
      level = tostring(e.level or 'info'),
      code = tostring(e.code or 'sandbox-event'),
      message = tostring(e.message or ''),
      count = tonumber(e.count) or 0
    }
  end
  table.sort(out, function(a, b)
    if a.count ~= b.count then
      return a.count > b.count
    end
    if a.level ~= b.level then
      return a.level < b.level
    end
    if a.code ~= b.code then
      return a.code < b.code
    end
    return a.message < b.message
  end)
  local total = #out
  local omitted = 0
  if max_items and max_items > 0 and #out > max_items then
    omitted = #out - max_items
    for i = #out, max_items + 1, -1 do
      out[i] = nil
    end
  end
  return out, total, omitted
end

local function summarize_history(history, total, omitted, max_items)
  local src = history or {}
  local out = {}
  local maxn = max_items and max_items > 0 and max_items or #src
  for i = 1, math.min(#src, maxn) do
    local h = src[i]
    out[#out + 1] = {
      seq = tonumber(h.seq) or i,
      kind = tostring(h.kind or 'event'),
      message = tostring(h.message or '')
    }
  end
  local total_count = tonumber(total) or #src
  local omitted_count = tonumber(omitted) or 0
  if #src > #out then
    omitted_count = omitted_count + (#src - #out)
  end
  return out, total_count, omitted_count
end

local function load_chunk(source, chunk_name, env)
  if type(load) == 'function' then
    return load(source, chunk_name, 't', env)
  end
  if type(loadstring) == 'function' then
    local fn, err = loadstring(source, chunk_name)
    if not fn then
      return nil, err
    end
    if type(setfenv) == 'function' then
      setfenv(fn, env)
    end
    return fn
  end
  return nil, 'no load function available'
end

local function has_continue_in_expr(node)
  if not node or type(node) ~= 'table' then
    return false
  end
  local t = node.type
  if t == 'Function' then
    return has_continue_in_expr(node.body)
  end
  if t == 'Block' then
    for _, stmt in ipairs(node.statements or {}) do
      if has_continue_in_expr(stmt) then
        return true
      end
    end
    return false
  end
  if t == 'BinaryOp' then
    return has_continue_in_expr(node.left) or has_continue_in_expr(node.right)
  end
  if t == 'UnaryOp' then
    return has_continue_in_expr(node.operand)
  end
  if t == 'FunctionCall' then
    if has_continue_in_expr(node.callee) then
      return true
    end
    for _, arg in ipairs(node.args or {}) do
      if has_continue_in_expr(arg) then
        return true
      end
    end
    return false
  end
  if t == 'MethodCall' then
    if has_continue_in_expr(node.object) then
      return true
    end
    for _, arg in ipairs(node.args or {}) do
      if has_continue_in_expr(arg) then
        return true
      end
    end
    return false
  end
  if t == 'IndexExpr' then
    return has_continue_in_expr(node.object) or has_continue_in_expr(node.index)
  end
  if t == 'PropertyExpr' then
    return has_continue_in_expr(node.object)
  end
  if t == 'Table' then
    for _, field in ipairs(node.fields or {}) do
      if has_continue_in_expr(field.key) or has_continue_in_expr(field.value) then
        return true
      end
    end
    return false
  end
  if t == 'Chunk' then
    return has_continue_in_expr(node.body)
  end
  if t == 'If' then
    if has_continue_in_expr(node.condition) or has_continue_in_expr(node.then_body) or has_continue_in_expr(node.else_body) then
      return true
    end
    for _, part in ipairs(node.elseif_parts or {}) do
      if has_continue_in_expr(part.condition) or has_continue_in_expr(part.body) then
        return true
      end
    end
    return false
  end
  if t == 'While' then
    return has_continue_in_expr(node.condition) or has_continue_in_expr(node.body)
  end
  if t == 'Repeat' then
    return has_continue_in_expr(node.body) or has_continue_in_expr(node.condition)
  end
  if t == 'For' then
    return has_continue_in_expr(node.start) or has_continue_in_expr(node.finish) or has_continue_in_expr(node.step) or has_continue_in_expr(node.body)
  end
  if t == 'ForIn' then
    for _, it in ipairs(node.iterators or {}) do
      if has_continue_in_expr(it) then
        return true
      end
    end
    return has_continue_in_expr(node.body)
  end
  if t == 'LocalDecl' then
    for _, v in ipairs(node.values or {}) do
      if has_continue_in_expr(v) then
        return true
      end
    end
    return false
  end
  if t == 'LocalFunc' then
    return has_continue_in_expr(node.body)
  end
  if t == 'FunctionDecl' then
    return has_continue_in_expr(node.body)
  end
  if t == 'Assignment' then
    for _, v in ipairs(node.targets or {}) do
      if has_continue_in_expr(v) then
        return true
      end
    end
    for _, v in ipairs(node.values or {}) do
      if has_continue_in_expr(v) then
        return true
      end
    end
    return false
  end
  if t == 'Return' then
    for _, v in ipairs(node.values or {}) do
      if has_continue_in_expr(v) then
        return true
      end
    end
    return false
  end
  if t == 'Do' then
    return has_continue_in_expr(node.body)
  end
  if t == 'Continue' then
    return true
  end
  return false
end

local function new_continue_label(state)
  state.counter = state.counter + 1
  return '__lint_continue_' .. tostring(state.counter)
end

local lower_continue_expr
local lower_continue_stmt
local lower_continue_block

lower_continue_expr = function(node, state)
  if not node or type(node) ~= 'table' then
    return false
  end
  local t = node.type
  local changed = false

  if t == 'Function' then
    changed = lower_continue_block(node.body, state, nil) or changed
    return changed
  end

  if t == 'BinaryOp' then
    changed = lower_continue_expr(node.left, state) or changed
    changed = lower_continue_expr(node.right, state) or changed
  elseif t == 'UnaryOp' then
    changed = lower_continue_expr(node.operand, state) or changed
  elseif t == 'FunctionCall' then
    changed = lower_continue_expr(node.callee, state) or changed
    for _, arg in ipairs(node.args or {}) do
      changed = lower_continue_expr(arg, state) or changed
    end
  elseif t == 'MethodCall' then
    changed = lower_continue_expr(node.object, state) or changed
    for _, arg in ipairs(node.args or {}) do
      changed = lower_continue_expr(arg, state) or changed
    end
  elseif t == 'IndexExpr' then
    changed = lower_continue_expr(node.object, state) or changed
    changed = lower_continue_expr(node.index, state) or changed
  elseif t == 'PropertyExpr' then
    changed = lower_continue_expr(node.object, state) or changed
  elseif t == 'Table' then
    for _, field in ipairs(node.fields or {}) do
      changed = lower_continue_expr(field.key, state) or changed
      changed = lower_continue_expr(field.value, state) or changed
    end
  end

  return changed
end

lower_continue_stmt = function(node, state, continue_label)
  if not node or type(node) ~= 'table' then
    return false
  end

  local t = node.type
  local changed = false

  if t == 'Continue' then
    if continue_label then
      node.type = 'Goto'
      node.label = continue_label
    else
      node.type = 'Break'
    end
    return true
  end

  if t == 'If' then
    changed = lower_continue_expr(node.condition, state) or changed
    changed = lower_continue_block(node.then_body, state, continue_label) or changed
    for _, part in ipairs(node.elseif_parts or {}) do
      changed = lower_continue_expr(part.condition, state) or changed
      changed = lower_continue_block(part.body, state, continue_label) or changed
    end
    changed = lower_continue_block(node.else_body, state, continue_label) or changed
    return changed
  end

  if t == 'While' then
    changed = lower_continue_expr(node.condition, state) or changed
    local label = new_continue_label(state)
    changed = lower_continue_block(node.body, state, label) or changed
    if node.body and node.body.statements then
      node.body.statements[#node.body.statements + 1] = AST.Label(label)
      changed = true
    end
    return changed
  end

  if t == 'Repeat' then
    local label = new_continue_label(state)
    changed = lower_continue_block(node.body, state, label) or changed
    if node.body and node.body.statements then
      node.body.statements[#node.body.statements + 1] = AST.Label(label)
      changed = true
    end
    changed = lower_continue_expr(node.condition, state) or changed
    return changed
  end

  if t == 'For' then
    changed = lower_continue_expr(node.start, state) or changed
    changed = lower_continue_expr(node.finish, state) or changed
    changed = lower_continue_expr(node.step, state) or changed
    local label = new_continue_label(state)
    changed = lower_continue_block(node.body, state, label) or changed
    if node.body and node.body.statements then
      node.body.statements[#node.body.statements + 1] = AST.Label(label)
      changed = true
    end
    return changed
  end

  if t == 'ForIn' then
    for _, it in ipairs(node.iterators or {}) do
      changed = lower_continue_expr(it, state) or changed
    end
    local label = new_continue_label(state)
    changed = lower_continue_block(node.body, state, label) or changed
    if node.body and node.body.statements then
      node.body.statements[#node.body.statements + 1] = AST.Label(label)
      changed = true
    end
    return changed
  end

  if t == 'Do' then
    changed = lower_continue_block(node.body, state, continue_label) or changed
    return changed
  end

  if t == 'LocalDecl' then
    for _, v in ipairs(node.values or {}) do
      changed = lower_continue_expr(v, state) or changed
    end
    return changed
  end

  if t == 'LocalFunc' then
    changed = lower_continue_expr(node.body, state) or changed
    return changed
  end

  if t == 'FunctionDecl' then
    changed = lower_continue_block(node.body, state, nil) or changed
    return changed
  end

  if t == 'Assignment' then
    for _, v in ipairs(node.targets or {}) do
      changed = lower_continue_expr(v, state) or changed
    end
    for _, v in ipairs(node.values or {}) do
      changed = lower_continue_expr(v, state) or changed
    end
    return changed
  end

  if t == 'Return' then
    for _, v in ipairs(node.values or {}) do
      changed = lower_continue_expr(v, state) or changed
    end
    return changed
  end

  changed = lower_continue_expr(node, state) or changed
  return changed
end

lower_continue_block = function(block, state, continue_label)
  if not block or type(block) ~= 'table' then
    return false
  end
  local changed = false
  local statements = block.statements or {}
  for i, stmt in ipairs(statements) do
    local stmt_changed = lower_continue_stmt(stmt, state, continue_label)
    if stmt_changed then
      changed = true
      statements[i] = stmt
    end
  end
  block.statements = statements
  return changed
end

local function normalize_source_for_runtime(source, dialect)
  local ok, result = pcall(function()
    local tokens = Lexer.new(source, { dialect = dialect }):tokenize()
    local parser = Parser.new(tokens, { dialect = dialect })
    local ast = parser:parse()

    local continue_found = has_continue_in_expr(ast)
    if continue_found then
      lower_continue_block(ast.body, { counter = 0 }, nil)
    end

    local codegen = CodeGen.new(nil)
    codegen.source_lines = {}
    codegen.preserve_indent_for_line = function(_, line)
      return line
    end
    local normalized = codegen:generate(ast.body)
    return {
      source = normalized,
      parser_ok = true,
      continue_lowered = continue_found
    }
  end)

  if ok and result and type(result.source) == 'string' and result.source ~= '' then
    return result
  end

  return {
    source = source,
    parser_ok = false,
    parser_error = tostring(result),
    continue_lowered = false
  }
end

local function add_probe_target(list, seen, fn, label, self_arg)
  if type(fn) ~= 'function' then
    return
  end
  local key = tostring(fn) .. '|' .. tostring(label or '')
  if seen[key] then
    return
  end
  seen[key] = true
  list[#list + 1] = { fn = fn, label = tostring(label or '<fn>'), self_arg = self_arg }
end

local function collect_table_functions(list, seen, tbl, label, max_fields)
  local count = 0
  for k, v in pairs(tbl or {}) do
    if count >= max_fields then
      break
    end
    if type(v) == 'function' then
      add_probe_target(list, seen, v, tostring(label) .. '.' .. tostring(k), tbl)
      count = count + 1
    end
  end
end

local function collect_probe_targets(env, returns, options)
  local targets = {}
  local seen = {}
  local max_fields = tonumber(options.max_probe_table_fields) or 12

  for k, v in pairs(env or {}) do
    if k ~= '_G' and k ~= '_ENV' then
      if type(v) == 'function' then
        add_probe_target(targets, seen, v, tostring(k), nil)
      elseif type(v) == 'table' and not rawget(v, '__path') then
        collect_table_functions(targets, seen, v, tostring(k), max_fields)
      end
    end
  end

  for i, v in ipairs(returns or {}) do
    if type(v) == 'function' then
      add_probe_target(targets, seen, v, 'return[' .. tostring(i) .. ']', nil)
    elseif type(v) == 'table' and not rawget(v, '__path') then
      collect_table_functions(targets, seen, v, 'return[' .. tostring(i) .. ']', max_fields)
    end
  end

  local max_targets = tonumber(options.max_probe_targets) or 16
  if max_targets < 0 then
    max_targets = 0
  end
  if #targets > max_targets then
    local trimmed = {}
    for i = 1, max_targets do
      trimmed[i] = targets[i]
    end
    return trimmed, #targets - max_targets
  end
  return targets, 0
end

local function set_hook(max_instructions)
  if type(debug) ~= 'table' or type(debug.gethook) ~= 'function' or type(debug.sethook) ~= 'function' then
    return { enabled = false, timeout = false }
  end
  local old_hook, old_mask, old_count = debug.gethook()
  local stride = 1000
  if max_instructions > 2000000 then
    stride = 4000
  elseif max_instructions > 1000000 then
    stride = 2000
  end
  local state = {
    enabled = true,
    timeout = false,
    old_hook = old_hook,
    old_mask = old_mask,
    old_count = old_count,
    stride = stride,
    budget = max_instructions
  }
  debug.sethook(function()
    state.budget = state.budget - state.stride
    if state.budget <= 0 then
      state.timeout = true
      error(TIMEOUT_SENTINEL)
    end
  end, '', stride)
  return state
end

local function clear_hook(state)
  if not state or not state.enabled then
    return
  end
  pcall(debug.sethook, state.old_hook, state.old_mask, state.old_count)
end

function LintDynamic.run(source, options)
  options = options or {}
  local max_instructions = tonumber(options.max_instructions) or 600000
  if max_instructions < 1000 then
    max_instructions = 1000
  end
  local max_records = tonumber(options.max_records) or 120
  if max_records < 10 then
    max_records = 10
  end
  local probe_enabled = options.probe ~= false

  local started = os.clock()

  local trace = {
    global_reads = {},
    global_writes = {},
    proxy_reads = {},
    require_calls = {}
  }
  local env
  env, trace = LintSandbox.build(options)
  local normalization = normalize_source_for_runtime(source, options.dialect)
  local runtime_source = normalization.source or source
  local used_normalized_source = runtime_source ~= source

  local chunk, compile_err = load_chunk(runtime_source, '@lint_dynamic', env)
  if not chunk and used_normalized_source then
    local fallback_chunk, fallback_err = load_chunk(source, '@lint_dynamic', env)
    if fallback_chunk then
      chunk = fallback_chunk
      compile_err = nil
      runtime_source = source
    else
      compile_err = fallback_err or compile_err
    end
  end

  if not chunk then
    local elapsed = math.floor((os.clock() - started) * 1000)
    return {
      ok = false,
      phase = 'compile',
      timeout = false,
      error = tostring(compile_err),
      duration_ms = elapsed,
      all_global_reads = {},
      resolved_global_reads = {},
      global_reads = {},
      global_writes = {},
      undefined_global_reads = {},
      proxy_root_reads = {},
      proxy_reads = {},
      require_calls = {},
      metatable_gets = {},
      metatable_sets = {},
      metatable_metamethods = {},
      history = {},
      history_stats = { total = 0, omitted = 0 },
      dependencies = {
        globals = {
          reads = {},
          resolved_reads = {},
          unresolved_reads = {},
          undefined_reads = {},
          writes = {}
        },
        metatable = {
          gets = {},
          sets = {},
          metamethod_keys = {}
        },
        proxies = {
          roots = {},
          reads = {}
        },
        require = {}
      },
      events = {},
      map_stats = {
        all_global_reads = { total = 0, omitted = 0 },
        resolved_global_reads = { total = 0, omitted = 0 },
        global_reads = { total = 0, omitted = 0 },
        global_writes = { total = 0, omitted = 0 },
        undefined_global_reads = { total = 0, omitted = 0 },
        proxy_root_reads = { total = 0, omitted = 0 },
        proxy_reads = { total = 0, omitted = 0 },
        require_calls = { total = 0, omitted = 0 },
        metatable_gets = { total = 0, omitted = 0 },
        metatable_sets = { total = 0, omitted = 0 },
        metatable_metamethods = { total = 0, omitted = 0 },
        events = { total = 0, omitted = 0 }
      },
      execution = {
        probe_enabled = probe_enabled,
        probes_attempted = 0,
        probes_ok = 0,
        probes_failed = 0,
        probes_omitted = 0,
        probe_errors = {}
      },
      runtime = {
        main = {
          ok = false,
          error = tostring(compile_err),
          phase = 'compile'
        },
        timeout = false
      },
      sandbox = { isolated = true }
    }
  end

  local timeout = false
  local runtime_err = nil
  local hook_state = set_hook(max_instructions)
  local exec = { pcall(chunk) }
  local ok = exec[1] == true
  local returns = {}
  if ok then
    for i = 2, #exec do
      returns[#returns + 1] = exec[i]
    end
  else
    runtime_err = tostring(exec[2])
  end

  local probe_errors_map = {}
  local probes_attempted, probes_ok, probes_failed, probes_omitted = 0, 0, 0, 0

  if ok and probe_enabled and not hook_state.timeout then
    local targets
    targets, probes_omitted = collect_probe_targets(env, returns, options)
    for _, target in ipairs(targets) do
      if hook_state.timeout then
        break
      end
      probes_attempted = probes_attempted + 1
      local pok, perr
      if target.self_arg ~= nil then
        pok, perr = pcall(target.fn, target.self_arg)
      else
        pok, perr = pcall(target.fn)
      end
      if pok then
        probes_ok = probes_ok + 1
      else
        probes_failed = probes_failed + 1
        local msg = tostring(perr or 'probe-failed')
        probe_errors_map[msg] = (probe_errors_map[msg] or 0) + 1
      end
    end
  end

  clear_hook(hook_state)
  timeout = hook_state.timeout == true

  if timeout then
    if not runtime_err then
      runtime_err = 'dynamic lint timeout'
    elseif runtime_err:find(TIMEOUT_SENTINEL, 1, true) then
      runtime_err = 'dynamic lint timeout'
    end
  end

  local all_global_reads, agr_total, agr_omit = summarize_key_counts(trace.all_global_reads, max_records)
  local resolved_global_reads, rgr_total, rgr_omit = summarize_key_counts(trace.resolved_global_reads, max_records)
  local global_reads, gr_total, gr_omit = summarize_key_counts(trace.global_reads, max_records)
  local global_writes, gw_total, gw_omit = summarize_key_counts(trace.global_writes, max_records)
  local undefined_global_reads, ug_total, ug_omit = summarize_key_counts(trace.undefined_global_reads, max_records)
  local proxy_root_reads, sr_total, sr_omit = summarize_key_counts(trace.proxy_root_reads, max_records)
  local proxy_reads, pr_total, pr_omit = summarize_key_counts(trace.proxy_reads, max_records)
  local require_calls, rq_total, rq_omit = summarize_key_counts(trace.require_calls, max_records)
  local metatable_gets, mg_total, mg_omit = summarize_key_counts(trace.metatable_gets, max_records)
  local metatable_sets, ms_total, ms_omit = summarize_key_counts(trace.metatable_sets, max_records)
  local metatable_metamethods, mm_total, mm_omit = summarize_key_counts(trace.metatable_metamethods, max_records)
  local events, ev_total, ev_omit = summarize_events(trace.events, max_records)
  local history, h_total, h_omit = summarize_history(
    trace.history,
    trace._history_total,
    trace._history_omitted,
    max_records
  )
  local probe_errors, pe_total, pe_omit = summarize_key_counts(probe_errors_map, math.max(10, math.floor(max_records / 2)))
  local elapsed = math.floor((os.clock() - started) * 1000)

  return {
    ok = ok and not timeout,
    phase = 'runtime',
    timeout = timeout,
    error = runtime_err,
    duration_ms = elapsed,
    all_global_reads = all_global_reads,
    resolved_global_reads = resolved_global_reads,
    global_reads = global_reads,
    global_writes = global_writes,
    undefined_global_reads = undefined_global_reads,
    proxy_root_reads = proxy_root_reads,
    proxy_reads = proxy_reads,
    require_calls = require_calls,
    metatable_gets = metatable_gets,
    metatable_sets = metatable_sets,
    metatable_metamethods = metatable_metamethods,
    history = history,
    history_stats = {
      total = h_total,
      omitted = h_omit
    },
    dependencies = {
      globals = {
        reads = all_global_reads,
        resolved_reads = resolved_global_reads,
        unresolved_reads = global_reads,
        undefined_reads = undefined_global_reads,
        writes = global_writes
      },
      metatable = {
        gets = metatable_gets,
        sets = metatable_sets,
        metamethod_keys = metatable_metamethods
      },
      proxies = {
        roots = proxy_root_reads,
        reads = proxy_reads
      },
      require = require_calls
    },
    events = events,
    map_stats = {
      all_global_reads = { total = agr_total, omitted = agr_omit },
      resolved_global_reads = { total = rgr_total, omitted = rgr_omit },
      global_reads = { total = gr_total, omitted = gr_omit },
      global_writes = { total = gw_total, omitted = gw_omit },
      undefined_global_reads = { total = ug_total, omitted = ug_omit },
      proxy_root_reads = { total = sr_total, omitted = sr_omit },
      proxy_reads = { total = pr_total, omitted = pr_omit },
      require_calls = { total = rq_total, omitted = rq_omit },
      metatable_gets = { total = mg_total, omitted = mg_omit },
      metatable_sets = { total = ms_total, omitted = ms_omit },
      metatable_metamethods = { total = mm_total, omitted = mm_omit },
      history = { total = h_total, omitted = h_omit },
      events = { total = ev_total, omitted = ev_omit }
    },
    execution = {
      probe_enabled = probe_enabled,
      probes_attempted = probes_attempted,
      probes_ok = probes_ok,
      probes_failed = probes_failed,
      probes_omitted = probes_omitted,
      probe_errors = probe_errors,
      probe_errors_stats = { total = pe_total, omitted = pe_omit }
    },
    runtime = {
      main = {
        ok = ok,
        error = runtime_err,
        phase = 'runtime'
      },
      timeout = timeout
    },
    limits = {
      max_instructions = max_instructions,
      max_records = max_records
    },
    sandbox = { isolated = true }
  }
end

return LintDynamic
