local Lexer = require('src.lexer')
local LexerFull = require('src.lexer_full')
local Parser = require('src.parser')

local RRequire = {}

local sep = package.config:sub(1, 1)

local function norm_sep(path)
  local p = tostring(path or '')
  p = p:gsub('[\\/]+', sep)
  return p
end

local function normalize_path(path)
  local p = norm_sep(path)
  local prefix = ''
  if p:match('^%a:' .. sep) then
    prefix = p:sub(1, 2) .. sep
    p = p:sub(4)
  elseif p:sub(1, 1) == sep then
    prefix = sep
    p = p:sub(2)
  end

  local parts = {}
  for part in p:gmatch('[^' .. sep .. ']+') do
    if part == '' or part == '.' then
    elseif part == '..' then
      if #parts > 0 then table.remove(parts) end
    else
      parts[#parts + 1] = part
    end
  end
  return prefix .. table.concat(parts, sep)
end

local function dirname(path)
  local p = norm_sep(path)
  local i = p:match('^.*()' .. sep)
  if not i then return '.' end
  if i <= 1 then return sep end
  return p:sub(1, i - 1)
end

local function join(base, rel)
  if rel:match('^%a:[/\\]') or rel:sub(1, 1) == '/' or rel:sub(1, 1) == '\\' then
    return normalize_path(rel)
  end
  local b = norm_sep(base or '.')
  if b == '' or b == '.' then
    return normalize_path(rel)
  end
  if b:sub(-1) == sep then
    return normalize_path(b .. rel)
  end
  return normalize_path(b .. sep .. rel)
end

local function file_exists(path)
  local f = io.open(path, 'rb')
  if not f then return false end
  f:close()
  return true
end

local function read_file(path)
  local f = io.open(path, 'rb')
  if not f then return nil end
  local s = f:read('*a')
  f:close()
  return s
end

local function module_to_rel(module_name)
  local m = tostring(module_name or '')
  m = norm_sep(m)
  if m:find('[\\/]', 1, false) then
    return m
  end
  if m:sub(1, 2) == './' or m:sub(1, 3) == '../' then
    return m
  end
  if m:sub(-4):lower() == '.lua' then
    local stem = m:sub(1, -5)
    if stem ~= '' then
      return stem:gsub('%.', sep) .. '.lua'
    end
    return m
  end
  return m:gsub('%.', sep)
end

local function package_path_candidates(module_name)
  local out = {}
  local mod = tostring(module_name or ''):gsub('%.', '/')
  local pp = package.path or ''
  for pattern in pp:gmatch('[^;]+') do
    if pattern:find('%?', 1, false) then
      out[#out + 1] = normalize_path(pattern:gsub('%?', mod))
    end
  end
  return out
end

local function resolve_module(module_name, from_file, root_dir)
  local from_dir = dirname(from_file)
  local rel = module_to_rel(module_name)
  local has_ext = rel:sub(-4):lower() == '.lua'

  local candidates = {}
  local seen = {}
  local function add_candidate(path)
    if not path or path == '' then return end
    local n = normalize_path(path)
    if not seen[n] then
      seen[n] = true
      candidates[#candidates + 1] = n
    end
  end

  if has_ext then
    add_candidate(join(from_dir, rel))
    add_candidate(join(root_dir, rel))
  else
    add_candidate(join(from_dir, rel .. '.lua'))
    add_candidate(join(from_dir, rel .. sep .. 'init.lua'))
    add_candidate(join(root_dir, rel .. '.lua'))
    add_candidate(join(root_dir, rel .. sep .. 'init.lua'))
  end

  for _, p in ipairs(package_path_candidates(module_name)) do
    add_candidate(p)
  end

  for _, c in ipairs(candidates) do
    if file_exists(c) then
      return c
    end
  end
  return nil
end

local function new_scope(parent)
  return { parent = parent, aliases = {} }
end

local function set_alias(scope, name, value)
  scope.aliases[name] = value and true or false
end

local function set_alias_in_visible_scope(scope, name, value)
  local cur = scope
  while cur do
    if cur.aliases[name] ~= nil then
      cur.aliases[name] = value and true or false
      return
    end
    cur = cur.parent
  end
  scope.aliases[name] = value and true or false
end

local function is_alias(scope, name)
  local cur = scope
  while cur do
    local v = cur.aliases[name]
    if v ~= nil then
      return v
    end
    cur = cur.parent
  end
  return name == 'require'
end

local function expr_is_require_callable(node, scope)
  if not node or type(node) ~= 'table' then
    return false
  end
  if node.type == 'Identifier' then
    return is_alias(scope, node.name)
  end
  if node.type == 'PropertyExpr' then
    return node.object and node.object.type == 'Identifier' and node.object.name == '_G' and node.property == 'require'
  end
  if node.type == 'IndexExpr' then
    return node.object and node.object.type == 'Identifier'
      and node.object.name == '_G'
      and node.index
      and node.index.type == 'String'
      and node.index.value == 'require'
  end
  return false
end

local function unique_insert(arr, seen, key, value)
  if seen[key] then return end
  seen[key] = true
  arr[#arr + 1] = value
end

local function collect_requires_from_ast(ast)
  local requires = {}
  local dynamic = {}
  local req_seen = {}
  local dyn_seen = {}

  local walk_expr
  local walk_stmt
  local walk_block

  local function add_require(module_name, line, col, kind)
    local key = table.concat({ tostring(line or 1), tostring(col or 1), tostring(kind or 'direct'), tostring(module_name) }, '|')
    unique_insert(requires, req_seen, key, {
      module = module_name,
      line = line or 1,
      col = col or 1,
      call_kind = kind or 'direct'
    })
  end

  local function add_dynamic(line, col, message, kind)
    local key = table.concat({ tostring(line or 1), tostring(col or 1), tostring(kind or 'dynamic'), tostring(message or '') }, '|')
    unique_insert(dynamic, dyn_seen, key, {
      line = line or 1,
      col = col or 1,
      message = message or 'dynamic require argument',
      call_kind = kind or 'dynamic'
    })
  end

  walk_expr = function(node, scope)
    if not node or type(node) ~= 'table' then
      return
    end
    local t = node.type

    if t == 'FunctionCall' then
      local callee = node.callee
      local line = (callee and callee.token and callee.token.line) or node.source_line or 1
      local col = (callee and callee.token and callee.token.col) or 1

      local handled = false

      if expr_is_require_callable(callee, scope) then
        local arg1 = node.args and node.args[1] or nil
        if arg1 and arg1.type == 'String' then
          local kind = (callee.type == 'Identifier' and callee.name == 'require') and 'direct' or 'alias'
          add_require(arg1.value, line, col, kind)
        else
          add_dynamic(line, col, 'dynamic require argument', 'direct')
        end
        handled = true
      elseif callee and callee.type == 'Identifier' and (callee.name == 'pcall' or callee.name == 'xpcall') then
        local fnarg = node.args and node.args[1] or nil
        if expr_is_require_callable(fnarg, scope) then
          local mod_idx = (callee.name == 'xpcall') and 3 or 2
          local marg = node.args and node.args[mod_idx] or nil
          if marg and marg.type == 'String' then
            add_require(marg.value, line, col, callee.name)
          else
            add_dynamic(line, col, 'dynamic require argument via ' .. callee.name, callee.name)
          end
          handled = true
        end
      end

      if not handled then
      end

      walk_expr(callee, scope)
      for _, arg in ipairs(node.args or {}) do
        walk_expr(arg, scope)
      end
      return
    end

    if t == 'MethodCall' then
      walk_expr(node.object, scope)
      for _, arg in ipairs(node.args or {}) do
        walk_expr(arg, scope)
      end
      return
    end

    if t == 'BinaryOp' then
      walk_expr(node.left, scope)
      walk_expr(node.right, scope)
      return
    end

    if t == 'UnaryOp' then
      walk_expr(node.operand, scope)
      return
    end

    if t == 'IndexExpr' then
      walk_expr(node.object, scope)
      walk_expr(node.index, scope)
      return
    end

    if t == 'PropertyExpr' then
      walk_expr(node.object, scope)
      return
    end

    if t == 'Table' then
      for _, f in ipairs(node.fields or {}) do
        if f.key then walk_expr(f.key, scope) end
        walk_expr(f.value, scope)
      end
      return
    end

    if t == 'Function' then
      local fn_scope = new_scope(scope)
      for _, p in ipairs(node.params or {}) do
        set_alias(fn_scope, p, false)
      end
      walk_block(node.body, fn_scope)
      return
    end
  end

  walk_stmt = function(stmt, scope)
    if not stmt then return end
    local t = stmt.type

    if t == 'LocalDecl' then
      for _, v in ipairs(stmt.values or {}) do
        walk_expr(v, scope)
      end

      local names = stmt.names or {}
      local values = stmt.values or {}
      for i, n in ipairs(names) do
        local v = values[i]
        set_alias(scope, n, v and expr_is_require_callable(v, scope) or false)
      end
      return
    end

    if t == 'LocalFunc' then
      set_alias(scope, stmt.name, false)
      if stmt.body then
        local fn_scope = new_scope(scope)
        for _, p in ipairs(stmt.body.params or {}) do
          set_alias(fn_scope, p, false)
        end
        if stmt.body.body then
          walk_block(stmt.body.body, fn_scope)
        end
      end
      return
    end

    if t == 'FunctionDecl' then
      local fn_scope = new_scope(scope)
      for _, p in ipairs(stmt.params or {}) do
        set_alias(fn_scope, p, false)
      end
      walk_block(stmt.body, fn_scope)
      return
    end

    if t == 'If' then
      walk_expr(stmt.condition, scope)
      walk_block(stmt.then_body, new_scope(scope))
      for _, p in ipairs(stmt.elseif_parts or {}) do
        walk_expr(p.condition, scope)
        walk_block(p.body, new_scope(scope))
      end
      if stmt.else_body then
        walk_block(stmt.else_body, new_scope(scope))
      end
      return
    end

    if t == 'While' then
      walk_expr(stmt.condition, scope)
      walk_block(stmt.body, new_scope(scope))
      return
    end

    if t == 'Repeat' then
      local rep_scope = new_scope(scope)
      walk_block(stmt.body, rep_scope)
      walk_expr(stmt.condition, rep_scope)
      return
    end

    if t == 'For' then
      walk_expr(stmt.start, scope)
      walk_expr(stmt.finish, scope)
      if stmt.step then walk_expr(stmt.step, scope) end
      local for_scope = new_scope(scope)
      set_alias(for_scope, stmt.var, false)
      walk_block(stmt.body, for_scope)
      return
    end

    if t == 'ForIn' then
      for _, it in ipairs(stmt.iterators or {}) do
        walk_expr(it, scope)
      end
      local for_scope = new_scope(scope)
      for _, v in ipairs(stmt.vars or {}) do
        set_alias(for_scope, v, false)
      end
      walk_block(stmt.body, for_scope)
      return
    end

    if t == 'Do' then
      walk_block(stmt.body, new_scope(scope))
      return
    end

    if t == 'Assignment' then
      for _, v in ipairs(stmt.values or {}) do
        walk_expr(v, scope)
      end

      for i, target in ipairs(stmt.targets or {}) do
        if target.type == 'Identifier' then
          local v = stmt.values and stmt.values[i] or nil
          local alias_value = v and expr_is_require_callable(v, scope) or false
          set_alias_in_visible_scope(scope, target.name, alias_value)
        else
          walk_expr(target, scope)
        end
      end
      return
    end

    if t == 'Return' then
      for _, v in ipairs(stmt.values or {}) do
        walk_expr(v, scope)
      end
      return
    end

    walk_expr(stmt, scope)
  end

  walk_block = function(block, scope)
    if not block or not block.statements then return end
    for _, stmt in ipairs(block.statements) do
      walk_stmt(stmt, scope)
    end
  end

  if ast and ast.type == 'Chunk' and ast.body then
    local root = new_scope(nil)
    walk_block(ast.body, root)
  end

  return requires, dynamic
end

local function parse_file_requires(path)
  local source = read_file(path)
  if not source then
    return nil, nil, 'file-read-error'
  end

  local function next_non_trivia(tokens, idx)
    local i = idx
    while i <= #tokens do
      local t = tokens[i]
      if t.type ~= 'comment' and t.type ~= 'newline' then
        return t, i
      end
      i = i + 1
    end
    return nil, i
  end

  local function decode_string_token(tok)
    if not tok or type(tok.value) ~= 'string' then
      return nil
    end
    if tok.type == 'long_string' then
      local eq, body = tok.value:match('^%[(=*)%[(.*)%]%1%]$')
      if eq ~= nil then return body end
      return tok.value
    end
    if tok.type == 'string' then
      local raw = tok.value
      if #raw >= 2 then
        local q = raw:sub(1, 1)
        if (q == '"' or q == "'") and raw:sub(-1) == q then
          raw = raw:sub(2, -2)
        end
      end
      raw = raw:gsub('\\\\', '\0')
      raw = raw:gsub('\\n', '\n')
      raw = raw:gsub('\\t', '\t')
      raw = raw:gsub('\\r', '\r')
      raw = raw:gsub("\\'", "'")
      raw = raw:gsub('\\"', '"')
      raw = raw:gsub('\0', '\\')
      return raw
    end
    return nil
  end

  local function collect_requires_by_tokens(text)
    local ok_lx, tokens = pcall(function()
      return LexerFull.new(text):tokenize()
    end)
    if not ok_lx then
      return {}, {}, 'tokenize-failed'
    end

    local reqs = {}
    local dyn = {}
    local req_seen = {}
    local dyn_seen = {}

    local function add_req(mod, line, col)
      local key = tostring(line) .. '|' .. tostring(col) .. '|' .. tostring(mod)
      unique_insert(reqs, req_seen, key, { module = mod, line = line, col = col, call_kind = 'fallback' })
    end

    local function add_dyn(line, col, msg)
      local key = tostring(line) .. '|' .. tostring(col) .. '|' .. tostring(msg)
      unique_insert(dyn, dyn_seen, key, { line = line, col = col, message = msg, call_kind = 'fallback' })
    end

    local i = 1
    while i <= #tokens do
      local tok = tokens[i]
      if tok and tok.type == 'ident' and tok.value == 'require' then
        local n1, i1 = next_non_trivia(tokens, i + 1)
        if n1 and n1.type == 'symbol' and n1.value == '(' then
          local arg = next_non_trivia(tokens, i1 + 1)
          if arg and (arg.type == 'string' or arg.type == 'long_string') then
            local mod = decode_string_token(arg)
            if mod and mod ~= '' then
              add_req(mod, tok.line or 1, tok.col or 1)
            else
              add_dyn(tok.line or 1, tok.col or 1, 'dynamic require argument')
            end
          else
            add_dyn(tok.line or 1, tok.col or 1, 'dynamic require argument')
          end
        elseif n1 and (n1.type == 'string' or n1.type == 'long_string') then
          local mod = decode_string_token(n1)
          if mod and mod ~= '' then
            add_req(mod, tok.line or 1, tok.col or 1)
          else
            add_dyn(tok.line or 1, tok.col or 1, 'dynamic require argument')
          end
        else
          add_dyn(tok.line or 1, tok.col or 1, 'dynamic require argument')
        end
      end
      i = i + 1
    end

    return reqs, dyn, nil
  end

  local ok, requires, dynamic = pcall(function()
    local tokens = Lexer.new(source):tokenize()
    local parser = Parser.new(tokens)
    local ast = parser:parse()
    return collect_requires_from_ast(ast)
  end)

  if not ok then
    local f_reqs, f_dyn, ferr = collect_requires_by_tokens(source)
    if ferr then
      return nil, nil, tostring(requires)
    end
    return f_reqs, f_dyn, nil
  end

  return requires or {}, dynamic or {}, nil
end

local function detect_cycles(nodes, edges)
  local adj = {}
  for _, n in ipairs(nodes) do
    adj[n] = {}
  end
  for _, e in ipairs(edges) do
    if e.to then
      local row = adj[e.from]
      if row then row[#row + 1] = e.to end
    end
  end
  for _, n in ipairs(nodes) do
    table.sort(adj[n])
    local dedup = {}
    local out = {}
    for _, to in ipairs(adj[n]) do
      if not dedup[to] then
        dedup[to] = true
        out[#out + 1] = to
      end
    end
    adj[n] = out
  end

  local color = {}
  local stack = {}
  local stack_pos = {}
  local cycles = {}
  local seen = {}

  local function dfs(node)
    color[node] = 1
    stack[#stack + 1] = node
    stack_pos[node] = #stack

    for _, to in ipairs(adj[node] or {}) do
      if color[to] == nil then
        dfs(to)
      elseif color[to] == 1 then
        local cycle = {}
        local start = stack_pos[to] or 1
        for i = start, #stack do
          cycle[#cycle + 1] = stack[i]
        end
        cycle[#cycle + 1] = to
        local key = table.concat(cycle, ' -> ')
        if not seen[key] then
          seen[key] = true
          cycles[#cycles + 1] = cycle
        end
      end
    end

    color[node] = 2
    stack_pos[node] = nil
    stack[#stack] = nil
  end

  for _, n in ipairs(nodes) do
    if color[n] == nil then
      dfs(n)
    end
  end

  return adj, cycles
end

function RRequire.analyze(entry_file)
  local entry = normalize_path(entry_file)
  local root_dir = dirname(entry)
  local queue = { entry }
  local qpos = 1

  local result = {
    entry = entry,
    root_dir = root_dir,
    nodes = {},
    edges = {},
    unresolved = {},
    dynamic = {},
    parse_errors = {},
    cycles = {},
    adjacency = {}
  }

  local node_set = {}
  local visited = {}
  local edge_seen = {}
  local unresolved_seen = {}
  local dynamic_seen = {}
  local parse_error_seen = {}

  while qpos <= #queue do
    local file = queue[qpos]
    qpos = qpos + 1

    if not visited[file] then
      visited[file] = true
      node_set[file] = true

      local requires, dynamic, err = parse_file_requires(file)
      if err then
        unique_insert(
          result.parse_errors,
          parse_error_seen,
          file .. '|' .. tostring(err),
          { file = file, message = tostring(err) }
        )
      else
        for _, d in ipairs(dynamic) do
          local item = {
            file = file,
            line = d.line or 1,
            col = d.col or 1,
            message = d.message or 'dynamic require',
            call_kind = d.call_kind or 'dynamic'
          }
          local key = table.concat({ item.file, item.line, item.col, item.message, item.call_kind }, '|')
          unique_insert(result.dynamic, dynamic_seen, key, item)
        end

        for _, req in ipairs(requires) do
          local resolved = resolve_module(req.module, file, root_dir)
          local edge = {
            from = file,
            module = req.module,
            to = resolved,
            line = req.line or 1,
            col = req.col or 1,
            call_kind = req.call_kind or 'direct'
          }
          local edge_key = table.concat({ edge.from, edge.module, tostring(edge.to), edge.line, edge.col, edge.call_kind }, '|')
          unique_insert(result.edges, edge_seen, edge_key, edge)

          if resolved then
            node_set[resolved] = true
            if not visited[resolved] then
              queue[#queue + 1] = resolved
            end
          else
            local u = {
              file = file,
              module = req.module,
              line = req.line or 1,
              col = req.col or 1,
              call_kind = req.call_kind or 'direct'
            }
            local ukey = table.concat({ u.file, u.module, u.line, u.col, u.call_kind }, '|')
            unique_insert(result.unresolved, unresolved_seen, ukey, u)
          end
        end
      end
    end
  end

  local nodes = {}
  for n, _ in pairs(node_set) do
    nodes[#nodes + 1] = n
  end
  table.sort(nodes)
  result.nodes = nodes

  table.sort(result.edges, function(a, b)
    if a.from ~= b.from then return a.from < b.from end
    if a.line ~= b.line then return a.line < b.line end
    if a.col ~= b.col then return a.col < b.col end
    return tostring(a.module) < tostring(b.module)
  end)
  table.sort(result.unresolved, function(a, b)
    if a.file ~= b.file then return a.file < b.file end
    if a.line ~= b.line then return a.line < b.line end
    if a.col ~= b.col then return a.col < b.col end
    return tostring(a.module) < tostring(b.module)
  end)
  table.sort(result.dynamic, function(a, b)
    if a.file ~= b.file then return a.file < b.file end
    if a.line ~= b.line then return a.line < b.line end
    return a.col < b.col
  end)
  table.sort(result.parse_errors, function(a, b)
    return a.file < b.file
  end)

  local adjacency, cycles = detect_cycles(nodes, result.edges)
  result.adjacency = adjacency
  result.cycles = cycles

  result.summary = {
    files = #nodes,
    edges = #result.edges,
    unresolved = #result.unresolved,
    dynamic = #result.dynamic,
    parse_errors = #result.parse_errors,
    cycles = #result.cycles
  }

  return result
end

function RRequire.format_report(result)
  local out = {}
  out[#out + 1] = 'rrequire report'
  out[#out + 1] = 'entry: ' .. tostring(result.entry or '')
  out[#out + 1] = string.format(
    'summary: files=%d edges=%d unresolved=%d dynamic=%d parse_errors=%d cycles=%d',
    result.summary.files or 0,
    result.summary.edges or 0,
    result.summary.unresolved or 0,
    result.summary.dynamic or 0,
    result.summary.parse_errors or 0,
    result.summary.cycles or 0
  )

  return table.concat(out, '\n')
end

return RRequire
