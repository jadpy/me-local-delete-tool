local Lexer = require('src.lexer')
local Parser = require('src.parser')
local LintDynamic = require('src.lint_dynamic')

local Linter = {}

local known_globals = {
  _G = true, _VERSION = true, assert = true, collectgarbage = true, dofile = true, error = true,
  getfenv = true, getmetatable = true, ipairs = true, load = true, loadfile = true, loadstring = true,
  module = true, newproxy = true, next = true, pairs = true,
  pcall = true, print = true, rawequal = true, rawget = true, rawlen = true, rawset = true,
  require = true, select = true, setfenv = true, setmetatable = true, tonumber = true, tostring = true, type = true,
  unpack = true,
  xpcall = true, coroutine = true, string = true, table = true, math = true, io = true, os = true,
  debug = true, utf8 = true, package = true, bit32 = true, warn = true, typeof = true,
  wait = true, spawn = true, delay = true, tick = true, time = true, task = true,
  game = true, workspace = true, script = true, Enum = true, Instance = true,
  shared = true, plugin = true, settings = true,
  Vector3 = true, Vector2 = true, CFrame = true, UDim = true, UDim2 = true, Color3 = true,
  BrickColor = true, Ray = true, Region3 = true, Rect = true,
  NumberRange = true, NumberSequence = true, NumberSequenceKeypoint = true,
  ColorSequence = true, ColorSequenceKeypoint = true,
  TweenInfo = true, Random = true, RaycastParams = true, OverlapParams = true,
  DockWidgetPluginGuiInfo = true, PhysicalProperties = true, Font = true
}

local protected_globals = {
  _G = true, _VERSION = true, assert = true, collectgarbage = true, dofile = true, error = true,
  getfenv = true, getmetatable = true, ipairs = true, load = true, loadfile = true, loadstring = true,
  module = true, newproxy = true, next = true, pairs = true,
  pcall = true, print = true, rawequal = true, rawget = true, rawlen = true, rawset = true,
  require = true, select = true, setfenv = true, setmetatable = true, tonumber = true, tostring = true, type = true,
  unpack = true,
  xpcall = true, coroutine = true, string = true, table = true, math = true, io = true, os = true,
  debug = true, utf8 = true, package = true, bit32 = true,
  typeof = true, wait = true, spawn = true, delay = true, tick = true, time = true, task = true
}

local arithmetic_ops = {
  ['+'] = true, ['-'] = true, ['*'] = true, ['/'] = true, ['//'] = true, ['%'] = true, ['^'] = true
}

local function new_scope(parent)
  return { parent = parent, locals = {} }
end

local function lookup(scope, name)
  local cur = scope
  while cur do
    local sym = cur.locals[name]
    if sym then
      return sym
    end
    cur = cur.parent
  end
  return nil
end

local function lookup_parent(scope, name)
  if not scope then return nil end
  return lookup(scope.parent, name)
end

local function add_type(sym, typ)
  if not sym or not typ or typ == 'unknown' then
    return
  end
  sym.types[typ] = true
end

local function get_single_type(sym)
  if not sym then return nil end
  local count = 0
  local last = nil
  for t, _ in pairs(sym.types) do
    count = count + 1
    last = t
    if count > 1 then
      return nil
    end
  end
  return last
end

local function is_literal_type(t)
  return t == 'number' or t == 'string' or t == 'boolean' or t == 'nil' or t == 'table' or t == 'function'
end

local function stmt_pos(stmt)
  if not stmt then return 1, 1 end
  if stmt.token and stmt.token.line then
    return stmt.token.line, stmt.token.col or 1
  end
  if stmt.source_line then
    return stmt.source_line, 1
  end
  return 1, 1
end

local function expr_pos(node)
  if not node then return 1, 1 end
  if node.token and node.token.line then
    return node.token.line, node.token.col or 1
  end
  if node.source_line then
    return node.source_line, 1
  end
  return 1, 1
end

local function add_diag(state, code, message, line, col, severity)
  local key = string.format('%s|%s|%s|%s', code, tostring(line or 1), tostring(col or 1), message)
  if state.diag_seen[key] then
    return
  end
  state.diag_seen[key] = true
  state.diagnostics[#state.diagnostics + 1] = {
    code = code,
    message = message,
    line = line or 1,
    col = col or 1,
    severity = severity or 'warning'
  }
end

local function declare_symbol(state, scope, name, kind, line, col)
  local current = scope.locals[name]
  if current then
    add_diag(state, 'duplicate-local', "duplicate local declaration '" .. name .. "'", line, col, 'warning')
  else
    local outer = lookup_parent(scope, name)
    if outer and not tostring(name):match('^_') then
      add_diag(state, 'shadowing', "local '" .. name .. "' shadows outer local", line, col, 'info')
    end
  end

  local sym = {
    name = name,
    kind = kind,
    line = line or 1,
    col = col or 1,
    refs = 0,
    types = {}
  }
  scope.locals[name] = sym
  state.symbols[#state.symbols + 1] = sym
  return sym
end

local function infer_expr_type(node, scope)
  if not node or type(node) ~= 'table' then
    return 'unknown'
  end
  local t = node.type

  if t == 'Number' then return 'number' end
  if t == 'String' then return 'string' end
  if t == 'Boolean' then return 'boolean' end
  if t == 'Nil' then return 'nil' end
  if t == 'Table' then return 'table' end
  if t == 'Function' then return 'function' end

  if t == 'Identifier' then
    local sym = lookup(scope, node.name)
    if sym then
      local one = get_single_type(sym)
      if one then
        return one
      end
    end
    return 'unknown'
  end

  if t == 'UnaryOp' then
    if node.op == 'not' then return 'boolean' end
    if node.op == '-' then return 'number' end
    if node.op == '#' then return 'number' end
    return 'unknown'
  end

  if t == 'BinaryOp' then
    local op = node.op
    if arithmetic_ops[op] then
      return 'number'
    end
    if op == '..' then
      return 'string'
    end
    if op == '<' or op == '<=' or op == '>' or op == '>=' or op == '==' or op == '~=' then
      return 'boolean'
    end
    if op == 'and' or op == 'or' then
      local lt = infer_expr_type(node.left, scope)
      local rt = infer_expr_type(node.right, scope)
      if lt == rt and lt ~= 'unknown' then
        return lt
      end
      return 'unknown'
    end
  end

  return 'unknown'
end

local function has_side_effect(node)
  if not node or type(node) ~= 'table' then
    return false
  end
  local t = node.type

  if t == 'FunctionCall' or t == 'MethodCall' then
    return true
  end
  if t == 'BinaryOp' then
    return has_side_effect(node.left) or has_side_effect(node.right)
  end
  if t == 'UnaryOp' then
    return has_side_effect(node.operand)
  end
  if t == 'IndexExpr' then
    return has_side_effect(node.object) or has_side_effect(node.index)
  end
  if t == 'PropertyExpr' then
    return has_side_effect(node.object)
  end
  if t == 'Table' then
    for _, f in ipairs(node.fields or {}) do
      if has_side_effect(f.key) or has_side_effect(f.value) then
        return true
      end
    end
  end
  return false
end

local function split_identifier_path(path)
  local parts = {}
  if type(path) ~= 'string' then
    return parts
  end
  for name in path:gmatch('([%a_][%w_]*)') do
    parts[#parts + 1] = name
  end
  return parts
end

local analyze_expr
local analyze_stmt
local analyze_block
local block_guarantees_termination
local stmt_guarantees_termination
local walk_unknown_children

walk_unknown_children = function(state, node, scope)
  if type(node) ~= 'table' then
    return
  end
  state.walk_seen = state.walk_seen or {}
  if state.walk_seen[node] then
    return
  end
  state.walk_seen[node] = true

  for k, v in pairs(node) do
    if k ~= 'token' and k ~= 'name_token' and k ~= 'name_tokens' and k ~= 'param_tokens' and k ~= 'var_token' and k ~= 'var_tokens' then
      if type(v) == 'table' then
        if v.type then
          analyze_expr(state, v, scope)
        else
          for _, item in pairs(v) do
            if type(item) == 'table' and item.type then
              analyze_expr(state, item, scope)
            end
          end
        end
      end
    end
  end
end

analyze_expr = function(state, node, scope)
  if not node or type(node) ~= 'table' then
    return
  end
  local t = node.type

  if t == 'Identifier' then
    local sym = lookup(scope, node.name)
    if sym then
      sym.refs = sym.refs + 1
    elseif not known_globals[node.name] then
      local ln, cl = expr_pos(node)
      add_diag(state, 'undefined-reference', "undefined reference '" .. node.name .. "'", ln, cl, 'warning')
    end
    return
  end

  if t == 'BinaryOp' then
    analyze_expr(state, node.left, scope)
    analyze_expr(state, node.right, scope)

    if arithmetic_ops[node.op] then
      local lt = infer_expr_type(node.left, scope)
      local rt = infer_expr_type(node.right, scope)
      if lt ~= 'unknown' and rt ~= 'unknown' and (lt ~= 'number' or rt ~= 'number') then
        local ln, cl = expr_pos(node.left)
        add_diag(state, 'type-mismatch', "arithmetic '" .. node.op .. "' expects number operands", ln, cl, 'warning')
      end
    elseif node.op == '..' then
      local lt = infer_expr_type(node.left, scope)
      local rt = infer_expr_type(node.right, scope)
      local left_ok = lt == 'string' or lt == 'number' or lt == 'unknown'
      local right_ok = rt == 'string' or rt == 'number' or rt == 'unknown'
      if not left_ok or not right_ok then
        local ln, cl = expr_pos(node.left)
        add_diag(state, 'type-mismatch', "concat '..' expects string/number operands", ln, cl, 'warning')
      end
    elseif node.op == '==' or node.op == '~=' then
      local lt = infer_expr_type(node.left, scope)
      local rt = infer_expr_type(node.right, scope)
      if lt ~= 'unknown' and rt ~= 'unknown' and lt ~= rt and is_literal_type(lt) and is_literal_type(rt) then
        local ln, cl = expr_pos(node.left)
        add_diag(state, 'suspicious-compare', "comparing different literal types: " .. lt .. ' and ' .. rt, ln, cl, 'info')
      end
    end
    return
  end

  if t == 'UnaryOp' then
    analyze_expr(state, node.operand, scope)
    if node.op == '-' then
      local ot = infer_expr_type(node.operand, scope)
      if ot ~= 'unknown' and ot ~= 'number' then
        local ln, cl = expr_pos(node.operand)
        add_diag(state, 'type-mismatch', "unary '-' expects number operand", ln, cl, 'warning')
      end
    end
    return
  end

  if t == 'FunctionCall' then
    analyze_expr(state, node.callee, scope)
    for _, arg in ipairs(node.args or {}) do
      analyze_expr(state, arg, scope)
    end
    local ct = infer_expr_type(node.callee, scope)
    if ct ~= 'unknown' and ct ~= 'function' then
      local ln, cl = expr_pos(node.callee)
      add_diag(state, 'call-non-function', 'attempt to call non-function value of type ' .. ct, ln, cl, 'warning')
    end
    return
  end

  if t == 'MethodCall' then
    analyze_expr(state, node.object, scope)
    for _, arg in ipairs(node.args or {}) do
      analyze_expr(state, arg, scope)
    end
    return
  end

  if t == 'IndexExpr' then
    analyze_expr(state, node.object, scope)
    analyze_expr(state, node.index, scope)
    return
  end

  if t == 'PropertyExpr' then
    analyze_expr(state, node.object, scope)
    return
  end

  if t == 'Table' then
    for _, f in ipairs(node.fields or {}) do
      if f.key then
        analyze_expr(state, f.key, scope)
      end
      analyze_expr(state, f.value, scope)
    end
    return
  end

  if t == 'Function' then
    local fn_scope = new_scope(scope)
    for i, p in ipairs(node.params or {}) do
      local tok = node.param_tokens and node.param_tokens[i] or nil
      local line = tok and tok.line or (node.source_line or 1)
      local col = tok and tok.col or 1
      declare_symbol(state, fn_scope, p, 'param', line, col)
    end
    analyze_block(state, node.body, fn_scope)
    return
  end

  walk_unknown_children(state, node, scope)
end

local function analyze_assignment_target(state, target, scope, value_type, value_node)
  if not target then return end

  if target.type == 'Identifier' then
    local sym = lookup(scope, target.name)
    if sym then
      local old_single = get_single_type(sym)
      if old_single and value_type and value_type ~= 'unknown' and value_type ~= old_single and is_literal_type(old_single) then
        local ln, cl = expr_pos(target)
        add_diag(
          state,
          'type-mismatch',
          "local '" .. target.name .. "' changes type from " .. old_single .. ' to ' .. value_type,
          ln,
          cl,
          'warning'
        )
      end
      add_type(sym, value_type)
    else
      local ln, cl = expr_pos(target)
      if protected_globals[target.name] then
        add_diag(state, 'global-overwrite', "assignment to protected global '" .. target.name .. "'", ln, cl, 'warning')
      elseif not known_globals[target.name] then
        add_diag(state, 'global-write', "assignment to undeclared global '" .. target.name .. "'", ln, cl, 'warning')
      end
    end

    if value_node and value_node.type == 'Identifier' and value_node.name == target.name then
      local ln, cl = expr_pos(target)
      add_diag(state, 'self-assignment', "self-assignment on '" .. target.name .. "'", ln, cl, 'info')
    end
    return
  end

  if target.type == 'IndexExpr' then
    analyze_expr(state, target.object, scope)
    analyze_expr(state, target.index, scope)
    return
  end

  if target.type == 'PropertyExpr' then
    analyze_expr(state, target.object, scope)
    return
  end

  analyze_expr(state, target, scope)
end

analyze_stmt = function(state, stmt, scope)
  if not stmt then return end
  local t = stmt.type

  if t == 'LocalDecl' then
    for _, v in ipairs(stmt.values or {}) do
      analyze_expr(state, v, scope)
    end

    local name_tokens = stmt.name_tokens or {}
    for i, name in ipairs(stmt.names or {}) do
      local tok = name_tokens[i]
      local line = tok and tok.line or (stmt.source_line or 1)
      local col = tok and tok.col or 1
      local sym = declare_symbol(state, scope, name, 'local', line, col)
      local v = stmt.values and stmt.values[i] or nil
      if v then
        add_type(sym, infer_expr_type(v, scope))
      end
    end
    return
  end

  if t == 'LocalFunc' then
    local nt = stmt.name_token
    local line = nt and nt.line or (stmt.source_line or 1)
    local col = nt and nt.col or 1
    local sym = declare_symbol(state, scope, stmt.name, 'localfunc', line, col)
    add_type(sym, 'function')
    if stmt.body and stmt.body.type == 'Block' then
      analyze_block(state, stmt.body, new_scope(scope))
    else
      analyze_expr(state, stmt.body, scope)
    end
    return
  end

  if t == 'FunctionDecl' then
    local parts = split_identifier_path(stmt.name)
    local head = parts[1]
    if head then
      local sym = lookup(scope, head)
      if sym then
        sym.refs = sym.refs + 1
      elseif (stmt.name:find('%.', 1, true) or stmt.name:find(':', 1, true)) and not known_globals[head] then
        local line = stmt.source_line or 1
        add_diag(state, 'undefined-reference', "base table '" .. head .. "' may be undefined", line, 1, 'info')
      end
    end

    local fn_scope = new_scope(scope)
    if stmt.name and stmt.name:find(':', 1, true) then
      declare_symbol(state, fn_scope, 'self', 'param', stmt.source_line or 1, 1)
    end
    for i, p in ipairs(stmt.params or {}) do
      local tok = stmt.param_tokens and stmt.param_tokens[i] or nil
      local line = tok and tok.line or (stmt.source_line or 1)
      local col = tok and tok.col or 1
      declare_symbol(state, fn_scope, p, 'param', line, col)
    end
    analyze_block(state, stmt.body, fn_scope)
    return
  end

  if t == 'If' then
    analyze_expr(state, stmt.condition, scope)
    analyze_block(state, stmt.then_body, new_scope(scope))
    for _, p in ipairs(stmt.elseif_parts or {}) do
      analyze_expr(state, p.condition, scope)
      analyze_block(state, p.body, new_scope(scope))
    end
    if stmt.else_body then
      analyze_block(state, stmt.else_body, new_scope(scope))
    end
    return
  end

  if t == 'While' then
    analyze_expr(state, stmt.condition, scope)
    analyze_block(state, stmt.body, new_scope(scope))
    return
  end

  if t == 'Repeat' then
    local rep_scope = new_scope(scope)
    analyze_block(state, stmt.body, rep_scope)
    analyze_expr(state, stmt.condition, rep_scope)
    return
  end

  if t == 'For' then
    analyze_expr(state, stmt.start, scope)
    analyze_expr(state, stmt.finish, scope)
    if stmt.step then
      analyze_expr(state, stmt.step, scope)
    end

    local for_scope = new_scope(scope)
    local vt = stmt.var_token
    local line = vt and vt.line or (stmt.source_line or 1)
    local col = vt and vt.col or 1
    local sym = declare_symbol(state, for_scope, stmt.var, 'forvar', line, col)
    add_type(sym, 'number')
    analyze_block(state, stmt.body, for_scope)
    return
  end

  if t == 'ForIn' then
    for _, iter in ipairs(stmt.iterators or {}) do
      analyze_expr(state, iter, scope)
    end
    local for_scope = new_scope(scope)
    local vars = stmt.vars or {}
    local tokens = stmt.var_tokens or {}
    for i, name in ipairs(vars) do
      local tok = tokens[i]
      local line = tok and tok.line or (stmt.source_line or 1)
      local col = tok and tok.col or 1
      declare_symbol(state, for_scope, name, 'forvar', line, col)
    end
    analyze_block(state, stmt.body, for_scope)
    return
  end

  if t == 'Do' then
    analyze_block(state, stmt.body, new_scope(scope))
    return
  end

  if t == 'Assignment' then
    for _, v in ipairs(stmt.values or {}) do
      analyze_expr(state, v, scope)
    end
    for i, target in ipairs(stmt.targets or {}) do
      local v = stmt.values and stmt.values[i] or nil
      analyze_assignment_target(state, target, scope, infer_expr_type(v, scope), v)
    end
    return
  end

  if t == 'Return' then
    for _, v in ipairs(stmt.values or {}) do
      analyze_expr(state, v, scope)
    end
    return
  end

  if t == 'Break' then
    return
  end

  analyze_expr(state, stmt, scope)
  if not has_side_effect(stmt) then
    local line, col = stmt_pos(stmt)
    add_diag(state, 'useless-expression', 'expression statement has no side effects', line, col, 'info')
  end
end

stmt_guarantees_termination = function(stmt)
  if not stmt or type(stmt) ~= 'table' then
    return false
  end
  local t = stmt.type
  if t == 'Return' or t == 'Break' or t == 'Continue' then
    return true
  end
  if t == 'Do' then
    return block_guarantees_termination(stmt.body)
  end
  if t == 'If' then
    if not stmt.else_body then
      return false
    end
    if not block_guarantees_termination(stmt.then_body) then
      return false
    end
    for _, p in ipairs(stmt.elseif_parts or {}) do
      if not block_guarantees_termination(p.body) then
        return false
      end
    end
    if not block_guarantees_termination(stmt.else_body) then
      return false
    end
    return true
  end
  return false
end

block_guarantees_termination = function(block)
  if not block or not block.statements then
    return false
  end
  for _, stmt in ipairs(block.statements) do
    if stmt_guarantees_termination(stmt) then
      return true
    end
  end
  return false
end

analyze_block = function(state, block, scope)
  if not block or not block.statements then
    return
  end
  local terminated = false
  for _, stmt in ipairs(block.statements) do
    if terminated then
      local line, col = stmt_pos(stmt)
      add_diag(state, 'unreachable-code', 'statement is unreachable', line, col, 'warning')
      break
    end
    analyze_stmt(state, stmt, scope)
    if stmt_guarantees_termination(stmt) then
      terminated = true
    end
  end
end

local function finalize_unused(state)
  for _, sym in ipairs(state.symbols) do
    local is_local_kind = sym.kind == 'local' or sym.kind == 'param' or sym.kind == 'forvar' or sym.kind == 'localfunc'
    if is_local_kind and sym.refs == 0 and not tostring(sym.name):match('^_') then
      add_diag(state, 'unused-variable', "unused " .. sym.kind .. " '" .. sym.name .. "'", sym.line, sym.col, 'warning')
    end
  end
end

local function sort_diags(diags)
  table.sort(diags, function(a, b)
    if a.line ~= b.line then return a.line < b.line end
    if a.col ~= b.col then return a.col < b.col end
    if a.severity ~= b.severity then return a.severity < b.severity end
    return a.code < b.code
  end)
end

local function build_summary(diags)
  local summary = {
    total = #diags,
    warning = 0,
    info = 0,
    error = 0,
    by_code = {}
  }
  for _, d in ipairs(diags) do
    summary[d.severity] = (summary[d.severity] or 0) + 1
    summary.by_code[d.code] = (summary.by_code[d.code] or 0) + 1
  end
  return summary
end

local function dynamic_supported_for_dialect(dialect)
  local key = tostring(dialect or 'auto'):lower()
  if key == '' then
    return true
  end
  return true
end

local function dynamic_skip_result(reason)
  return {
    ok = false,
    skipped = true,
    reason = tostring(reason or 'dynamic-disabled'),
    phase = 'skipped',
    timeout = false,
    error = nil,
    duration_ms = 0,
    all_global_reads = {},
    resolved_global_reads = {},
    global_reads = {},
    global_writes = {},
    undefined_global_reads = {},
    proxy_root_reads = {},
    proxy_reads = {},
    require_calls = {},
    metatable_gets = {},
    metatable_sets = {},
    metatable_metamethods = {},
    history = {},
    history_stats = { total = 0, omitted = 0 },
    dependencies = {
      globals = {
        reads = {},
        resolved_reads = {},
        unresolved_reads = {},
        undefined_reads = {},
        writes = {}
      },
      metatable = {
        gets = {},
        sets = {},
        metamethod_keys = {}
      },
      proxies = {
        roots = {},
        reads = {}
      },
      require = {}
    },
    events = {},
    map_stats = {
      all_global_reads = { total = 0, omitted = 0 },
      resolved_global_reads = { total = 0, omitted = 0 },
      global_reads = { total = 0, omitted = 0 },
      global_writes = { total = 0, omitted = 0 },
      undefined_global_reads = { total = 0, omitted = 0 },
      proxy_root_reads = { total = 0, omitted = 0 },
      proxy_reads = { total = 0, omitted = 0 },
      require_calls = { total = 0, omitted = 0 },
      metatable_gets = { total = 0, omitted = 0 },
      metatable_sets = { total = 0, omitted = 0 },
      metatable_metamethods = { total = 0, omitted = 0 },
      history = { total = 0, omitted = 0 },
      events = { total = 0, omitted = 0 }
    },
    execution = {
      probe_enabled = false,
      probes_attempted = 0,
      probes_ok = 0,
      probes_failed = 0,
      probes_omitted = 0,
      probe_errors = {},
      probe_errors_stats = { total = 0, omitted = 0 }
    },
    runtime = {
      main = { ok = false, error = nil, phase = 'skipped' },
      timeout = false
    },
    sandbox = { isolated = true }
  }
end

local function emit_dynamic_items(push_diag, items, limit, code, severity, build_message, allow_item)
  local emitted = 0
  for _, item in ipairs(items or {}) do
    local ok_item = true
    if allow_item then
      ok_item = allow_item(item)
    end
    if ok_item then
      emitted = emitted + 1
      if emitted <= limit then
        push_diag(code, build_message(item), severity)
      end
    end
  end
  if emitted > limit then
    push_diag(code .. '-more', 'additional ' .. tostring(code) .. ' entries: ' .. tostring(emitted - limit), 'info')
  end
end

function Linter.run(source, options)
  options = options or {}
  local dialect = options.dialect
  local dynamic_enabled = options.dynamic ~= false
  local dynamic_diag_limit = tonumber(options.dynamic_diag_limit) or 24
  if dynamic_diag_limit < 1 then
    dynamic_diag_limit = 1
  end
  local ok, result = pcall(function()
    local tokens = Lexer.new(source, { dialect = dialect }):tokenize()
    local parser = Parser.new(tokens, { dialect = dialect })
    local ast = parser:parse()

    local state = {
      diagnostics = {},
      diag_seen = {},
      symbols = {},
      walk_seen = {}
    }

    local root = new_scope(nil)
    analyze_block(state, ast.body, root)
    finalize_unused(state)
    sort_diags(state.diagnostics)

    local out = {
      ok = true,
      diagnostics = state.diagnostics,
      summary = build_summary(state.diagnostics)
    }
    if dynamic_enabled then
      if dynamic_supported_for_dialect(dialect) then
        out.dynamic = LintDynamic.run(source, {
          max_instructions = options.max_instructions,
          max_records = options.max_records,
          max_probe_targets = options.max_probe_targets,
          max_probe_table_fields = options.max_probe_table_fields,
          probe = options.probe,
          dialect = dialect
        })
      else
        out.dynamic = dynamic_skip_result('dialect-not-runtime-compatible')
      end
    end
    return out
  end)

  if ok then
    if result.dynamic then
      local diag_seen = {}
      for _, d in ipairs(result.diagnostics or {}) do
        local key = table.concat({
          tostring(d.code or ''),
          tostring(d.line or 1),
          tostring(d.col or 1),
          tostring(d.message or '')
        }, '|')
        diag_seen[key] = true
      end
      local function push_diag(code, message, severity)
        local key = table.concat({ tostring(code), '1', '1', tostring(message) }, '|')
        if diag_seen[key] then
          return
        end
        diag_seen[key] = true
        result.diagnostics[#result.diagnostics + 1] = {
          code = code,
          message = message,
          line = 1,
          col = 1,
          severity = severity
        }
      end

      if result.dynamic.skipped then
        push_diag('dynamic-skipped', 'dynamic lint skipped: ' .. tostring(result.dynamic.reason), 'info')
      elseif result.dynamic.timeout then
        push_diag('dynamic-timeout', 'dynamic lint execution timed out', 'warning')
      elseif not result.dynamic.ok and result.dynamic.error then
        push_diag('dynamic-runtime-error', tostring(result.dynamic.error), 'warning')
      end
      emit_dynamic_items(
        push_diag,
        result.dynamic.global_reads,
        dynamic_diag_limit,
        'dynamic-global-read',
        'info',
        function(item)
          return "runtime read global '" .. tostring(item.name) .. "' x" .. tostring(item.count)
        end,
        function(item)
          return item and item.name and item.name ~= '_G' and item.name ~= '_ENV'
        end
      )
      emit_dynamic_items(
        push_diag,
        result.dynamic.global_writes,
        dynamic_diag_limit,
        'dynamic-global-write',
        'warning',
        function(item)
          return "runtime write global '" .. tostring(item.name) .. "' x" .. tostring(item.count)
        end,
        function(item)
          return item and item.name and item.name ~= '_G' and item.name ~= '_ENV'
        end
      )
      emit_dynamic_items(
        push_diag,
        result.dynamic.undefined_global_reads,
        dynamic_diag_limit,
        'dynamic-undefined-global-read',
        'warning',
        function(item)
          return "runtime read undefined global '" .. tostring(item.name) .. "' x" .. tostring(item.count)
        end,
        function(item)
          return item and item.name
        end
      )
      emit_dynamic_items(
        push_diag,
        result.dynamic.require_calls,
        dynamic_diag_limit,
        'dynamic-require',
        'info',
        function(item)
          return "runtime require '" .. tostring(item.name) .. "' x" .. tostring(item.count)
        end,
        function(item)
          return item and item.name
        end
      )
      emit_dynamic_items(
        push_diag,
        result.dynamic.events,
        dynamic_diag_limit,
        'dynamic-sandbox-event',
        'info',
        function(item)
          return "[" .. tostring(item.level) .. "] " .. tostring(item.code) .. ': ' .. tostring(item.message) .. " x" .. tostring(item.count)
        end,
        nil
      )
      if result.dynamic.execution then
        local ex = result.dynamic.execution
        if (ex.probes_omitted or 0) > 0 then
          push_diag('dynamic-probe-truncated', 'dynamic probe targets omitted: ' .. tostring(ex.probes_omitted), 'info')
        end
        if (ex.probes_failed or 0) > 0 then
          push_diag('dynamic-probe-failed', 'dynamic probe failures: ' .. tostring(ex.probes_failed), 'warning')
        end
        emit_dynamic_items(
          push_diag,
          ex.probe_errors,
          dynamic_diag_limit,
          'dynamic-probe-error',
          'info',
          function(item)
            return "probe error '" .. tostring(item.name) .. "' x" .. tostring(item.count)
          end,
          function(item)
            return item and item.name
          end
        )
      end
      if result.dynamic.map_stats then
        local ms = result.dynamic.map_stats
        local omitted = (ms.all_global_reads and ms.all_global_reads.omitted or 0)
          + (ms.resolved_global_reads and ms.resolved_global_reads.omitted or 0)
          + (ms.global_reads and ms.global_reads.omitted or 0)
          + (ms.global_writes and ms.global_writes.omitted or 0)
          + (ms.undefined_global_reads and ms.undefined_global_reads.omitted or 0)
          + (ms.proxy_root_reads and ms.proxy_root_reads.omitted or 0)
          + (ms.proxy_reads and ms.proxy_reads.omitted or 0)
          + (ms.require_calls and ms.require_calls.omitted or 0)
          + (ms.metatable_gets and ms.metatable_gets.omitted or 0)
          + (ms.metatable_sets and ms.metatable_sets.omitted or 0)
          + (ms.metatable_metamethods and ms.metatable_metamethods.omitted or 0)
          + (ms.history and ms.history.omitted or 0)
          + (ms.events and ms.events.omitted or 0)
        if omitted > 0 then
          push_diag('dynamic-truncated', 'dynamic result entries truncated: ' .. tostring(omitted), 'info')
        end
      end
      if result.dynamic.runtime and result.dynamic.runtime.main and result.dynamic.runtime.main.error then
        local detail_msg = tostring(result.dynamic.runtime.main.error)
        local base_msg = result.dynamic.error and tostring(result.dynamic.error) or nil
        if detail_msg ~= '' and detail_msg ~= base_msg then
          push_diag('dynamic-runtime-detail', detail_msg, 'warning')
        end
      end
      if (result.dynamic.duration_ms or 0) > 2000 then
        push_diag('dynamic-slow', 'dynamic lint runtime is slow: ' .. tostring(result.dynamic.duration_ms) .. 'ms', 'info')
      end
      sort_diags(result.diagnostics)
      result.summary = build_summary(result.diagnostics)
    end
    return result
  end

  local diags = {
    {
      code = 'parse-error',
      message = tostring(result),
      line = 1,
      col = 1,
      severity = 'error'
    }
  }
  local out = {
    ok = false,
    diagnostics = diags,
    summary = build_summary(diags)
  }
  if dynamic_enabled then
    if dynamic_supported_for_dialect(dialect) then
      out.dynamic = LintDynamic.run(source, {
        max_instructions = options.max_instructions,
        max_records = options.max_records,
        max_probe_targets = options.max_probe_targets,
        max_probe_table_fields = options.max_probe_table_fields,
        probe = options.probe,
        dialect = dialect
      })
    else
      out.dynamic = dynamic_skip_result('dialect-not-runtime-compatible')
    end
    if out.dynamic.skipped then
      out.diagnostics[#out.diagnostics + 1] = {
        code = 'dynamic-skipped',
        message = 'dynamic lint skipped: ' .. tostring(out.dynamic.reason),
        line = 1,
        col = 1,
        severity = 'info'
      }
    elseif out.dynamic.timeout then
      out.diagnostics[#out.diagnostics + 1] = {
        code = 'dynamic-timeout',
        message = 'dynamic lint execution timed out',
        line = 1,
        col = 1,
        severity = 'warning'
      }
    elseif not out.dynamic.ok and out.dynamic.error then
      out.diagnostics[#out.diagnostics + 1] = {
        code = 'dynamic-runtime-error',
        message = tostring(out.dynamic.error),
        line = 1,
        col = 1,
        severity = 'warning'
      }
    end
    local seen_dynamic_parse_fail = {}
    local function push_dynamic_diag_parse_fail(code, message, severity)
      local key = tostring(code) .. '|' .. tostring(message)
      if seen_dynamic_parse_fail[key] then
        return
      end
      seen_dynamic_parse_fail[key] = true
      out.diagnostics[#out.diagnostics + 1] = {
        code = code,
        message = message,
        line = 1,
        col = 1,
        severity = severity
      }
    end
    emit_dynamic_items(
      push_dynamic_diag_parse_fail,
      out.dynamic.global_reads,
      dynamic_diag_limit,
      'dynamic-global-read',
      'info',
      function(item)
        return "runtime read global '" .. tostring(item.name) .. "' x" .. tostring(item.count)
      end,
      function(item)
        return item and item.name and item.name ~= '_G' and item.name ~= '_ENV'
      end
    )
    emit_dynamic_items(
      push_dynamic_diag_parse_fail,
      out.dynamic.global_writes,
      dynamic_diag_limit,
      'dynamic-global-write',
      'warning',
      function(item)
        return "runtime write global '" .. tostring(item.name) .. "' x" .. tostring(item.count)
      end,
      function(item)
        return item and item.name and item.name ~= '_G' and item.name ~= '_ENV'
      end
    )
    emit_dynamic_items(
      push_dynamic_diag_parse_fail,
      out.dynamic.undefined_global_reads,
      dynamic_diag_limit,
      'dynamic-undefined-global-read',
      'warning',
      function(item)
        return "runtime read undefined global '" .. tostring(item.name) .. "' x" .. tostring(item.count)
      end,
      function(item)
        return item and item.name
      end
    )
    emit_dynamic_items(
      push_dynamic_diag_parse_fail,
      out.dynamic.require_calls,
      dynamic_diag_limit,
      'dynamic-require',
      'info',
      function(item)
        return "runtime require '" .. tostring(item.name) .. "' x" .. tostring(item.count)
      end,
      function(item)
        return item and item.name
      end
    )
    emit_dynamic_items(
      push_dynamic_diag_parse_fail,
      out.dynamic.events,
      dynamic_diag_limit,
      'dynamic-sandbox-event',
      'info',
      function(item)
        return "[" .. tostring(item.level) .. "] " .. tostring(item.code) .. ': ' .. tostring(item.message) .. " x" .. tostring(item.count)
      end,
      nil
    )
    if out.dynamic.execution then
      local ex = out.dynamic.execution
      if (ex.probes_omitted or 0) > 0 then
        out.diagnostics[#out.diagnostics + 1] = {
          code = 'dynamic-probe-truncated',
          message = 'dynamic probe targets omitted: ' .. tostring(ex.probes_omitted),
          line = 1,
          col = 1,
          severity = 'info'
        }
      end
      if (ex.probes_failed or 0) > 0 then
        out.diagnostics[#out.diagnostics + 1] = {
          code = 'dynamic-probe-failed',
          message = 'dynamic probe failures: ' .. tostring(ex.probes_failed),
          line = 1,
          col = 1,
          severity = 'warning'
        }
      end
      emit_dynamic_items(
        push_dynamic_diag_parse_fail,
        ex.probe_errors,
        dynamic_diag_limit,
        'dynamic-probe-error',
        'info',
        function(item)
          return "probe error '" .. tostring(item.name) .. "' x" .. tostring(item.count)
        end,
        function(item)
          return item and item.name
        end
      )
    end
    if out.dynamic.map_stats then
      local ms = out.dynamic.map_stats
      local omitted = (ms.all_global_reads and ms.all_global_reads.omitted or 0)
        + (ms.resolved_global_reads and ms.resolved_global_reads.omitted or 0)
        + (ms.global_reads and ms.global_reads.omitted or 0)
        + (ms.global_writes and ms.global_writes.omitted or 0)
        + (ms.undefined_global_reads and ms.undefined_global_reads.omitted or 0)
        + (ms.proxy_root_reads and ms.proxy_root_reads.omitted or 0)
        + (ms.proxy_reads and ms.proxy_reads.omitted or 0)
        + (ms.require_calls and ms.require_calls.omitted or 0)
        + (ms.metatable_gets and ms.metatable_gets.omitted or 0)
        + (ms.metatable_sets and ms.metatable_sets.omitted or 0)
        + (ms.metatable_metamethods and ms.metatable_metamethods.omitted or 0)
        + (ms.history and ms.history.omitted or 0)
        + (ms.events and ms.events.omitted or 0)
      if omitted > 0 then
        out.diagnostics[#out.diagnostics + 1] = {
          code = 'dynamic-truncated',
          message = 'dynamic result entries truncated: ' .. tostring(omitted),
          line = 1,
          col = 1,
          severity = 'info'
        }
      end
    end
    if out.dynamic.runtime and out.dynamic.runtime.main and out.dynamic.runtime.main.error then
      local detail_msg = tostring(out.dynamic.runtime.main.error)
      local base_msg = out.dynamic.error and tostring(out.dynamic.error) or nil
      if detail_msg ~= '' and detail_msg ~= base_msg then
        out.diagnostics[#out.diagnostics + 1] = {
          code = 'dynamic-runtime-detail',
          message = detail_msg,
          line = 1,
          col = 1,
          severity = 'warning'
        }
      end
    end
    if (out.dynamic.duration_ms or 0) > 2000 then
      out.diagnostics[#out.diagnostics + 1] = {
        code = 'dynamic-slow',
        message = 'dynamic lint runtime is slow: ' .. tostring(out.dynamic.duration_ms) .. 'ms',
        line = 1,
        col = 1,
        severity = 'info'
      }
    end
    out.summary = build_summary(out.diagnostics)
  end
  return out
end

function Linter.format_report(result, input_filepath)
  local out = {}
  out[#out + 1] = 'lint report'
  out[#out + 1] = 'file: ' .. tostring(input_filepath or '')
  out[#out + 1] = string.format(
    'summary: total=%d error=%d warning=%d info=%d',
    result.summary.total or 0,
    result.summary.error or 0,
    result.summary.warning or 0,
    result.summary.info or 0
  )
  out[#out + 1] = ''

  if #result.diagnostics == 0 then
    out[#out + 1] = 'no issues found'
    return table.concat(out, '\n')
  end

  for _, d in ipairs(result.diagnostics) do
    out[#out + 1] = string.format(
      '%s:%d:%d: %s [%s] %s',
      tostring(input_filepath or ''),
      d.line or 1,
      d.col or 1,
      d.severity or 'warning',
      d.code or 'lint',
      d.message or ''
    )
  end

  return table.concat(out, '\n')
end

return Linter
