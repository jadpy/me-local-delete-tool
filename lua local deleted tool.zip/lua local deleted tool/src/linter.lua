local Lexer = require('src.lexer')
local Parser = require('src.parser')

local Linter = {}

local known_globals = {
  _G = true, _VERSION = true, assert = true, collectgarbage = true, dofile = true, error = true,
  getmetatable = true, ipairs = true, load = true, loadfile = true, next = true, pairs = true,
  pcall = true, print = true, rawequal = true, rawget = true, rawlen = true, rawset = true,
  require = true, select = true, setmetatable = true, tonumber = true, tostring = true, type = true,
  xpcall = true, coroutine = true, string = true, table = true, math = true, io = true, os = true,
  debug = true, utf8 = true, package = true, bit32 = true, warn = true,
  game = true, workspace = true, script = true, Enum = true, Instance = true,
  Vector3 = true, CFrame = true, UDim2 = true, Color3 = true
}

local protected_globals = {
  _G = true, _VERSION = true, assert = true, collectgarbage = true, dofile = true, error = true,
  getmetatable = true, ipairs = true, load = true, loadfile = true, next = true, pairs = true,
  pcall = true, print = true, rawequal = true, rawget = true, rawlen = true, rawset = true,
  require = true, select = true, setmetatable = true, tonumber = true, tostring = true, type = true,
  xpcall = true, coroutine = true, string = true, table = true, math = true, io = true, os = true,
  debug = true, utf8 = true, package = true, bit32 = true
}

local arithmetic_ops = {
  ['+'] = true, ['-'] = true, ['*'] = true, ['/'] = true, ['//'] = true, ['%'] = true, ['^'] = true
}

local function new_scope(parent)
  return { parent = parent, locals = {} }
end

local function lookup(scope, name)
  local cur = scope
  while cur do
    local sym = cur.locals[name]
    if sym then
      return sym
    end
    cur = cur.parent
  end
  return nil
end

local function lookup_parent(scope, name)
  if not scope then return nil end
  return lookup(scope.parent, name)
end

local function add_type(sym, typ)
  if not sym or not typ or typ == 'unknown' then
    return
  end
  sym.types[typ] = true
end

local function get_single_type(sym)
  if not sym then return nil end
  local count = 0
  local last = nil
  for t, _ in pairs(sym.types) do
    count = count + 1
    last = t
    if count > 1 then
      return nil
    end
  end
  return last
end

local function is_literal_type(t)
  return t == 'number' or t == 'string' or t == 'boolean' or t == 'nil' or t == 'table' or t == 'function'
end

local function stmt_pos(stmt)
  if not stmt then return 1, 1 end
  if stmt.token and stmt.token.line then
    return stmt.token.line, stmt.token.col or 1
  end
  if stmt.source_line then
    return stmt.source_line, 1
  end
  return 1, 1
end

local function expr_pos(node)
  if not node then return 1, 1 end
  if node.token and node.token.line then
    return node.token.line, node.token.col or 1
  end
  if node.source_line then
    return node.source_line, 1
  end
  return 1, 1
end

local function add_diag(state, code, message, line, col, severity)
  local key = string.format('%s|%s|%s|%s', code, tostring(line or 1), tostring(col or 1), message)
  if state.diag_seen[key] then
    return
  end
  state.diag_seen[key] = true
  state.diagnostics[#state.diagnostics + 1] = {
    code = code,
    message = message,
    line = line or 1,
    col = col or 1,
    severity = severity or 'warning'
  }
end

local function declare_symbol(state, scope, name, kind, line, col)
  local current = scope.locals[name]
  if current then
    add_diag(state, 'duplicate-local', "duplicate local declaration '" .. name .. "'", line, col, 'warning')
  else
    local outer = lookup_parent(scope, name)
    if outer and not tostring(name):match('^_') then
      add_diag(state, 'shadowing', "local '" .. name .. "' shadows outer local", line, col, 'info')
    end
  end

  local sym = {
    name = name,
    kind = kind,
    line = line or 1,
    col = col or 1,
    refs = 0,
    types = {}
  }
  scope.locals[name] = sym
  state.symbols[#state.symbols + 1] = sym
  return sym
end

local function infer_expr_type(node, scope)
  if not node or type(node) ~= 'table' then
    return 'unknown'
  end
  local t = node.type

  if t == 'Number' then return 'number' end
  if t == 'String' then return 'string' end
  if t == 'Boolean' then return 'boolean' end
  if t == 'Nil' then return 'nil' end
  if t == 'Table' then return 'table' end
  if t == 'Function' then return 'function' end

  if t == 'Identifier' then
    local sym = lookup(scope, node.name)
    if sym then
      local one = get_single_type(sym)
      if one then
        return one
      end
    end
    return 'unknown'
  end

  if t == 'UnaryOp' then
    if node.op == 'not' then return 'boolean' end
    if node.op == '-' then return 'number' end
    if node.op == '#' then return 'number' end
    return 'unknown'
  end

  if t == 'BinaryOp' then
    local op = node.op
    if arithmetic_ops[op] then
      return 'number'
    end
    if op == '..' then
      return 'string'
    end
    if op == '<' or op == '<=' or op == '>' or op == '>=' or op == '==' or op == '~=' then
      return 'boolean'
    end
    if op == 'and' or op == 'or' then
      local lt = infer_expr_type(node.left, scope)
      local rt = infer_expr_type(node.right, scope)
      if lt == rt and lt ~= 'unknown' then
        return lt
      end
      return 'unknown'
    end
  end

  return 'unknown'
end

local function has_side_effect(node)
  if not node or type(node) ~= 'table' then
    return false
  end
  local t = node.type

  if t == 'FunctionCall' or t == 'MethodCall' then
    return true
  end
  if t == 'BinaryOp' then
    return has_side_effect(node.left) or has_side_effect(node.right)
  end
  if t == 'UnaryOp' then
    return has_side_effect(node.operand)
  end
  if t == 'IndexExpr' then
    return has_side_effect(node.object) or has_side_effect(node.index)
  end
  if t == 'PropertyExpr' then
    return has_side_effect(node.object)
  end
  if t == 'Table' then
    for _, f in ipairs(node.fields or {}) do
      if has_side_effect(f.key) or has_side_effect(f.value) then
        return true
      end
    end
  end
  return false
end

local function split_identifier_path(path)
  local parts = {}
  if type(path) ~= 'string' then
    return parts
  end
  for name in path:gmatch('([%a_][%w_]*)') do
    parts[#parts + 1] = name
  end
  return parts
end

local analyze_expr
local analyze_stmt
local analyze_block
local block_guarantees_termination
local stmt_guarantees_termination

analyze_expr = function(state, node, scope)
  if not node or type(node) ~= 'table' then
    return
  end
  local t = node.type

  if t == 'Identifier' then
    local sym = lookup(scope, node.name)
    if sym then
      sym.refs = sym.refs + 1
    elseif not known_globals[node.name] then
      local ln, cl = expr_pos(node)
      add_diag(state, 'undefined-reference', "undefined reference '" .. node.name .. "'", ln, cl, 'warning')
    end
    return
  end

  if t == 'BinaryOp' then
    analyze_expr(state, node.left, scope)
    analyze_expr(state, node.right, scope)

    if arithmetic_ops[node.op] then
      local lt = infer_expr_type(node.left, scope)
      local rt = infer_expr_type(node.right, scope)
      if lt ~= 'unknown' and rt ~= 'unknown' and (lt ~= 'number' or rt ~= 'number') then
        local ln, cl = expr_pos(node.left)
        add_diag(state, 'type-mismatch', "arithmetic '" .. node.op .. "' expects number operands", ln, cl, 'warning')
      end
    elseif node.op == '..' then
      local lt = infer_expr_type(node.left, scope)
      local rt = infer_expr_type(node.right, scope)
      local left_ok = lt == 'string' or lt == 'number' or lt == 'unknown'
      local right_ok = rt == 'string' or rt == 'number' or rt == 'unknown'
      if not left_ok or not right_ok then
        local ln, cl = expr_pos(node.left)
        add_diag(state, 'type-mismatch', "concat '..' expects string/number operands", ln, cl, 'warning')
      end
    elseif node.op == '==' or node.op == '~=' then
      local lt = infer_expr_type(node.left, scope)
      local rt = infer_expr_type(node.right, scope)
      if lt ~= 'unknown' and rt ~= 'unknown' and lt ~= rt and is_literal_type(lt) and is_literal_type(rt) then
        local ln, cl = expr_pos(node.left)
        add_diag(state, 'suspicious-compare', "comparing different literal types: " .. lt .. ' and ' .. rt, ln, cl, 'info')
      end
    end
    return
  end

  if t == 'UnaryOp' then
    analyze_expr(state, node.operand, scope)
    if node.op == '-' then
      local ot = infer_expr_type(node.operand, scope)
      if ot ~= 'unknown' and ot ~= 'number' then
        local ln, cl = expr_pos(node.operand)
        add_diag(state, 'type-mismatch', "unary '-' expects number operand", ln, cl, 'warning')
      end
    end
    return
  end

  if t == 'FunctionCall' then
    analyze_expr(state, node.callee, scope)
    for _, arg in ipairs(node.args or {}) do
      analyze_expr(state, arg, scope)
    end
    local ct = infer_expr_type(node.callee, scope)
    if ct ~= 'unknown' and ct ~= 'function' then
      local ln, cl = expr_pos(node.callee)
      add_diag(state, 'call-non-function', 'attempt to call non-function value of type ' .. ct, ln, cl, 'warning')
    end
    return
  end

  if t == 'MethodCall' then
    analyze_expr(state, node.object, scope)
    for _, arg in ipairs(node.args or {}) do
      analyze_expr(state, arg, scope)
    end
    return
  end

  if t == 'IndexExpr' then
    analyze_expr(state, node.object, scope)
    analyze_expr(state, node.index, scope)
    return
  end

  if t == 'PropertyExpr' then
    analyze_expr(state, node.object, scope)
    return
  end

  if t == 'Table' then
    for _, f in ipairs(node.fields or {}) do
      if f.key then
        analyze_expr(state, f.key, scope)
      end
      analyze_expr(state, f.value, scope)
    end
    return
  end

  if t == 'Function' then
    local fn_scope = new_scope(scope)
    for i, p in ipairs(node.params or {}) do
      local tok = node.param_tokens and node.param_tokens[i] or nil
      local line = tok and tok.line or (node.source_line or 1)
      local col = tok and tok.col or 1
      declare_symbol(state, fn_scope, p, 'param', line, col)
    end
    analyze_block(state, node.body, fn_scope)
    return
  end
end

local function analyze_assignment_target(state, target, scope, value_type, value_node)
  if not target then return end

  if target.type == 'Identifier' then
    local sym = lookup(scope, target.name)
    if sym then
      local old_single = get_single_type(sym)
      if old_single and value_type and value_type ~= 'unknown' and value_type ~= old_single and is_literal_type(old_single) then
        local ln, cl = expr_pos(target)
        add_diag(
          state,
          'type-mismatch',
          "local '" .. target.name .. "' changes type from " .. old_single .. ' to ' .. value_type,
          ln,
          cl,
          'warning'
        )
      end
      add_type(sym, value_type)
    else
      local ln, cl = expr_pos(target)
      if protected_globals[target.name] then
        add_diag(state, 'global-overwrite', "assignment to protected global '" .. target.name .. "'", ln, cl, 'warning')
      elseif not known_globals[target.name] then
        add_diag(state, 'global-write', "assignment to undeclared global '" .. target.name .. "'", ln, cl, 'warning')
      end
    end

    if value_node and value_node.type == 'Identifier' and value_node.name == target.name then
      local ln, cl = expr_pos(target)
      add_diag(state, 'self-assignment', "self-assignment on '" .. target.name .. "'", ln, cl, 'info')
    end
    return
  end

  if target.type == 'IndexExpr' then
    analyze_expr(state, target.object, scope)
    analyze_expr(state, target.index, scope)
    return
  end

  if target.type == 'PropertyExpr' then
    analyze_expr(state, target.object, scope)
    return
  end

  analyze_expr(state, target, scope)
end

analyze_stmt = function(state, stmt, scope)
  if not stmt then return end
  local t = stmt.type

  if t == 'LocalDecl' then
    for _, v in ipairs(stmt.values or {}) do
      analyze_expr(state, v, scope)
    end

    local name_tokens = stmt.name_tokens or {}
    for i, name in ipairs(stmt.names or {}) do
      local tok = name_tokens[i]
      local line = tok and tok.line or (stmt.source_line or 1)
      local col = tok and tok.col or 1
      local sym = declare_symbol(state, scope, name, 'local', line, col)
      local v = stmt.values and stmt.values[i] or nil
      if v then
        add_type(sym, infer_expr_type(v, scope))
      end
    end
    return
  end

  if t == 'LocalFunc' then
    local nt = stmt.name_token
    local line = nt and nt.line or (stmt.source_line or 1)
    local col = nt and nt.col or 1
    local sym = declare_symbol(state, scope, stmt.name, 'localfunc', line, col)
    add_type(sym, 'function')
    analyze_expr(state, stmt.body, scope)
    return
  end

  if t == 'FunctionDecl' then
    local parts = split_identifier_path(stmt.name)
    local head = parts[1]
    if head then
      local sym = lookup(scope, head)
      if sym then
        sym.refs = sym.refs + 1
      elseif (stmt.name:find('%.', 1, true) or stmt.name:find(':', 1, true)) and not known_globals[head] then
        local line = stmt.source_line or 1
        add_diag(state, 'undefined-reference', "base table '" .. head .. "' may be undefined", line, 1, 'info')
      end
    end

    local fn_scope = new_scope(scope)
    if stmt.name and stmt.name:find(':', 1, true) then
      declare_symbol(state, fn_scope, 'self', 'param', stmt.source_line or 1, 1)
    end
    for i, p in ipairs(stmt.params or {}) do
      local tok = stmt.param_tokens and stmt.param_tokens[i] or nil
      local line = tok and tok.line or (stmt.source_line or 1)
      local col = tok and tok.col or 1
      declare_symbol(state, fn_scope, p, 'param', line, col)
    end
    analyze_block(state, stmt.body, fn_scope)
    return
  end

  if t == 'If' then
    analyze_expr(state, stmt.condition, scope)
    analyze_block(state, stmt.then_body, new_scope(scope))
    for _, p in ipairs(stmt.elseif_parts or {}) do
      analyze_expr(state, p.condition, scope)
      analyze_block(state, p.body, new_scope(scope))
    end
    if stmt.else_body then
      analyze_block(state, stmt.else_body, new_scope(scope))
    end
    return
  end

  if t == 'While' then
    analyze_expr(state, stmt.condition, scope)
    analyze_block(state, stmt.body, new_scope(scope))
    return
  end

  if t == 'Repeat' then
    local rep_scope = new_scope(scope)
    analyze_block(state, stmt.body, rep_scope)
    analyze_expr(state, stmt.condition, rep_scope)
    return
  end

  if t == 'For' then
    analyze_expr(state, stmt.start, scope)
    analyze_expr(state, stmt.finish, scope)
    if stmt.step then
      analyze_expr(state, stmt.step, scope)
    end

    local for_scope = new_scope(scope)
    local vt = stmt.var_token
    local line = vt and vt.line or (stmt.source_line or 1)
    local col = vt and vt.col or 1
    local sym = declare_symbol(state, for_scope, stmt.var, 'forvar', line, col)
    add_type(sym, 'number')
    analyze_block(state, stmt.body, for_scope)
    return
  end

  if t == 'ForIn' then
    for _, iter in ipairs(stmt.iterators or {}) do
      analyze_expr(state, iter, scope)
    end
    local for_scope = new_scope(scope)
    local vars = stmt.vars or {}
    local tokens = stmt.var_tokens or {}
    for i, name in ipairs(vars) do
      local tok = tokens[i]
      local line = tok and tok.line or (stmt.source_line or 1)
      local col = tok and tok.col or 1
      declare_symbol(state, for_scope, name, 'forvar', line, col)
    end
    analyze_block(state, stmt.body, for_scope)
    return
  end

  if t == 'Do' then
    analyze_block(state, stmt.body, new_scope(scope))
    return
  end

  if t == 'Assignment' then
    for _, v in ipairs(stmt.values or {}) do
      analyze_expr(state, v, scope)
    end
    for i, target in ipairs(stmt.targets or {}) do
      local v = stmt.values and stmt.values[i] or nil
      analyze_assignment_target(state, target, scope, infer_expr_type(v, scope), v)
    end
    return
  end

  if t == 'Return' then
    for _, v in ipairs(stmt.values or {}) do
      analyze_expr(state, v, scope)
    end
    return
  end

  if t == 'Break' then
    return
  end

  analyze_expr(state, stmt, scope)
  if not has_side_effect(stmt) then
    local line, col = stmt_pos(stmt)
    add_diag(state, 'useless-expression', 'expression statement has no side effects', line, col, 'info')
  end
end

stmt_guarantees_termination = function(stmt)
  if not stmt or type(stmt) ~= 'table' then
    return false
  end
  local t = stmt.type
  if t == 'Return' or t == 'Break' then
    return true
  end
  if t == 'Do' then
    return block_guarantees_termination(stmt.body)
  end
  if t == 'If' then
    if not stmt.else_body then
      return false
    end
    if not block_guarantees_termination(stmt.then_body) then
      return false
    end
    for _, p in ipairs(stmt.elseif_parts or {}) do
      if not block_guarantees_termination(p.body) then
        return false
      end
    end
    if not block_guarantees_termination(stmt.else_body) then
      return false
    end
    return true
  end
  return false
end

block_guarantees_termination = function(block)
  if not block or not block.statements then
    return false
  end
  for _, stmt in ipairs(block.statements) do
    if stmt_guarantees_termination(stmt) then
      return true
    end
  end
  return false
end

analyze_block = function(state, block, scope)
  if not block or not block.statements then
    return
  end
  local terminated = false
  for _, stmt in ipairs(block.statements) do
    if terminated then
      local line, col = stmt_pos(stmt)
      add_diag(state, 'unreachable-code', 'statement is unreachable', line, col, 'warning')
      break
    end
    analyze_stmt(state, stmt, scope)
    if stmt_guarantees_termination(stmt) then
      terminated = true
    end
  end
end

local function finalize_unused(state)
  for _, sym in ipairs(state.symbols) do
    local is_local_kind = sym.kind == 'local' or sym.kind == 'param' or sym.kind == 'forvar' or sym.kind == 'localfunc'
    if is_local_kind and sym.refs == 0 and not tostring(sym.name):match('^_') then
      add_diag(state, 'unused-variable', "unused " .. sym.kind .. " '" .. sym.name .. "'", sym.line, sym.col, 'warning')
    end
  end
end

local function sort_diags(diags)
  table.sort(diags, function(a, b)
    if a.line ~= b.line then return a.line < b.line end
    if a.col ~= b.col then return a.col < b.col end
    if a.severity ~= b.severity then return a.severity < b.severity end
    return a.code < b.code
  end)
end

local function build_summary(diags)
  local summary = {
    total = #diags,
    warning = 0,
    info = 0,
    error = 0,
    by_code = {}
  }
  for _, d in ipairs(diags) do
    summary[d.severity] = (summary[d.severity] or 0) + 1
    summary.by_code[d.code] = (summary.by_code[d.code] or 0) + 1
  end
  return summary
end

function Linter.run(source)
  local ok, result = pcall(function()
    local tokens = Lexer.new(source):tokenize()
    local parser = Parser.new(tokens)
    local ast = parser:parse()

    local state = {
      diagnostics = {},
      diag_seen = {},
      symbols = {}
    }

    local root = new_scope(nil)
    analyze_block(state, ast.body, root)
    finalize_unused(state)
    sort_diags(state.diagnostics)

    return {
      ok = true,
      diagnostics = state.diagnostics,
      summary = build_summary(state.diagnostics)
    }
  end)

  if ok then
    return result
  end

  local diags = {
    {
      code = 'parse-error',
      message = tostring(result),
      line = 1,
      col = 1,
      severity = 'error'
    }
  }
  return {
    ok = false,
    diagnostics = diags,
    summary = build_summary(diags)
  }
end

function Linter.format_report(result, input_filepath)
  local out = {}
  out[#out + 1] = 'lint report'
  out[#out + 1] = 'file: ' .. tostring(input_filepath or '')
  out[#out + 1] = string.format(
    'summary: total=%d error=%d warning=%d info=%d',
    result.summary.total or 0,
    result.summary.error or 0,
    result.summary.warning or 0,
    result.summary.info or 0
  )
  out[#out + 1] = ''

  if #result.diagnostics == 0 then
    out[#out + 1] = 'no issues found'
    return table.concat(out, '\n')
  end

  for _, d in ipairs(result.diagnostics) do
    out[#out + 1] = string.format(
      '%s:%d:%d: %s [%s] %s',
      tostring(input_filepath or ''),
      d.line or 1,
      d.col or 1,
      d.severity or 'warning',
      d.code or 'lint',
      d.message or ''
    )
  end

  return table.concat(out, '\n')
end

return Linter
