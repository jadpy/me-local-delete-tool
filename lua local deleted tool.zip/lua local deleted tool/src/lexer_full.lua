local LexerFull = {}

local Token = {}
function Token.new(type, value, line, col, extra)
  local tok = { type = type, value = value, line = line, col = col }
  if extra then
    for k, v in pairs(extra) do tok[k] = v end
  end
  return tok
end

local function is_digit(ch)
  local b = ch and ch:byte() or nil
  return b and b >= 48 and b <= 57
end

local function is_hex_digit(ch)
  local b = ch and ch:byte() or nil
  if not b then return false end
  return (b >= 48 and b <= 57) or (b >= 65 and b <= 70) or (b >= 97 and b <= 102)
end

local function is_ident_start(ch)
  local b = ch and ch:byte() or nil
  if not b then return false end
  if (b >= 65 and b <= 90) or (b >= 97 and b <= 122) or ch == '_' then
    return true
  end
  return b >= 0x80
end

local function is_ident_part(ch)
  local b = ch and ch:byte() or nil
  if not b then return false end
  if (b >= 48 and b <= 57) or (b >= 65 and b <= 90) or (b >= 97 and b <= 122) or ch == '_' then
    return true
  end
  return b >= 0x80
end

function LexerFull.new(source)
  local self = {
    source = source or '',
    pos = 1,
    line = 1,
    col = 1,
    len = #(source or ''),
    current_char = (source or ''):sub(1, 1),
    tokens = {}
  }
  return setmetatable(self, { __index = LexerFull })
end

function LexerFull:peek(offset)
  offset = offset or 1
  return self.source:sub(self.pos + offset, self.pos + offset)
end

function LexerFull:advance(n)
  n = n or 1
  for _ = 1, n do
    local ch = self.current_char
    if ch == '' then
      return
    end
    if ch == '\r' then
      if self:peek() == '\n' then
        self.pos = self.pos + 1
      end
      self.line = self.line + 1
      self.col = 1
    elseif ch == '\n' then
      self.line = self.line + 1
      self.col = 1
    else
      self.col = self.col + 1
    end
    self.pos = self.pos + 1
    self.current_char = self.source:sub(self.pos, self.pos)
  end
end

function LexerFull:long_bracket_level()
  if self.current_char ~= '[' then return nil end
  local i = 1
  local eq = 0
  while self:peek(i) == '=' do
    eq = eq + 1
    i = i + 1
  end
  if self:peek(i) == '[' then
    return eq
  end
  return nil
end

function LexerFull:read_long_bracket(eq)
  local value = ''
  value = value .. '[' .. string.rep('=', eq) .. '['
  self:advance()
  if eq > 0 then
    self:advance(eq)
  end
  self:advance()
  while self.current_char ~= '' do
    if self.current_char == ']' then
      local ok = true
      for i = 1, eq do
        if self:peek(i) ~= '=' then
          ok = false
          break
        end
      end
      if ok and self:peek(eq + 1) == ']' then
        value = value .. ']' .. string.rep('=', eq) .. ']'
        self:advance()
        if eq > 0 then
          self:advance(eq)
        end
        self:advance()
        break
      end
    end
    value = value .. self.current_char
    self:advance()
  end
  return value
end

function LexerFull:read_short_string(quote)
  local line = self.line
  local col = self.col
  local value = quote
  self:advance()
  while self.current_char ~= '' do
    local ch = self.current_char
    value = value .. ch
    if ch == '\\' then
      self:advance()
      if self.current_char == '' then
        break
      end
      value = value .. self.current_char
      self:advance()
    elseif ch == quote then
      self:advance()
      break
    else
      self:advance()
    end
  end
  return Token.new('string', value, line, col)
end

function LexerFull:read_number()
  local line = self.line
  local col = self.col
  local value = ''
  local function add()
    value = value .. self.current_char
    self:advance()
  end

  if self.current_char == '0' and (self:peek() == 'x' or self:peek() == 'X') then
    add()
    add()
    while is_hex_digit(self.current_char) do add() end
    if self.current_char == '.' and self:peek() ~= '.' then
      add()
      while is_hex_digit(self.current_char) do add() end
    end
    if self.current_char == 'p' or self.current_char == 'P' then
      add()
      if self.current_char == '+' or self.current_char == '-' then add() end
      while is_digit(self.current_char) do add() end
    end
  elseif self.current_char == '0' and (self:peek() == 'b' or self:peek() == 'B') then
    add()
    add()
    while self.current_char == '0' or self.current_char == '1' do add() end
    if self.current_char == '.' and self:peek() ~= '.' then
      add()
      while self.current_char == '0' or self.current_char == '1' do add() end
    end
    if self.current_char == 'e' or self.current_char == 'E' or self.current_char == 'p' or self.current_char == 'P' then
      add()
      if self.current_char == '+' or self.current_char == '-' then add() end
      while is_digit(self.current_char) do add() end
    end
  else
    while is_digit(self.current_char) do add() end
    if self.current_char == '.' and self:peek() ~= '.' then
      add()
      while is_digit(self.current_char) do add() end
    end
    if self.current_char == 'e' or self.current_char == 'E' then
      add()
      if self.current_char == '+' or self.current_char == '-' then add() end
      while is_digit(self.current_char) do add() end
    end
  end

  return Token.new('number', value, line, col)
end

function LexerFull:read_identifier()
  local line = self.line
  local col = self.col
  local value = ''
  while self.current_char ~= '' and is_ident_part(self.current_char) do
    value = value .. self.current_char
    self:advance()
  end
  local keywords = {
    ['and'] = true, ['break'] = true, ['do'] = true, ['else'] = true, ['elseif'] = true,
    ['end'] = true, ['false'] = true, ['for'] = true, ['function'] = true, ['if'] = true,
    ['in'] = true, ['local'] = true, ['nil'] = true, ['not'] = true, ['or'] = true,
    ['repeat'] = true, ['return'] = true, ['then'] = true, ['true'] = true, ['until'] = true,
    ['while'] = true, ['goto'] = true, ['continue'] = true, ['type'] = true, ['export'] = true
  }
  if keywords[value] then
    return Token.new('keyword', value, line, col)
  end
  return Token.new('ident', value, line, col)
end

function LexerFull:read_comment()
  local line = self.line
  local col = self.col
  local value = '--'
  self:advance(2)
  if self.current_char == '[' then
    local eq = self:long_bracket_level()
    if eq ~= nil then
      local bracket = self:read_long_bracket(eq)
      value = value .. bracket
      return Token.new('comment', value, line, col, { is_block = true })
    end
  end
  while self.current_char ~= '' and self.current_char ~= '\n' and self.current_char ~= '\r' do
    value = value .. self.current_char
    self:advance()
  end
  return Token.new('comment', value, line, col, { is_block = false })
end

function LexerFull:read_symbol()
  local line = self.line
  local col = self.col
  local symbols = {
    '...',
    '..=',
    '==', '~=', '<=', '>=', '<<', '>>', '//', '::',
    '+=', '-=', '*=', '/=', '%=', '^=', '&=', '|=',
    '->', '=>', ':=',
    '&&', '||',
    '..'
  }
  for _, sym in ipairs(symbols) do
    if self.source:sub(self.pos, self.pos + #sym - 1) == sym then
      self:advance(#sym)
      return Token.new('symbol', sym, line, col)
    end
  end
  local ch = self.current_char
  self:advance()
  return Token.new('symbol', ch, line, col)
end

function LexerFull:tokenize()
  while self.current_char ~= '' do
    local ch = self.current_char
    if ch == ' ' or ch == '\t' or ch == '\v' or ch == '\f' then
      self:advance()
    elseif ch == '\r' or ch == '\n' then
      local line = self.line
      local col = self.col
      local value = ch
      if ch == '\r' and self:peek() == '\n' then
        value = '\r\n'
      end
      table.insert(self.tokens, Token.new('newline', value, line, col))
      self:advance()
    elseif ch == '-' and self:peek() == '-' then
      table.insert(self.tokens, self:read_comment())
    elseif ch == '"' or ch == "'" then
      table.insert(self.tokens, self:read_short_string(ch))
    elseif ch == '[' then
      local eq = self:long_bracket_level()
      if eq ~= nil then
        local line = self.line
        local col = self.col
        local value = self:read_long_bracket(eq)
        table.insert(self.tokens, Token.new('long_string', value, line, col))
      else
        table.insert(self.tokens, self:read_symbol())
      end
    elseif is_digit(ch) or (ch == '.' and is_digit(self:peek())) then
      table.insert(self.tokens, self:read_number())
    elseif is_ident_start(ch) then
      table.insert(self.tokens, self:read_identifier())
    else
      table.insert(self.tokens, self:read_symbol())
    end
  end
  return self.tokens
end

return LexerFull
