local LintSandbox = {}
local make_proxy

local function record(map, key)
  map[key] = (map[key] or 0) + 1
end

local function push_history(trace, kind, message)
  if not trace then
    return
  end
  local max_history = tonumber(trace.max_history) or 240
  if max_history <= 0 then
    return
  end
  trace._history_total = (trace._history_total or 0) + 1
  if #trace.history >= max_history then
    trace._history_omitted = (trace._history_omitted or 0) + 1
    return
  end
  trace.history[#trace.history + 1] = {
    seq = trace._history_total,
    kind = tostring(kind or 'event'),
    message = tostring(message or '')
  }
end

local function describe_value(v)
  local tv = type(v)
  if tv == 'table' then
    local p = rawget(v, '__path')
    if p then
      return 'proxy:' .. tostring(p)
    end
    return 'table'
  end
  if tv == 'function' then
    return 'function:' .. tostring(v)
  end
  return tv .. ':' .. tostring(v)
end

local function record_event(trace, level, code, message)
  if not trace then
    return
  end
  local lev = tostring(level or 'info')
  local cod = tostring(code or 'sandbox-event')
  local msg = tostring(message or '')
  local key = lev .. '|' .. cod .. '|' .. msg
  local row = trace._event_map[key]
  if row then
    row.count = row.count + 1
    return
  end
  row = {
    level = lev,
    code = cod,
    message = msg,
    count = 1
  }
  trace._event_map[key] = row
  trace.events[#trace.events + 1] = row
  push_history(trace, 'event:' .. cod, msg)
end

local known_services = {
  Players = true, Workspace = true, ReplicatedStorage = true, ServerScriptService = true,
  ServerStorage = true, StarterGui = true, StarterPack = true, StarterPlayer = true,
  Lighting = true, TweenService = true, RunService = true, UserInputService = true,
  HttpService = true, TeleportService = true, CollectionService = true,
  MarketplaceService = true, SoundService = true, Teams = true, Chat = true,
  TextChatService = true, GuiService = true, ContextActionService = true,
  PathfindingService = true, PhysicsService = true, BadgeService = true,
  LocalizationService = true, SocialService = true, ProximityPromptService = true,
  VRService = true
}

local function get_proxy(cache, path, reads)
  local p = cache[path]
  if p then
    return p
  end
  p = make_proxy(path, reads, cache)
  cache[path] = p
  return p
end

make_proxy = function(path, reads, cache)
  local obj = { __path = path or '<proxy>' }
  local tr = cache and cache.__trace or nil
  local function record_op(op)
    local p = obj.__path .. ':' .. tostring(op)
    record(reads, p)
    push_history(tr, 'proxy-op', p)
  end
  local mt = {
    __index = function(self, key)
      local p = self.__path .. '.' .. tostring(key)
      record(reads, p)
      push_history(tr, 'proxy-index', p)
      return get_proxy(cache, p, reads)
    end,
    __newindex = function(self, key, _)
      local p = self.__path .. '.' .. tostring(key)
      record(reads, p)
      push_history(tr, 'proxy-newindex', p)
    end,
    __call = function(self, ...)
      local p = self.__path .. '()'
      record(reads, p)
      push_history(tr, 'proxy-call', p)

      local arg1 = select(1, ...)
      local arg2 = select(2, ...)
      local method = self.__path:match('%.([%a_][%w_]*)$')
      if method == 'GetService' then
        local service = type(arg2) == 'string' and arg2 or (type(arg1) == 'string' and arg1 or nil)
        if service and service ~= '' then
          push_history(tr, 'dependency:service', tostring(service))
          if not known_services[service] then
            if tr then
              record_event(tr, 'warning', 'unknown-service', "GetService('" .. tostring(service) .. "') is not in known service list")
            end
          end
          return get_proxy(cache, service, reads)
        end
        if tr then
          record_event(tr, 'warning', 'invalid-getservice', 'GetService called without a valid service name')
        end
      elseif method == 'WaitForChild' or method == 'FindFirstChild' or method == 'FindFirstChildOfClass' or method == 'FindFirstChildWhichIsA' then
        local child = type(arg2) == 'string' and arg2 or (type(arg1) == 'string' and arg1 or nil)
        if child and child ~= '' then
          local base = self.__path:gsub('%.([%a_][%w_]*)$', '')
          push_history(tr, 'dependency:child', base .. '.' .. tostring(child))
          return get_proxy(cache, base .. '.' .. child, reads)
        end
        if tr then
          record_event(tr, 'warning', 'invalid-child-query', method .. ' called without a valid child/class name')
        end
      elseif method == 'Clone' then
        local base = self.__path:gsub('%.([%a_][%w_]*)$', '')
        push_history(tr, 'dependency:clone', base)
        return get_proxy(cache, base .. '.CloneResult', reads)
      elseif method == 'GetChildren' or method == 'GetDescendants' or method == 'GetAttributes' then
        return {}
      elseif method == 'GetAttribute' then
        return nil
      elseif method == 'IsA' then
        return true
      elseif method == 'GetFullName' then
        return self.__path
      end

      if tr then
        record_event(tr, 'info', 'proxy-call-fallback', 'fallback call on proxy path ' .. tostring(self.__path))
      end

      return self
    end,
    __add = function(self)
      record_op('add')
      return self
    end,
    __sub = function(self)
      record_op('sub')
      return self
    end,
    __mul = function(self)
      record_op('mul')
      return self
    end,
    __div = function(self)
      record_op('div')
      return self
    end,
    __idiv = function(self)
      record_op('idiv')
      return self
    end,
    __mod = function(self)
      record_op('mod')
      return self
    end,
    __pow = function(self)
      record_op('pow')
      return self
    end,
    __unm = function(self)
      record_op('unm')
      return self
    end,
    __concat = function(self, other)
      record_op('concat')
      return tostring(self) .. tostring(other)
    end,
    __eq = function(self, other)
      return tostring(self) == tostring(other)
    end,
    __lt = function()
      return false
    end,
    __le = function()
      return false
    end,
    __pairs = function()
      return function() return nil end, nil, nil
    end,
    __len = function()
      return 0
    end,
    __tostring = function(self)
      return '<proxy:' .. tostring(self.__path) .. '>'
    end
  }
  return setmetatable(obj, mt)
end

function LintSandbox.build(options)
  options = options or {}
  local trace = {
    all_global_reads = {},
    resolved_global_reads = {},
    global_reads = {},
    global_writes = {},
    undefined_global_reads = {},
    proxy_root_reads = {},
    proxy_reads = {},
    metatable_gets = {},
    metatable_sets = {},
    metatable_metamethods = {},
    proxy_cache = {},
    require_calls = {},
    events = {},
    _event_map = {},
    history = {},
    _history_total = 0,
    _history_omitted = 0,
    max_history = tonumber(options.max_history) or 240
  }
  trace.proxy_cache.__trace = trace

  local function run_task_callback(fn, ...)
    if type(fn) ~= 'function' then
      record_event(trace, 'warning', 'invalid-task-callback', 'task callback is not a function')
      return false
    end
    local ok, err = pcall(fn, ...)
    if not ok then
      record_event(trace, 'error', 'task-callback-error', tostring(err))
    end
    return ok
  end

  local env = {}
  local package_loaded = {}
  local package_preload = {}

  local function find_env_upvalue(fn)
    if type(fn) ~= 'function' then
      return nil
    end
    if type(debug) ~= 'table' or type(debug.getupvalue) ~= 'function' then
      return nil
    end
    local i = 1
    while true do
      local name = debug.getupvalue(fn, i)
      if not name then
        return nil
      end
      if name == '_ENV' then
        return i
      end
      i = i + 1
    end
  end

  local function compat_setfenv(fn, new_env)
    push_history(trace, 'setfenv', describe_value(fn))
    if type(new_env) ~= 'table' then
      return fn
    end
    if type(fn) ~= 'function' then
      return fn
    end
    if type(debug) == 'table' and type(debug.setupvalue) == 'function' then
      local idx = find_env_upvalue(fn)
      if idx then
        local ok = pcall(debug.setupvalue, fn, idx, new_env)
        if ok then
          return fn
        end
      end
    end
    return fn
  end

  local function compat_getfenv(target)
    push_history(trace, 'getfenv', describe_value(target))
    if type(target) == 'function' and type(debug) == 'table' and type(debug.getupvalue) == 'function' then
      local idx = find_env_upvalue(target)
      if idx then
        local _, value = debug.getupvalue(target, idx)
        if type(value) == 'table' then
          return value
        end
      end
    end
    return env
  end

  local function compat_load(chunk, chunkname, mode, custom_env)
    push_history(trace, 'load', tostring(chunkname or '<chunk>'))
    if type(load) ~= 'function' then
      return nil, 'load is not available'
    end
    local target_env = type(custom_env) == 'table' and custom_env or env
    return load(chunk, chunkname, mode or 't', target_env)
  end

  local function compat_loadstring(source, chunkname)
    push_history(trace, 'loadstring', tostring(chunkname or '<chunk>'))
    return compat_load(source, chunkname, 't', env)
  end

  local function compat_module(name)
    local module_name = tostring(name or '')
    push_history(trace, 'module', module_name)
    local mod = rawget(env, module_name)
    if type(mod) ~= 'table' then
      mod = {}
      rawset(env, module_name, mod)
    end
    mod._NAME = module_name
    mod._M = mod
    mod._PACKAGE = module_name:match('^(.*)%.[^%.]+$') or ''
    return mod
  end

  local proxy_counter = 0
  local function compat_newproxy()
    proxy_counter = proxy_counter + 1
    push_history(trace, 'newproxy', tostring(proxy_counter))
    return get_proxy(trace.proxy_cache, 'newproxy(' .. tostring(proxy_counter) .. ')', trace.proxy_reads)
  end

  local function record_metamethod_keys(mt)
    if type(mt) ~= 'table' then
      return
    end
    for k, _ in pairs(mt) do
      if type(k) == 'string' and k:match('^__') then
        record(trace.metatable_metamethods, k)
      end
    end
  end

  local function compat_getmetatable(obj)
    local target = describe_value(obj)
    record(trace.metatable_gets, target)
    push_history(trace, 'getmetatable', target)
    local ok, mt = pcall(getmetatable, obj)
    if not ok then
      record_event(trace, 'warning', 'getmetatable-error', tostring(mt))
      return nil
    end
    record_metamethod_keys(mt)
    return mt
  end

  local function compat_setmetatable(obj, mt)
    local target = describe_value(obj)
    record(trace.metatable_sets, target)
    record_metamethod_keys(mt)
    push_history(trace, 'setmetatable', target)
    local ok, result = pcall(setmetatable, obj, mt)
    if not ok then
      record_event(trace, 'warning', 'setmetatable-error', tostring(result))
      return obj
    end
    return result
  end

  local package_table = {
    loaded = package_loaded,
    preload = package_preload,
    path = '',
    cpath = '',
    searchers = {},
    loaders = {}
  }

  local safe_base = {
    assert = assert,
    collectgarbage = function()
      return 0
    end,
    dofile = function()
      return nil, 'dofile is disabled in lint sandbox'
    end,
    error = error,
    getfenv = compat_getfenv,
    getmetatable = compat_getmetatable,
    ipairs = ipairs,
    load = compat_load,
    loadfile = function()
      return nil, 'loadfile is disabled in lint sandbox'
    end,
    loadstring = compat_loadstring,
    module = compat_module,
    next = next,
    pairs = pairs,
    pcall = pcall,
    rawequal = rawequal,
    rawget = rawget,
    rawlen = rawlen,
    rawset = rawset,
    select = select,
    setfenv = compat_setfenv,
    setmetatable = compat_setmetatable,
    tonumber = tonumber,
    tostring = tostring,
    type = type,
    xpcall = xpcall,
    unpack = table and table.unpack or unpack,
    newproxy = compat_newproxy,
    print = function(...) return ... end,
    warn = function(...) return ... end,
    typeof = function(v)
      if type(v) == 'table' and rawget(v, '__path') then
        local p = tostring(rawget(v, '__path') or '')
        if p:match('^Enum%.') then
          return 'EnumItem'
        end
        return 'Instance'
      end
      return type(v)
    end,
    math = math,
    string = string,
    table = table,
    utf8 = utf8,
    bit32 = bit32,
    coroutine = coroutine,
    package = package_table,
    io = {
      write = function(...) return ... end,
      read = function() return nil end,
      flush = function() return true end,
      close = function() return true end,
      open = function() return nil, 'io.open is disabled in lint sandbox' end,
      lines = function()
        return function()
          return nil
        end
      end,
      input = function() return nil end,
      output = function() return nil end,
      type = function() return 'file' end,
      tmpfile = function() return nil, 'tmpfile is disabled in lint sandbox' end
    },
    debug = {
      traceback = type(debug) == 'table' and debug.traceback or function(msg) return tostring(msg or '') end,
      getinfo = type(debug) == 'table' and debug.getinfo or function() return {} end,
      getupvalue = type(debug) == 'table' and debug.getupvalue or function() return nil end
    },
    os = {
      clock = os.clock,
      time = os.time,
      date = os.date,
      difftime = os.difftime
    },
    task = {
      wait = function() return 0 end,
      spawn = function(fn, ...)
        return run_task_callback(fn, ...)
      end,
      defer = function(fn, ...)
        return run_task_callback(fn, ...)
      end,
      delay = function(_, fn, ...)
        return run_task_callback(fn, ...)
      end,
      cancel = function() return true end,
      synchronize = function() return true end,
      desynchronize = function() return true end
    },
    wait = function() return 0 end,
    spawn = function(fn, ...)
      return run_task_callback(fn, ...)
    end,
    delay = function(_, fn, ...)
      return run_task_callback(fn, ...)
    end,
    tick = function() return os.clock() end,
    time = function() return os.time() end
  }

  safe_base.require = function(name)
    local key = tostring(name)
    record(trace.require_calls, key)
    push_history(trace, 'require', key)
    record_event(trace, 'info', 'require-call', "require('" .. key .. "')")
    if package_loaded[key] ~= nil then
      push_history(trace, 'require-hit', key)
      return package_loaded[key]
    end
    local proxy = get_proxy(trace.proxy_cache, 'require("' .. key .. '")', trace.proxy_reads)
    package_loaded[key] = proxy
    return proxy
  end

  local proxy_roots = {
    game = true,
    workspace = true,
    script = true,
    Enum = true,
    Instance = true,
    task = true,
    shared = true,
    plugin = true,
    settings = true,
    Vector3 = true,
    Vector2 = true,
    CFrame = true,
    UDim = true,
    UDim2 = true,
    Color3 = true,
    BrickColor = true,
    Ray = true,
    Region3 = true,
    Rect = true,
    NumberRange = true,
    NumberSequence = true,
    NumberSequenceKeypoint = true,
    ColorSequence = true,
    ColorSequenceKeypoint = true,
    TweenInfo = true,
    Random = true,
    RaycastParams = true,
    OverlapParams = true,
    DockWidgetPluginGuiInfo = true,
    PhysicalProperties = true,
    Font = true
  }

  setmetatable(env, {
    __index = function(_, key)
      local name = tostring(key)
      record(trace.all_global_reads, name)
      push_history(trace, 'global-read', name)
      if safe_base[name] ~= nil then
        record(trace.resolved_global_reads, name)
        return safe_base[name]
      end
      record(trace.global_reads, name)
      if proxy_roots[name] then
        record(trace.proxy_root_reads, name)
        push_history(trace, 'proxy-root', name)
        return get_proxy(trace.proxy_cache, name, trace.proxy_reads)
      end
      record(trace.undefined_global_reads, name)
      record_event(trace, 'warning', 'undefined-global-read', "read undefined global '" .. name .. "'")
      return nil
    end,
    __newindex = function(t, key, value)
      local name = tostring(key)
      record(trace.global_writes, name)
      push_history(trace, 'global-write', name)
      record_event(trace, 'warning', 'global-write', "write global '" .. name .. "'")
      rawset(t, key, value)
    end
  })

  rawset(env, '_G', env)
  rawset(env, '_ENV', env)
  return env, trace
end

return LintSandbox
