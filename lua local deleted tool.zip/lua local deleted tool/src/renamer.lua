local Lexer = require('src.lexer')
local Parser = require('src.parser')

local Renamer = {}

local reserved = {
  ['and'] = true, ['break'] = true, ['do'] = true, ['else'] = true, ['elseif'] = true,
  ['end'] = true, ['false'] = true, ['for'] = true, ['function'] = true, ['if'] = true,
  ['in'] = true, ['local'] = true, ['nil'] = true, ['not'] = true, ['or'] = true,
  ['repeat'] = true, ['return'] = true, ['then'] = true, ['true'] = true, ['until'] = true,
  ['while'] = true
}

local first_chars = {}
for c = string.byte('a'), string.byte('z') do table.insert(first_chars, string.char(c)) end
for c = string.byte('A'), string.byte('Z') do table.insert(first_chars, string.char(c)) end
table.insert(first_chars, '_')

local rest_chars = {}
for _, ch in ipairs(first_chars) do table.insert(rest_chars, ch) end
for c = string.byte('0'), string.byte('9') do table.insert(rest_chars, string.char(c)) end

local function gcd(a, b)
  while b ~= 0 do
    local t = a % b
    a = b
    b = t
  end
  return a
end

local NameGenerator = {}
NameGenerator.__index = NameGenerator

function NameGenerator.new(used_names)
  local self = {
    used = used_names or {},
    len = 1,
    length_total = 0,
    length_start = 0,
    length_step = 1,
    emitted = 0
  }
  setmetatable(self, NameGenerator)
  self:reset_length()
  return self
end

function NameGenerator:length_count(len)
  if len == 1 then
    return #first_chars
  end
  return #first_chars * ((#rest_chars) ^ (len - 1))
end

function NameGenerator:pick_coprime_step(total)
  if total <= 1 then return 1 end
  local step = math.random(1, total - 1)
  while gcd(step, total) ~= 1 do
    step = step + 1
    if step >= total then
      step = 1
    end
  end
  return step
end

function NameGenerator:reset_length()
  self.length_total = self:length_count(self.len)
  if self.length_total <= 1 then
    self.length_start = 0
    self.length_step = 1
  else
    self.length_start = math.random(0, self.length_total - 1)
    self.length_step = self:pick_coprime_step(self.length_total)
  end
  self.emitted = 0
end

function NameGenerator:index_to_name(idx, len)
  if len == 1 then
    return first_chars[idx + 1]
  end

  local base = #rest_chars
  local rem = idx
  local place = base ^ (len - 1)
  local first_idx = math.floor(rem / place)
  rem = rem % place

  local out = { first_chars[first_idx + 1] }
  for p = len - 1, 1, -1 do
    local div = base ^ (p - 1)
    local d = math.floor(rem / div)
    rem = rem % div
    out[#out + 1] = rest_chars[d + 1]
  end

  return table.concat(out)
end

function NameGenerator:next_name()
  while true do
    if self.emitted >= self.length_total then
      self.len = self.len + 1
      self:reset_length()
    end

    local idx = (self.length_start + self.emitted * self.length_step) % self.length_total
    self.emitted = self.emitted + 1
    local cand = self:index_to_name(idx, self.len)

    if not reserved[cand] and not self.used[cand] then
      self.used[cand] = true
      return cand
    end
  end
end

local function new_scope(parent)
  return { parent = parent, locals = {} }
end

local function scope_lookup(scope, name)
  local cur = scope
  while cur do
    local mapped = cur.locals[name]
    if mapped ~= nil then
      return mapped
    end
    cur = cur.parent
  end
  return nil
end

local function scope_declare(scope, old_name, new_name)
  scope.locals[old_name] = new_name
end

local function split_identifier_path(path)
  local parts = {}
  if type(path) ~= 'string' then
    return parts
  end
  for name in path:gmatch('([%a_][%w_]*)') do
    parts[#parts + 1] = name
  end
  return parts
end

local active_protected_names = nil

local function should_keep_name(name)
  return active_protected_names and active_protected_names[name] == true
end

local function collect_used_names(node, used)
  if not node then return end
  local t = node.type

  if t == 'Identifier' then
    used[node.name] = true
    return
  end

  if t == 'LocalDecl' then
    for _, name in ipairs(node.names or {}) do used[name] = true end
    for _, value in ipairs(node.values or {}) do collect_used_names(value, used) end
    return
  end

  if t == 'LocalFunc' then
    used[node.name] = true
    collect_used_names(node.body, used)
    return
  end

  if t == 'FunctionDecl' then
    for _, name in ipairs(split_identifier_path(node.name)) do used[name] = true end
    for _, p in ipairs(node.params or {}) do used[p] = true end
    collect_used_names(node.body, used)
    return
  end

  if t == 'Function' then
    for _, p in ipairs(node.params or {}) do used[p] = true end
    collect_used_names(node.body, used)
    return
  end

  if t == 'Block' then
    for _, stmt in ipairs(node.statements or {}) do collect_used_names(stmt, used) end
    return
  end

  if t == 'Chunk' then
    collect_used_names(node.body, used)
    return
  end

  if t == 'For' then
    used[node.var] = true
    collect_used_names(node.start, used)
    collect_used_names(node.finish, used)
    collect_used_names(node.step, used)
    collect_used_names(node.body, used)
    return
  end

  if t == 'ForIn' then
    for _, v in ipairs(node.vars or {}) do used[v] = true end
    for _, it in ipairs(node.iterators or {}) do collect_used_names(it, used) end
    collect_used_names(node.body, used)
    return
  end

  if t == 'PropertyExpr' then
    used[node.property] = true
    collect_used_names(node.object, used)
    return
  end

  if t == 'MethodCall' then
    used[node.method] = true
    collect_used_names(node.object, used)
    for _, arg in ipairs(node.args or {}) do collect_used_names(arg, used) end
    return
  end

  if t == 'Table' then
    for _, field in ipairs(node.fields or {}) do
      collect_used_names(field.key, used)
      collect_used_names(field.value, used)
    end
    return
  end

  if t == 'String' then
    if type(node.value) == 'string' and node.value:match('^[%a_][%w_]*$') then
      used[node.value] = true
    end
    return
  end

  for _, v in pairs(node) do
    if type(v) == 'table' then
      collect_used_names(v, used)
    end
  end
end

local function add_replacement(replacements, seen, token, old_name, new_name)
  if not token or not old_name or not new_name or old_name == new_name then
    return
  end
  if not token.line or not token.col then
    return
  end
  local key = tostring(token.line) .. ':' .. tostring(token.col) .. ':' .. old_name
  if seen[key] then
    return
  end
  seen[key] = true
  table.insert(replacements, {
    line = token.line,
    col = token.col,
    old = old_name,
    new = new_name
  })
end

local function rename_function_decl_name(node, scope, replacements, seen)
  local token = node.name_head_token
  if not token then
    return
  end
  local mapped = scope_lookup(scope, token.value)
  if mapped then
    add_replacement(replacements, seen, token, token.value, mapped)
  end
end

local rename_function_node

local function rename_expr(node, scope, gen, replacements, seen)
  if not node then return end
  local t = node.type

  if t == 'Identifier' then
    local mapped = scope_lookup(scope, node.name)
    if mapped then
      add_replacement(replacements, seen, node.token, node.name, mapped)
    end
    return
  end

  if t == 'BinaryOp' then
    rename_expr(node.left, scope, gen, replacements, seen)
    rename_expr(node.right, scope, gen, replacements, seen)
    return
  end

  if t == 'UnaryOp' then
    rename_expr(node.operand, scope, gen, replacements, seen)
    return
  end

  if t == 'FunctionCall' then
    rename_expr(node.callee, scope, gen, replacements, seen)
    for _, arg in ipairs(node.args or {}) do
      rename_expr(arg, scope, gen, replacements, seen)
    end
    return
  end

  if t == 'MethodCall' then
    rename_expr(node.object, scope, gen, replacements, seen)
    for _, arg in ipairs(node.args or {}) do
      rename_expr(arg, scope, gen, replacements, seen)
    end
    return
  end

  if t == 'IndexExpr' then
    rename_expr(node.object, scope, gen, replacements, seen)
    rename_expr(node.index, scope, gen, replacements, seen)
    return
  end

  if t == 'PropertyExpr' then
    rename_expr(node.object, scope, gen, replacements, seen)
    return
  end

  if t == 'Table' then
    for _, field in ipairs(node.fields or {}) do
      if field.key then
        rename_expr(field.key, scope, gen, replacements, seen)
      end
      rename_expr(field.value, scope, gen, replacements, seen)
    end
    return
  end

  if t == 'Function' then
    rename_function_node(node, scope, gen, replacements, seen)
    return
  end
end

local rename_stmt

local function rename_block(block_node, scope, gen, replacements, seen)
  for _, stmt in ipairs(block_node.statements or {}) do
    rename_stmt(stmt, scope, gen, replacements, seen)
  end
end

rename_function_node = function(fn_node, parent_scope, gen, replacements, seen)
  local fn_scope = new_scope(parent_scope)
  local params = fn_node.params or {}
  local param_tokens = fn_node.param_tokens or {}
  for i, p in ipairs(params) do
    local new_name = should_keep_name(p) and p or gen:next_name()
    scope_declare(fn_scope, p, new_name)
    add_replacement(replacements, seen, param_tokens[i], p, new_name)
  end
  local body_scope = new_scope(fn_scope)
  rename_block(fn_node.body, body_scope, gen, replacements, seen)
end

rename_stmt = function(node, scope, gen, replacements, seen)
  if not node then return end
  local t = node.type

  if t == 'LocalDecl' then
    for _, value in ipairs(node.values or {}) do
      rename_expr(value, scope, gen, replacements, seen)
    end
    local name_tokens = node.name_tokens or {}
    for i, old_name in ipairs(node.names or {}) do
      local new_name = should_keep_name(old_name) and old_name or gen:next_name()
      scope_declare(scope, old_name, new_name)
      add_replacement(replacements, seen, name_tokens[i], old_name, new_name)
    end
    return
  end

  if t == 'LocalFunc' then
    local new_name = should_keep_name(node.name) and node.name or gen:next_name()
    scope_declare(scope, node.name, new_name)
    add_replacement(replacements, seen, node.name_token, node.name, new_name)
    rename_function_node(node.body, scope, gen, replacements, seen)
    return
  end

  if t == 'FunctionDecl' then
    rename_function_decl_name(node, scope, replacements, seen)
    rename_function_node({
      params = node.params,
      param_tokens = node.param_tokens,
      body = node.body
    }, scope, gen, replacements, seen)
    return
  end

  if t == 'If' then
    rename_expr(node.condition, scope, gen, replacements, seen)
    local then_scope = new_scope(scope)
    rename_block(node.then_body, then_scope, gen, replacements, seen)

    for _, part in ipairs(node.elseif_parts or {}) do
      rename_expr(part.condition, scope, gen, replacements, seen)
      local elseif_scope = new_scope(scope)
      rename_block(part.body, elseif_scope, gen, replacements, seen)
    end

    if node.else_body then
      local else_scope = new_scope(scope)
      rename_block(node.else_body, else_scope, gen, replacements, seen)
    end
    return
  end

  if t == 'While' then
    rename_expr(node.condition, scope, gen, replacements, seen)
    local body_scope = new_scope(scope)
    rename_block(node.body, body_scope, gen, replacements, seen)
    return
  end

  if t == 'Repeat' then
    local rep_scope = new_scope(scope)
    rename_block(node.body, rep_scope, gen, replacements, seen)
    rename_expr(node.condition, rep_scope, gen, replacements, seen)
    return
  end

  if t == 'For' then
    rename_expr(node.start, scope, gen, replacements, seen)
    rename_expr(node.finish, scope, gen, replacements, seen)
    if node.step then
      rename_expr(node.step, scope, gen, replacements, seen)
    end
    local for_scope = new_scope(scope)
    local new_name = should_keep_name(node.var) and node.var or gen:next_name()
    scope_declare(for_scope, node.var, new_name)
    add_replacement(replacements, seen, node.var_token, node.var, new_name)
    rename_block(node.body, for_scope, gen, replacements, seen)
    return
  end

  if t == 'ForIn' then
    for _, iter in ipairs(node.iterators or {}) do
      rename_expr(iter, scope, gen, replacements, seen)
    end
    local for_scope = new_scope(scope)
    local vars = node.vars or {}
    local var_tokens = node.var_tokens or {}
    for i, old_name in ipairs(vars) do
      local new_name = should_keep_name(old_name) and old_name or gen:next_name()
      scope_declare(for_scope, old_name, new_name)
      add_replacement(replacements, seen, var_tokens[i], old_name, new_name)
    end
    rename_block(node.body, for_scope, gen, replacements, seen)
    return
  end

  if t == 'Do' then
    local do_scope = new_scope(scope)
    rename_block(node.body, do_scope, gen, replacements, seen)
    return
  end

  if t == 'Assignment' then
    for _, value in ipairs(node.values or {}) do
      rename_expr(value, scope, gen, replacements, seen)
    end
    for _, target in ipairs(node.targets or {}) do
      rename_expr(target, scope, gen, replacements, seen)
    end
    return
  end

  if t == 'Return' then
    for _, value in ipairs(node.values or {}) do
      rename_expr(value, scope, gen, replacements, seen)
    end
    return
  end

  rename_expr(node, scope, gen, replacements, seen)
end

local function build_line_starts(source)
  local starts = { 1 }
  for i = 1, #source do
    if source:byte(i) == 10 then
      starts[#starts + 1] = i + 1
    end
  end
  return starts
end

local function line_col_to_byte(source, line_starts, line, col)
  local line_start = line_starts[line]
  if not line_start then
    return nil
  end
  if col <= 1 then
    return line_start
  end
  if type(utf8) == 'table' and utf8.offset then
    local p = utf8.offset(source, col, line_start)
    if p then
      return p
    end
  end
  return line_start + col - 1
end

local function apply_replacements(source, replacements)
  local line_starts = build_line_starts(source)
  local spans = {}

  for _, rep in ipairs(replacements) do
    local start_pos = line_col_to_byte(source, line_starts, rep.line, rep.col)
    if start_pos then
      local end_pos = start_pos + #rep.old - 1
      if source:sub(start_pos, end_pos) == rep.old then
        spans[#spans + 1] = {
          start_pos = start_pos,
          end_pos = end_pos,
          new = rep.new
        }
      end
    end
  end

  table.sort(spans, function(a, b)
    if a.start_pos == b.start_pos then
      return a.end_pos > b.end_pos
    end
    return a.start_pos > b.start_pos
  end)

  local out = source
  local last_applied_start = math.huge
  for _, span in ipairs(spans) do
    if span.end_pos < last_applied_start then
      out = out:sub(1, span.start_pos - 1) .. span.new .. out:sub(span.end_pos + 1)
      last_applied_start = span.start_pos
    end
  end

  return out
end

function Renamer.rename(source, options)
  math.randomseed(os.time())

  local lexer = Lexer.new(source)
  local tokens = lexer:tokenize()

  local parser = Parser.new(tokens)
  local ast = parser:parse()

  local used = {}
  collect_used_names(ast, used)

  local gen = NameGenerator.new(used)
  local global_scope = new_scope(nil)
  local replacements = {}
  local seen = {}
  local prev_protected = active_protected_names
  active_protected_names = {}
  if options and type(options.protected_names) == 'table' then
    for name, keep in pairs(options.protected_names) do
      if keep and type(name) == 'string' then
        active_protected_names[name] = true
      end
    end
  end
  rename_block(ast.body, global_scope, gen, replacements, seen)
  active_protected_names = prev_protected

  local output = apply_replacements(source, replacements)
  local analyzer = { all_locals = {} }
  return output, analyzer
end

return Renamer
