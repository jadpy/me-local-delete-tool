local AST = require('src.ast')

local Parser = {}

local function token_info(tok)
  if not tok then
    return 'EOF', 0, 0
  end
  return tostring(tok.type or 'EOF'), tonumber(tok.line) or 0, tonumber(tok.col) or 0
end

local function is_assignable_target(node)
  if not node or type(node) ~= 'table' then
    return false
  end
  return node.type == 'Identifier' or node.type == 'IndexExpr' or node.type == 'PropertyExpr'
end

function Parser.new(tokens)
  local self = {
    tokens = tokens,
    pos = 1,
    current_token = tokens[1]
  }
  return setmetatable(self, { __index = Parser })
end

function Parser:advance()
  self.pos = self.pos + 1
  self.current_token = self.tokens[self.pos]
end

function Parser:peek(offset)
  offset = offset or 1
  return self.tokens[self.pos + offset]
end

function Parser:expect(token_type)
  local current = self.current_token
  if not current or current.type ~= token_type then
    local got, line, col = token_info(current)
    error(string.format("Expected %s but got %s at line %d col %d", tostring(token_type), got, line, col))
  end
  local token = current
  self:advance()
  return token
end

function Parser:match(...)
  if not self.current_token then
    return false
  end
  local types = {...}
  for _, t in ipairs(types) do
    if self.current_token.type == t then
      return true
    end
  end
  return false
end

function Parser:parse()
  return self:parse_chunk()
end

function Parser:parse_chunk()
  local statements = {}
  
  while self.current_token and self.current_token.type ~= 'EOF' do
    local stmt = self:parse_statement()
    if stmt then
      table.insert(statements, stmt)
    end
    if self:match('SEMICOLON') then
      self:advance()
    end
  end
  
  return AST.Chunk(AST.Block(statements))
end

function Parser:parse_statement()
  local stmt_line = (self.current_token and self.current_token.line) or self.current_line or 1

  if self:match('SEMICOLON') then
    self:advance()
    return nil
  end

  local stmt
  if self:match('LOCAL') then
    stmt = self:parse_local()
  elseif self:match('FUNCTION') then
    stmt = self:parse_function_decl()
  elseif self:match('IF') then
    stmt = self:parse_if()
  elseif self:match('WHILE') then
    stmt = self:parse_while()
  elseif self:match('REPEAT') then
    stmt = self:parse_repeat()
  elseif self:match('FOR') then
    stmt = self:parse_for()
  elseif self:match('DO') then
    stmt = self:parse_do()
  elseif self:match('BREAK') then
    self:advance()
    stmt = AST.Break()
  elseif self:match('RETURN') then
    stmt = self:parse_return()
  else
    stmt = self:parse_expr_statement()
  end

  if stmt and stmt_line then
    stmt.source_line = stmt_line
  end
  return stmt
end

function Parser:parse_local()
  local local_tok = self:expect('LOCAL')
  
  if self:match('FUNCTION') then
    self:advance()
    local name_tok = self:expect('IDENT')
    local name = name_tok.value
    local func = self:parse_function_body()
    local node = AST.LocalFunc(name, func)
    node.name_token = name_tok
    node.local_token = local_tok
    return node
  else
    local names = {}
    local name_tokens = {}
    local first_tok = self:expect('IDENT')
    table.insert(names, first_tok.value)
    table.insert(name_tokens, first_tok)
    
    while self:match('COMMA') do
      self:advance()
      local tok = self:expect('IDENT')
      table.insert(names, tok.value)
      table.insert(name_tokens, tok)
    end
    
    local values = {}
    if self:match('ASSIGN') then
      self:advance()
      table.insert(values, self:parse_expression())
      
      while self:match('COMMA') do
        self:advance()
        table.insert(values, self:parse_expression())
      end
    end
    
    local node = AST.LocalDecl(names, values)
    node.name_tokens = name_tokens
    node.local_token = local_tok
    return node
  end
end

function Parser:parse_function_decl()
  self:expect('FUNCTION')
  
  local head_tok = self:expect('IDENT')
  local name = head_tok.value
  
  while self:match('DOT') do
    self:advance()
    name = name .. '.' .. self:expect('IDENT').value
  end
  
  if self:match('COLON') then
    self:advance()
    name = name .. ':' .. self:expect('IDENT').value
  end
  
  local func = self:parse_function_body()
  local node = AST.FunctionDecl(name, func.params, func.body, false)
  node.name_head_token = head_tok
  node.param_tokens = func.param_tokens
  return node
end

function Parser:parse_function_body()
  self:expect('LPAREN')
  
  local params = {}
  local param_tokens = {}
  local has_varargs = false
  
  if not self:match('RPAREN') then
    if self:match('ELLIPSIS') then
      self:advance()
      has_varargs = true
    else
      local tok = self:expect('IDENT')
      table.insert(params, tok.value)
      table.insert(param_tokens, tok)
      
      while self:match('COMMA') do
        self:advance()
        if self:match('ELLIPSIS') then
          self:advance()
          has_varargs = true
          break
        else
          local p_tok = self:expect('IDENT')
          table.insert(params, p_tok.value)
          table.insert(param_tokens, p_tok)
        end
      end
    end
  end
  
  self:expect('RPAREN')
  
  local body = self:parse_block()
  self:expect('END')
  
  local node = AST.Function(params, body, has_varargs)
  node.param_tokens = param_tokens
  return node
end

function Parser:parse_block()
  local statements = {}
  
  while not self:match('END', 'ELSEIF', 'ELSE', 'UNTIL', 'EOF') do
    local stmt = self:parse_statement()
    if stmt then
      table.insert(statements, stmt)
    end
    if self:match('SEMICOLON') then
      self:advance()
    end
  end
  
  return AST.Block(statements)
end

function Parser:parse_if()
  self:expect('IF')
  
  local condition = self:parse_expression()
  self:expect('THEN')
  local then_body = self:parse_block()
  
  local elseif_parts = {}
  while self:match('ELSEIF') do
    self:advance()
    local elseif_cond = self:parse_expression()
    self:expect('THEN')
    local elseif_body = self:parse_block()
    table.insert(elseif_parts, { condition = elseif_cond, body = elseif_body })
  end
  
  local else_body = nil
  if self:match('ELSE') then
    self:advance()
    else_body = self:parse_block()
  end
  
  self:expect('END')
  
  return AST.If(condition, then_body, elseif_parts, else_body)
end

function Parser:parse_while()
  self:expect('WHILE')
  local condition = self:parse_expression()
  self:expect('DO')
  local body = self:parse_block()
  self:expect('END')
  return AST.While(condition, body)
end

function Parser:parse_repeat()
  self:expect('REPEAT')
  local body = self:parse_block()
  self:expect('UNTIL')
  local condition = self:parse_expression()
  return AST.Repeat(body, condition)
end

function Parser:parse_for()
  self:expect('FOR')
  local first_tok = self:expect('IDENT')

  if self:match('ASSIGN') then
    self:advance()
    local start = self:parse_expression()
    self:expect('COMMA')
    local finish = self:parse_expression()

    local step = nil
    if self:match('COMMA') then
      self:advance()
      step = self:parse_expression()
    end

    self:expect('DO')
    local body = self:parse_block()
    self:expect('END')

    local node = AST.For(first_tok.value, start, finish, step, body)
    node.var_token = first_tok
    return node
  else
    local vars = {}
    local var_tokens = {}
    table.insert(vars, first_tok.value)
    table.insert(var_tokens, first_tok)
    
    while self:match('COMMA') do
      self:advance()
      local tok = self:expect('IDENT')
      table.insert(vars, tok.value)
      table.insert(var_tokens, tok)
    end
    
    self:expect('IN')
    
    local iterators = {}
    table.insert(iterators, self:parse_expression())
    while self:match('COMMA') do
      self:advance()
      table.insert(iterators, self:parse_expression())
    end
    
    self:expect('DO')
    local body = self:parse_block()
    self:expect('END')
    
    local node = AST.ForIn(vars, iterators, body)
    node.var_tokens = var_tokens
    return node
  end
end

function Parser:parse_do()
  self:expect('DO')
  local body = self:parse_block()
  self:expect('END')
  return AST.Do(body)
end

function Parser:parse_return()
  self:expect('RETURN')
  
  local values = {}
  if not self:match('EOF', 'END', 'ELSEIF', 'ELSE', 'UNTIL', 'SEMICOLON') then
    table.insert(values, self:parse_expression())
    
    while self:match('COMMA') do
      self:advance()
      table.insert(values, self:parse_expression())
    end
  end
  
  if self:match('SEMICOLON') then
    self:advance()
  end
  
  return AST.Return(values)
end

function Parser:parse_expr_list()
  local values = {}
  table.insert(values, self:parse_expression())
  while self:match('COMMA') do
    self:advance()
    table.insert(values, self:parse_expression())
  end
  return values
end

function Parser:parse_expr_statement()
  local expr = self:parse_expression()
  
  if self:match('ASSIGN', 'COMMA') then
    local targets = { expr }

    if self:match('COMMA') then
      while self:match('COMMA') do
        self:advance()
        table.insert(targets, self:parse_expression())
      end
      self:expect('ASSIGN')
    else
      self:advance()
    end

    for _, target in ipairs(targets) do
      if not is_assignable_target(target) then
        local got_type = target and target.type or 'nil'
        local line = (self.current_token and self.current_token.line) or 0
        error(string.format("Invalid assignment target: %s at line %d", tostring(got_type), line))
      end
    end

    local values = {}
    table.insert(values, self:parse_expression())
    while self:match('COMMA') do
      self:advance()
      table.insert(values, self:parse_expression())
    end
    
    return AST.Assignment(targets, values)
  end
  
  if self:match('SEMICOLON') then
    self:advance()
  end
  
  return expr
end

function Parser:parse_expression()
  return self:parse_or()
end

function Parser:parse_or()
  local left = self:parse_and()
  
  while self:match('OR') do
    local op = self.current_token.value
    self:advance()
    local right = self:parse_and()
    left = AST.BinaryOp(op, left, right)
  end
  
  return left
end

function Parser:parse_and()
  local left = self:parse_not()
  
  while self:match('AND') do
    local op = self.current_token.value
    self:advance()
    local right = self:parse_not()
    left = AST.BinaryOp(op, left, right)
  end
  
  return left
end

function Parser:parse_not()
  if self:match('NOT') then
    local op = self.current_token.value
    self:advance()
    local operand = self:parse_not()
    return AST.UnaryOp(op, operand)
  end
  
  return self:parse_comparison()
end

function Parser:parse_comparison()
  local left = self:parse_concat()
  
  while self:match('LT', 'LE', 'GT', 'GE', 'EQ', 'NE') do
    local op = self.current_token.value
    self:advance()
    local right = self:parse_concat()
    left = AST.BinaryOp(op, left, right)
  end
  
  return left
end

function Parser:parse_concat()
  local left = self:parse_additive()
  
  while self:match('CONCAT') do
    local op = self.current_token.value
    self:advance()
    local right = self:parse_additive()
    left = AST.BinaryOp(op, left, right)
  end
  
  return left
end

function Parser:parse_additive()
  local left = self:parse_multiplicative()
  
  while self:match('PLUS', 'MINUS') do
    local op = self.current_token.value
    self:advance()
    local right = self:parse_multiplicative()
    left = AST.BinaryOp(op, left, right)
  end
  
  return left
end

function Parser:parse_multiplicative()
  local left = self:parse_unary()
  
  while self:match('MUL', 'DIV', 'IDIV', 'MOD') do
    local op = self.current_token.value
    self:advance()
    local right = self:parse_unary()
    left = AST.BinaryOp(op, left, right)
  end
  
  return left
end

function Parser:parse_unary()
  if self:match('MINUS', 'NOT', 'LEN') then
    local op = self.current_token.value
    self:advance()
    local operand = self:parse_unary()
    return AST.UnaryOp(op, operand)
  end
  
  return self:parse_power()
end

function Parser:parse_power()
  local left = self:parse_postfix()
  
  if self:match('POW') then
    local op = self.current_token.value
    self:advance()
    local right = self:parse_power()
    left = AST.BinaryOp(op, left, right)
  end
  
  return left
end

function Parser:parse_call_args()
  if self:match('LPAREN') then
    self:advance()
    local args = {}
    if not self:match('RPAREN') then
      args = self:parse_expr_list()
    end
    self:expect('RPAREN')
    return args
  end
  if self:match('LBRACE') then
    return { self:parse_table() }
  end
  if self:match('STRING') then
    local value = self.current_token.value
    self:advance()
    return { AST.String(value) }
  end
  local got, line, col = token_info(self.current_token)
  error(string.format("Expected function arguments but got %s at line %d col %d", got, line, col))
end

function Parser:parse_postfix()
  local expr = self:parse_primary()
  
  while true do
    if self:match('LPAREN', 'LBRACE', 'STRING') then
      expr = AST.FunctionCall(expr, self:parse_call_args())
    elseif self:match('LBRACKET') then
      self:advance()
      local index = self:parse_expression()
      self:expect('RBRACKET')
      expr = AST.IndexExpr(expr, index)
    elseif self:match('DOT') then
      self:advance()
      local property = self:expect('IDENT').value
      expr = AST.PropertyExpr(expr, property)
    elseif self:match('COLON') then
      self:advance()
      local method = self:expect('IDENT').value
      expr = AST.MethodCall(expr, method, self:parse_call_args())
    else
      break
    end
  end
  
  return expr
end

function Parser:parse_primary()
  if self:match('NIL') then
    self:advance()
    return AST.Nil()
  elseif self:match('TRUE') then
    self:advance()
    return AST.Boolean(true)
  elseif self:match('FALSE') then
    self:advance()
    return AST.Boolean(false)
  elseif self:match('NUMBER') then
    local value = self.current_token.value
    self:advance()
    return AST.Number(value)
  elseif self:match('STRING') then
    local value = self.current_token.value
    self:advance()
    return AST.String(value)
  elseif self:match('ELLIPSIS') then
    self:advance()
    return AST.VarArgs()
  elseif self:match('FUNCTION') then
    self:advance()
    return self:parse_function_body()
  elseif self:match('LBRACE') then
    return self:parse_table()
  elseif self:match('LPAREN') then
    self:advance()
    local expr = self:parse_expression()
    self:expect('RPAREN')
    return expr
  elseif self:match('IDENT') then
    local tok = self.current_token
    local name = tok.value
    self:advance()
    local node = AST.Identifier(name)
    node.token = tok
    return node
  else
    local got, line, col = token_info(self.current_token)
    error(string.format("Unexpected token: %s at line %d col %d", got, line, col))
  end
end

function Parser:parse_table()
  self:expect('LBRACE')
  
  local fields = {}
  if not self:match('RBRACE') then
    table.insert(fields, self:parse_table_field())
    while self:match('COMMA', 'SEMICOLON') do
      self:advance()
      if self:match('RBRACE') then break end
      table.insert(fields, self:parse_table_field())
    end
  end
  
  self:expect('RBRACE')
  
  return AST.Table(fields)
end

function Parser:parse_table_field()
  if self:match('LBRACKET') then
    self:advance()
    local key = self:parse_expression()
    self:expect('RBRACKET')
    self:expect('ASSIGN')
    local value = self:parse_expression()
    return AST.TableField(key, value)
  elseif self:match('IDENT') and self:peek() and self:peek().type == 'ASSIGN' then
    local key = self:expect('IDENT').value
    self:expect('ASSIGN')
    local value = self:parse_expression()
    return AST.TableField(AST.String(key), value)
  else
    local value = self:parse_expression()
    return AST.TableField(nil, value)
  end
end

return Parser
