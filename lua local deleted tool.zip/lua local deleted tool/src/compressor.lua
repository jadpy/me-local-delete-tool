local LexerFull = require('src.lexer_full')
local Lexer = require('src.lexer')
local Parser = require('src.parser')
local CodeGen = require('src.codegen')
local Optimizer = require('src.optimizer')

local Compressor = {}

local function is_wordlike(tok)
  return tok.type == 'keyword' or tok.type == 'ident' or tok.type == 'number' or tok.type == 'string' or tok.type == 'long_string'
end

local merge_pairs = {
  ['--'] = true, ['=='] = true, ['~='] = true, ['<='] = true, ['>='] = true,
  ['<<'] = true, ['>>'] = true, ['//'] = true, ['..'] = true, ['...'] = true,
  ['::'] = true, ['+='] = true, ['-='] = true, ['*='] = true, ['/='] = true,
  ['%='] = true, ['^='] = true, ['&='] = true, ['|='] = true, ['..='] = true,
  ['->'] = true, ['=>'] = true, [':='] = true, ['&&'] = true, ['||'] = true
}

local function needs_space(prev, nxt)
  if not prev or not nxt then return false end
  if is_wordlike(prev) and is_wordlike(nxt) then return true end
  if prev.type == 'number' and nxt.type == 'symbol' and nxt.value:sub(1, 1) == '.' then return true end
  if prev.type == 'symbol' and nxt.type == 'symbol' then
    if merge_pairs[prev.value .. nxt.value] then return true end
    if prev.value:sub(-1) == '.' and nxt.value:sub(1, 1) == '.' then return true end
  end
  if prev.type == 'symbol' and prev.value == '[' and (nxt.value == '[' or nxt.value:sub(1, 1) == '=') then return true end
  if prev.type == 'symbol' and prev.value == ']' and nxt.value == ']' then return true end
  if prev.type == 'symbol' and prev.value == ':' and nxt.value == ':' then return true end
  return false
end

local stmt_start_keywords = {
  ['local'] = true, ['function'] = true, ['if'] = true, ['while'] = true,
  ['repeat'] = true, ['for'] = true, ['do'] = true, ['break'] = true,
  ['return'] = true, ['goto'] = true, ['continue'] = true,
  ['end'] = true, ['elseif'] = true, ['else'] = true, ['until'] = true
}

local function can_end_statement(prev)
  if not prev then return false end
  if prev.type == 'ident' or prev.type == 'number' or prev.type == 'string' or prev.type == 'long_string' then
    return true
  end
  if prev.type == 'keyword' then
    return prev.value == 'end' or prev.value == 'until' or prev.value == 'break' or prev.value == 'return'
      or prev.value == 'true' or prev.value == 'false' or prev.value == 'nil'
  end
  if prev.type == 'symbol' then
    return prev.value == ')' or prev.value == ']' or prev.value == '}'
  end
  return false
end

local function can_start_statement(tok)
  if not tok then return false end
  if tok.type == 'keyword' and stmt_start_keywords[tok.value] then
    return true
  end
  if tok.type == 'symbol' and tok.value == '::' then
    return true
  end
  return false
end

local function can_compile(code)
  if type(load) == 'function' then
    local fn = load(code)
    return fn ~= nil
  end
  if type(loadstring) == 'function' then
    local fn = loadstring(code)
    return fn ~= nil
  end
  return true
end

local function can_parse_with_ast(code)
  local ok = pcall(function()
    local tokens = Lexer.new(code):tokenize()
    local parser = Parser.new(tokens)
    parser:parse()
  end)
  return ok
end

local function minify_source(source)
  local lexer = LexerFull.new(source)
  local tokens = lexer:tokenize()
  local out = {}
  local out_tail = ''
  local function append(piece)
    table.insert(out, piece)
    out_tail = out_tail .. piece
    if #out_tail > 8 then
      out_tail = out_tail:sub(-8)
    end
  end
  local prev = nil
  local brace_depth = 0
  local pending_break = false
  for _, tok in ipairs(tokens) do
    if tok.type == 'newline' then
      pending_break = true
    elseif tok.type == 'comment' then
      pending_break = true
    end

    local emit = tok.type ~= 'comment' and tok.type ~= 'newline'
    if emit and tok.type == 'symbol' and tok.value == ';' and brace_depth == 0 then
      emit = false
    end

    if emit then
      local left = prev
      local force_space_for_minus = prev
        and prev.type == 'symbol' and prev.value == '-'
        and out_tail:sub(-2) == '--'
        and tok.type == 'number'

      if pending_break and brace_depth == 0 and can_end_statement(prev) and can_start_statement(tok) then
        append(';')
        left = { type = 'symbol', value = ';' }
      elseif force_space_for_minus or needs_space(prev, tok) then
        append(' ')
      end
      append(tok.value)
      prev = tok
      pending_break = false
    end

    if tok.type == 'symbol' then
      if tok.value == '{' then
        brace_depth = brace_depth + 1
      elseif tok.value == '}' and brace_depth > 0 then
        brace_depth = brace_depth - 1
      end
    end
  end
  return table.concat(out)
end

local function optimize_source_with_ast(source)
  local ok, out = pcall(function()
    local tokens = Lexer.new(source):tokenize()
    local parser = Parser.new(tokens)
    local ast = parser:parse()
    ast = Optimizer.optimize(ast)

    local codegen = CodeGen.new(nil)
    codegen.source_lines = nil
    codegen.preserve_indent_for_line = function(_, line)
      return line
    end
    return codegen:generate(ast.body)
  end)
  if ok and type(out) == 'string' and out ~= '' then
    return out
  end
  return nil
end

local function validate_result(candidate, source_parse_ok, source_compile_ok)
  local tok_ok = pcall(function()
    local lx = LexerFull.new(candidate)
    lx:tokenize()
  end)
  if not tok_ok then
    return false
  end

  if source_compile_ok then
    if not can_compile(candidate) then
      return false
    end
  elseif source_parse_ok then
    if not can_parse_with_ast(candidate) then
      return false
    end
  end

  return true
end

function Compressor.compress(source, options)
  options = options or {}
  local optimize = options.optimize ~= false

  local source_parse_ok = can_parse_with_ast(source)
  local source_compile_ok = can_compile(source)

  local candidates = {}
  if optimize and source_parse_ok then
    local optimized_source = optimize_source_with_ast(source)
    if optimized_source then
      candidates[#candidates + 1] = minify_source(optimized_source)
    end
  end
  candidates[#candidates + 1] = minify_source(source)

  for _, c in ipairs(candidates) do
    if validate_result(c, source_parse_ok, source_compile_ok) then
      return c
    end
  end

  return source
end

return Compressor
