local Lexer = require('src.lexer')
local Parser = require('src.parser')
local Linter = require('src.linter')

local Safety = {}

local function can_parse(source, options)
  options = options or {}
  local ok = pcall(function()
    local tokens = Lexer.new(source, { dialect = options.dialect }):tokenize()
    local parser = Parser.new(tokens, { dialect = options.dialect })
    parser:parse()
  end)
  return ok
end

local function can_compile(source)
  if type(load) == 'function' then
    local fn = load(source)
    return fn ~= nil
  end
  if type(loadstring) == 'function' then
    local fn = loadstring(source)
    return fn ~= nil
  end
  return true
end

local function safe_lint_summary(source, options)
  local ok, result = pcall(Linter.run, source, {
    dialect = options and options.dialect or nil,
    dynamic = false
  })
  if not ok or type(result) ~= 'table' or type(result.summary) ~= 'table' then
    return {
      total = 1,
      error = 1,
      warning = 0,
      info = 0,
      by_code = { ['lint-run-failed'] = 1 }
    }
  end
  return result.summary
end

function Safety.analyze_source(source, options)
  options = options or {}
  local text = source
  if type(text) ~= 'string' then
    text = tostring(text or '')
  end
  return {
    parse_ok = can_parse(text, options),
    compile_ok = can_compile(text),
    lint_summary = safe_lint_summary(text, options)
  }
end

function Safety.guard(mode, source, output, before_analysis, options)
  options = options or {}
  local input_text = source
  if type(input_text) ~= 'string' then
    input_text = tostring(input_text or '')
  end
  local output_text = output
  if type(output_text) ~= 'string' then
    output_text = tostring(output_text or '')
  end

  local before = before_analysis or Safety.analyze_source(input_text, options)
  local after = Safety.analyze_source(output_text, options)

  local fallback_applied = false
  local reason = nil
  local final_output = output_text

  if before.parse_ok and not after.parse_ok then
    fallback_applied = true
    reason = 'output is not parseable while input is parseable'
  elseif before.compile_ok and not after.compile_ok then
    fallback_applied = true
    reason = 'output is not compilable while input is compilable'
  end

  if fallback_applied then
    final_output = input_text
    after = before
  end

  return final_output, {
    type = 'safety-report',
    mode = tostring(mode or ''),
    dialect = tostring(options.dialect or 'auto'),
    generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
    before = before,
    after = after,
    fallback_applied = fallback_applied,
    fallback_reason = reason
  }
end

return Safety
