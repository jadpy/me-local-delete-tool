local LexerFull = require('src.lexer_full')

local Formatter = {}

local function split_lines_any(source)
  local lines = {}
  local s = source or ''
  local len = #s
  local start = 1
  local i = 1
  while i <= len do
    local ch = s:sub(i, i)
    if ch == '\r' or ch == '\n' then
      table.insert(lines, s:sub(start, i - 1))
      if ch == '\r' and s:sub(i + 1, i + 1) == '\n' then
        i = i + 1
      end
      start = i + 1
    end
    i = i + 1
  end
  if start <= len then
    table.insert(lines, s:sub(start, len))
  elseif #lines == 0 then
    table.insert(lines, '')
  end
  return lines
end

local function gcd(a, b)
  while b ~= 0 do
    local t = a % b
    a = b
    b = t
  end
  return a
end

local function detect_indent_str(source)
  local lines = split_lines_any(source or '')
  local tab_lines = 0
  local space_counts = {}

  for _, line in ipairs(lines) do
    if line:match('%S') then
      local ws = line:match('^(%s+)')
      if ws and #ws > 0 then
        if ws:find('\t', 1, true) then
          tab_lines = tab_lines + 1
        else
          local spaces = ws:match('^( +)$')
          if spaces and #spaces > 0 then
            table.insert(space_counts, #spaces)
          end
        end
      end
    end
  end

  if tab_lines > #space_counts and tab_lines > 0 then
    return '\t'
  end

  if #space_counts > 0 then
    local unit = space_counts[1]
    for i = 2, #space_counts do
      unit = gcd(unit, space_counts[i])
    end
    if unit < 1 then unit = 4 end
    if unit > 8 then unit = 4 end
    return string.rep(' ', unit)
  end

  return '    '
end

local function is_wordlike(tok)
  return tok.type == 'keyword' or tok.type == 'ident' or tok.type == 'number'
    or tok.type == 'string' or tok.type == 'long_string'
end

local keyword_space_after = {
  ['if'] = true, ['while'] = true, ['for'] = true, ['return'] = true,
  ['local'] = true, ['function'] = true, ['elseif'] = true, ['until'] = true,
  ['in'] = true, ['then'] = true, ['do'] = true, ['repeat'] = true, ['not'] = true
}

local keyword_binary = {
  ['and'] = true, ['or'] = true, ['in'] = true
}

local binary_ops = {
  ['='] = true, ['=='] = true, ['~='] = true, ['<'] = true, ['<='] = true,
  ['>'] = true, ['>='] = true, ['+'] = true, ['-'] = true, ['*'] = true,
  ['/'] = true, ['//'] = true, ['%'] = true, ['^'] = true, ['..'] = true,
  ['<<'] = true, ['>>'] = true, ['&'] = true, ['|'] = true, ['~'] = true,
  ['+='] = true, ['-='] = true, ['*='] = true, ['/='] = true, ['%='] = true,
  ['^='] = true, ['&='] = true, ['|='] = true, ['..='] = true
}

local merge_pairs = {
  ['--'] = true, ['=='] = true, ['~='] = true, ['<='] = true, ['>='] = true,
  ['<<'] = true, ['>>'] = true, ['//'] = true, ['..'] = true, ['...'] = true,
  ['::'] = true, ['+='] = true, ['-='] = true, ['*='] = true, ['/='] = true,
  ['%='] = true, ['^='] = true, ['&='] = true, ['|='] = true, ['..='] = true,
  ['->'] = true, ['=>'] = true, [':='] = true, ['&&'] = true, ['||'] = true
}

local function is_unary_context(prev)
  if not prev then return true end
  if prev.type == 'symbol' then
    local v = prev.value
    if v == '(' or v == '[' or v == '{' or v == ',' then return true end
    if binary_ops[v] then return true end
  elseif prev.type == 'keyword' then
    local kw = prev.value
    if kw == 'return' or kw == 'local' or kw == 'then' or kw == 'do'
      or kw == 'elseif' or kw == 'if' or kw == 'for' or kw == 'while'
      or kw == 'in' or kw == 'and' or kw == 'or' or kw == 'not'
      or kw == 'repeat' or kw == 'until' then
      return true
    end
  end
  return false
end

local function is_binary_symbol(tok, prev)
  if not tok or tok.type ~= 'symbol' then return false end
  local v = tok.value
  if v == '.' or v == ':' or v == '::' then return false end
  if v == '#' then return false end
  if v == '-' or v == '+' or v == '~' then
    if is_unary_context(prev) then return false end
  end
  return binary_ops[v] == true
end

local function needs_space(prev, nxt)
  if not prev or not nxt then return false end
  if prev._binary then return true end
  if prev.type == 'symbol' and prev.value == ',' then return true end
  if prev.type == 'symbol' and prev.value == ';' then
    if nxt.type == 'symbol' and nxt.value == '}' then return false end
    return true
  end
  if prev.type == 'symbol' and prev.value == '{' then
    if nxt.type == 'symbol' and nxt.value == '}' then return false end
    return true
  end
  if nxt.type == 'symbol' and nxt.value == '}' then
    if prev.type == 'symbol' and prev.value == '{' then return false end
    return true
  end
  if prev.type == 'keyword' and keyword_space_after[prev.value] then
    if prev.value == 'function' and nxt.type == 'symbol' and nxt.value == '(' then
    else
      return true
    end
  end
  if is_binary_symbol(nxt, prev) and not is_unary_context(prev) then
    return true
  end
  if is_wordlike(prev) and is_wordlike(nxt) then return true end
  if prev.type == 'number' and nxt.type == 'symbol' and nxt.value:sub(1, 1) == '.' then return true end
  if prev.type == 'symbol' and nxt.type == 'symbol' then
    if merge_pairs[prev.value .. nxt.value] then return true end
    if prev.value:sub(-1) == '.' and nxt.value:sub(1, 1) == '.' then return true end
  end
  if prev.type == 'symbol' and (prev.value == ')' or prev.value == ']' or prev.value == '}') and is_wordlike(nxt) then
    return true
  end
  if prev.type == 'symbol' and prev.value == '[' and (nxt.value == '[' or nxt.value:sub(1, 1) == '=') then return true end
  if prev.type == 'symbol' and prev.value == ']' and nxt.value == ']' then return true end
  if prev.type == 'symbol' and prev.value == ':' and nxt.value == ':' then return true end
  return false
end

local statement_starters = {
  ['local'] = true, ['function'] = true, ['if'] = true, ['for'] = true,
  ['while'] = true, ['repeat'] = true, ['return'] = true, ['break'] = true,
  ['goto'] = true, ['do'] = true, ['export'] = true, ['continue'] = true
}

local assignment_symbols = {
  ['='] = true, ['+='] = true, ['-='] = true, ['*='] = true, ['/='] = true,
  ['%='] = true, ['^='] = true, ['&='] = true, ['|='] = true, ['..='] = true
}

local function next_non_trivia(tokens, idx)
  local i = idx
  while i <= #tokens do
    local t = tokens[i]
    if t.type ~= 'newline' and t.type ~= 'comment' then
      return t, i
    end
    i = i + 1
  end
  return nil, i
end

local function prev_non_trivia(tokens, idx)
  local i = idx
  while i >= 1 do
    local t = tokens[i]
    if t.type ~= 'newline' and t.type ~= 'comment' then
      return t, i
    end
    i = i - 1
  end
  return nil, i
end

local function should_expand_call_table(tokens, open_idx)
  local prev_tok = prev_non_trivia(tokens, open_idx - 1)
  if not prev_tok or prev_tok.type ~= 'symbol' then
    return false
  end
  if prev_tok.value ~= '(' and prev_tok.value ~= ',' then
    return false
  end

  local depth = 0
  local top_sep = 0
  local has_named_field = false
  local has_callback_func = false
  local has_newline = false
  local i = open_idx

  while i <= #tokens do
    local t = tokens[i]
    if t.type == 'symbol' and t.value == '{' then
      depth = depth + 1
    elseif t.type == 'symbol' and t.value == '}' then
      depth = depth - 1
      if depth == 0 then
        break
      end
    elseif depth == 1 then
      if t.type == 'newline' then
        has_newline = true
      elseif t.type == 'keyword' and t.value == 'function' then
        has_callback_func = true
      elseif t.type == 'symbol' and (t.value == ',' or t.value == ';') then
        top_sep = top_sep + 1
      elseif t.type == 'symbol' and t.value == '=' then
        local ltok = prev_non_trivia(tokens, i - 1)
        if ltok and ltok.type == 'ident' then
          has_named_field = true
        end
      end
    end
    i = i + 1
  end

  if has_callback_func then return true end
  if has_named_field and top_sep >= 1 then return true end
  if has_named_field and has_newline then return true end
  return false
end

local function is_statement_ending_token(tok)
  if not tok then return false end
  if tok.type == 'ident' or tok.type == 'number' or tok.type == 'string' or tok.type == 'long_string' then
    return true
  end
  if tok.type == 'keyword' then
    local kw = tok.value
    return kw == 'nil' or kw == 'true' or kw == 'false' or kw == 'end' or kw == 'until' or kw == 'break' or kw == 'continue'
  end
  if tok.type == 'symbol' then
    local v = tok.value
    return v == ')' or v == ']' or v == '}'
  end
  return false
end

local function is_identifier_statement_start(tokens, idx)
  local tok = tokens[idx]
  if not tok or tok.type ~= 'ident' then return false end

  local nxt = next_non_trivia(tokens, idx + 1)
  if not nxt then
    return true
  end

  if nxt.type == 'symbol' then
    local v = nxt.value
    if v == '(' or v == '[' or v == '.' or v == ':' or v == ',' or assignment_symbols[v] then
      return true
    end
  end

  if nxt.type == 'string' or nxt.type == 'long_string' then
    return true
  end

  if nxt.type == 'symbol' and nxt.value == '{' then
    return true
  end

  return false
end

local function should_force_break_after_end(tokens, idx_after_end)
  local t1, i1 = next_non_trivia(tokens, idx_after_end)
  if not t1 or t1.type ~= 'symbol' then return false end
  if t1.value ~= '}' then return false end
  local t2 = next_non_trivia(tokens, i1 + 1)
  if not t2 or t2.type ~= 'symbol' then return false end
  return t2.value == ')' or t2.value == ']'
end

function Formatter.format(source, options)
  options = options or {}
  local lexer = LexerFull.new(source, { dialect = options.dialect })
  local tokens = lexer:tokenize()

  local out_lines = {}
  local line = {}
  local indent = 0
  local indent_str = detect_indent_str(source)
  local prev = nil
  local paren_depth, brace_depth, bracket_depth = 0, 0, 0
  local in_func_header = false
  local func_paren_depth = 0
  local seen_func_paren = false
  local pending_do = false
  local last_flushed_last_token = nil
  local table_stack = {}

  local function line_has_content()
    return #line > 0
  end

  local function flush_line(force)
    if line_has_content() or force then
      table.insert(out_lines, table.concat(line))
      last_flushed_last_token = prev
      line = {}
      prev = nil
    end
  end

  local function ensure_blank_line()
    if #out_lines == 0 then return end
    if out_lines[#out_lines] ~= '' then
      table.insert(out_lines, '')
    end
  end

  local function emit_indent()
    if #line == 0 then
      table.insert(line, string.rep(indent_str, indent))
    end
  end

  local function emit_token(tok, prev_tok)
    if tok.type == 'symbol' then
      tok._binary = is_binary_symbol(tok, prev_tok)
    elseif tok.type == 'keyword' then
      tok._binary = keyword_binary[tok.value] == true
    end
    emit_indent()
    if needs_space(prev, tok) then
      table.insert(line, ' ')
    end
    table.insert(line, tok.value)
    prev = tok
  end

  local function newline_before()
    if line_has_content() then
      flush_line(false)
    end
  end

  local function at_top_level()
    return brace_depth == 0 and bracket_depth == 0
  end

  local function maybe_add_top_level_gap(kw)
    if indent ~= 0 or not at_top_level() then return end
    if #out_lines == 0 then return end
    if out_lines[#out_lines] == '' then return end

    if kw == 'function' or kw == 'while' or kw == 'for' or kw == 'repeat' then
      ensure_blank_line()
      return
    end

    if last_flushed_last_token and last_flushed_last_token.type == 'keyword' then
      local last_kw = last_flushed_last_token.value
      if (last_kw == 'end' or last_kw == 'until') and (kw == 'local' or kw == 'function' or kw == 'while' or kw == 'for' or kw == 'if') then
        ensure_blank_line()
      end
    end
  end

  local function should_join_after_end(next_tok)
    if not next_tok or next_tok.type ~= 'symbol' then return false end
    local v = next_tok.value
    return v == ')' or v == ']' or v == '}' or v == ',' or v == '.' or v == ':'
  end

  local idx = 1
  while idx <= #tokens do
    local tok = tokens[idx]
    local next_tok = tokens[idx + 1]
    local next_sig_tok, next_sig_idx = next_non_trivia(tokens, idx + 1)
    local skip_depth_update = false
    if tok.type == 'newline' then
      if line_has_content() and not in_func_header then
        local break_on_newline = false
        if next_sig_tok then
          if next_sig_tok.type == 'keyword' then
            local kw = next_sig_tok.value
            if statement_starters[kw] or kw == 'end' or kw == 'elseif' or kw == 'else' or kw == 'until' then
              break_on_newline = true
            end
          elseif next_sig_tok.type == 'ident' then
            if is_statement_ending_token(prev) and is_identifier_statement_start(tokens, next_sig_idx) then
              break_on_newline = true
            end
          end
        end
        if break_on_newline then
          flush_line(false)
        end
      end
    elseif tok.type == 'comment' then
      newline_before()
      local lines = split_lines_any(tok.value)
      for _, cl in ipairs(lines) do
        emit_indent()
        table.insert(line, cl)
        flush_line(true)
      end
    else
      if tok.type == 'ident' and line_has_content()
        and not in_func_header
        and is_statement_ending_token(prev) and is_identifier_statement_start(tokens, idx) then
        flush_line(false)
      end

      if tok.type == 'keyword' then
        local kw = tok.value

        if kw == 'end' then
          newline_before()
          if indent > 0 then indent = indent - 1 end
          emit_token(tok, prev)
          if should_force_break_after_end(tokens, idx + 1) or not should_join_after_end(next_sig_tok or next_tok) then
            flush_line(true)
          end
          skip_depth_update = true
        elseif kw == 'until' then
          newline_before()
          if indent > 0 then indent = indent - 1 end
          emit_token(tok, prev)
          skip_depth_update = true
        elseif kw == 'else' then
          newline_before()
          if indent > 0 then indent = indent - 1 end
          emit_token(tok, prev)
          flush_line(true)
          indent = indent + 1
          skip_depth_update = true
        elseif kw == 'elseif' then
          newline_before()
          if indent > 0 then indent = indent - 1 end
          emit_token(tok, prev)
          skip_depth_update = true
        elseif kw == 'repeat' then
          newline_before()
          emit_token(tok, prev)
          flush_line(true)
          indent = indent + 1
          skip_depth_update = true
        else
          if kw == 'for' or kw == 'while' then
            pending_do = true
          end

          if statement_starters[kw] and line_has_content() and is_statement_ending_token(prev) then
            if kw == 'function' and prev then
              if prev.type == 'keyword' and prev.value == 'local' then
              elseif prev.type == 'symbol' and (prev.value == '(' or prev.value == '=' or prev.value == ',') then
              else
                flush_line(false)
              end
            elseif kw == 'do' and pending_do then
            else
              flush_line(false)
            end
          end

          if statement_starters[kw] and not line_has_content() and at_top_level() then
            maybe_add_top_level_gap(kw)
          end

          emit_token(tok, prev)

          if kw == 'then' then
            flush_line(true)
            indent = indent + 1
            skip_depth_update = true
          elseif kw == 'do' then
            flush_line(true)
            indent = indent + 1
            pending_do = false
            skip_depth_update = true
          elseif kw == 'function' then
            in_func_header = true
            func_paren_depth = 0
            seen_func_paren = false
          end
        end

      elseif tok.type == 'symbol' then
        if tok.value == '{' then
          local multiline = should_expand_call_table(tokens, idx)
          emit_token(tok, prev)
          table.insert(table_stack, {
            multiline = multiline,
            paren_level = paren_depth,
            bracket_level = bracket_depth,
            brace_level = brace_depth + 1
          })
          if multiline then
            flush_line(true)
            indent = indent + 1
          end
        elseif tok.value == '}' then
          local entry = table_stack[#table_stack]
          local closes_current = entry
            and brace_depth == entry.brace_level
            and paren_depth == entry.paren_level
            and bracket_depth == entry.bracket_level

          if closes_current and entry.multiline then
            newline_before()
            if indent > 0 then indent = indent - 1 end
            emit_token(tok, prev)
            table.remove(table_stack)
          else
            emit_token(tok, prev)
            if closes_current then
              table.remove(table_stack)
            end
          end
        elseif tok.value == ';' or tok.value == ',' then
          emit_token(tok, prev)
          local entry = table_stack[#table_stack]
          local in_multiline_table = entry
            and entry.multiline
            and brace_depth == entry.brace_level
            and paren_depth == entry.paren_level
            and bracket_depth == entry.bracket_level

          if in_multiline_table then
            flush_line(true)
          elseif tok.value == ';' and brace_depth == 0 and bracket_depth == 0 then
            flush_line(true)
            skip_depth_update = true
          end
        else
          emit_token(tok, prev)
        end
      else
        emit_token(tok, prev)
      end
    end

    if not skip_depth_update and tok.type == 'symbol' then
      local v = tok.value
      if v == '(' then
        paren_depth = paren_depth + 1
        if in_func_header then
          func_paren_depth = func_paren_depth + 1
          seen_func_paren = true
        end
      elseif v == ')' then
        if paren_depth > 0 then paren_depth = paren_depth - 1 end
        if in_func_header and func_paren_depth > 0 then
          func_paren_depth = func_paren_depth - 1
          if func_paren_depth == 0 and seen_func_paren then
            flush_line(true)
            indent = indent + 1
            in_func_header = false
          end
        end
      elseif v == '{' then
        brace_depth = brace_depth + 1
      elseif v == '}' then
        if brace_depth > 0 then brace_depth = brace_depth - 1 end
      elseif v == '[' then
        bracket_depth = bracket_depth + 1
      elseif v == ']' then
        if bracket_depth > 0 then bracket_depth = bracket_depth - 1 end
      end
    end

    idx = idx + 1
  end

  flush_line(false)
  return table.concat(out_lines, '\n')
end

return Formatter
