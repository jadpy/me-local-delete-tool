local Lexer = require('src.lexer')
local Parser = require('src.parser')
local Analyzer = require('src.analyzer')
local Transformer = require('src.transformer')
local CodeGen = require('src.codegen')
local TransformerLine = require('src.transformer_line')
local Formatter = require('src.formatter')
local Compressor = require('src.compressor')
local Nmbun = require('src.nmbun')
local Renamer = require('src.renamer')
local DeleteOut = require('src.deleteout')
local NoCode = require('src.nocode')
local Linter = require('src.linter')
local RRequire = require('src.rrequire')
local Safety = require('src.safety')
local Json = require('src.json')

local Preset = {}

local function read_file(filepath)
  local file = io.open(filepath, 'rb')
  if not file then
    error('Cannot open file: ' .. filepath)
  end
  local content = file:read('*a')
  file:close()
  return content
end

local function write_file(filepath, content)
  local file = io.open(filepath, 'wb')
  if not file then
    error('Cannot write file: ' .. filepath)
  end
  file:write(content)
  file:close()
end

local function ensure_dir(dirpath)
  os.execute('if not exist "' .. dirpath .. '" mkdir "' .. dirpath .. '"')
end

local function basename(filepath)
  return filepath:match('([^/\\]+)$') or filepath
end

local function step_label(idx, step)
  local name = tostring((step and step.name) or '')
  name = name:gsub('[^%w%._%-]', '_')
  if name == '' then
    return string.format('step%02d', idx)
  end
  return string.format('step%02d_%s', idx, name)
end

local function resolve_mode_name(mode_name, scope)
  if mode_name == 'functionlocal' then
    if scope == 'function' then
      return 'remove_function_local_function'
    elseif scope == 'global' then
      return 'remove_function_local_global'
    else
      return 'remove_function_local_all'
    end
  elseif mode_name == 'localcyt' then
    if scope == 'function' then
      return 'remove_local_string_function'
    elseif scope == 'global' then
      return 'remove_local_string_global'
    else
      return 'remove_local_string_all'
    end
  elseif mode_name == 'localnum' then
    if scope == 'function' then
      return 'remove_local_number_function'
    elseif scope == 'global' then
      return 'remove_local_number_global'
    else
      return 'remove_local_number_all'
    end
  elseif mode_name == 'localtur' then
    if scope == 'function' then
      return 'remove_local_boolean_function'
    elseif scope == 'global' then
      return 'remove_local_boolean_global'
    else
      return 'remove_local_boolean_all'
    end
  elseif mode_name == 'localkw' then
    if scope == 'function' then
      return 'remove_local_keyword_function'
    elseif scope == 'global' then
      return 'remove_local_keyword_global'
    else
      return 'remove_local_keyword_all'
    end
  elseif mode_name == 'localte' then
    if scope == 'function' then
      return 'remove_local_boolean_function'
    elseif scope == 'global' then
      return 'remove_local_boolean_global'
    end
    return nil, 'localte requires scope: function or global'
  elseif mode_name == 'localc' then
    if scope == 'function' then
      return 'remove_local_string_function'
    elseif scope == 'global' then
      return 'remove_local_string_global'
    end
    return nil, 'localc requires scope: function or global'
  elseif mode_name == 'localtabke' then
    if scope == 'function' then
      return 'remove_local_table_function'
    elseif scope == 'global' then
      return 'remove_local_table_global'
    else
      return 'remove_local_table_all'
    end
  elseif mode_name == 'outcode' then
    return 'outcode'
  elseif mode_name == 'deleteout' then
    return 'deleteout'
  elseif mode_name == 'nocode' then
    return 'nocode'
  elseif mode_name == 'fom' then
    return 'fom'
  elseif mode_name == 'coml' then
    return 'coml'
  elseif mode_name == 'nmbun' then
    return 'nmbun'
  elseif mode_name == 'rename' then
    return 'rename'
  elseif mode_name == 'lint' then
    return 'lint'
  elseif mode_name == 'rrequire' then
    return 'rrequire'
  end
  return nil, 'unsupported mode: ' .. tostring(mode_name)
end

local function process_source(source, source_path, mode, engine)
  if mode == 'fom' then
    return Formatter.format(source), { all_locals = {} }
  elseif mode == 'coml' then
    return Compressor.compress(source), { all_locals = {} }
  elseif mode == 'nmbun' then
    return Nmbun.run(source)
  elseif mode == 'rename' then
    return Renamer.rename(source)
  elseif mode == 'deleteout' then
    return DeleteOut.strip(source), { all_locals = {} }
  elseif mode == 'nocode' then
    return NoCode.clean(source)
  elseif mode == 'lint' then
    local result = Linter.run(source)
    return source, { all_locals = {} }, {
      report_data = {
        type = 'lint-report',
        file = source_path,
        generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        result = result
      },
      report_suffix = '.lint.json',
      lint_summary = result.summary
    }
  elseif mode == 'rrequire' then
    local result = RRequire.analyze(source_path)
    return source, { all_locals = {} }, {
      report_data = {
        type = 'rrequire-report',
        file = source_path,
        generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        result = result
      },
      report_suffix = '.rrequire.json',
      rrequire_summary = result.summary
    }
  end

  local lexer = Lexer.new(source)
  local tokens = lexer:tokenize()
  if engine == 'line' then
    local transformer = TransformerLine.new(source, tokens, { mode = mode })
    return transformer:apply(), { all_locals = {} }
  end
  local parser = Parser.new(tokens)
  local ast = parser:parse()
  local analyzer = Analyzer.new()
  analyzer:analyze(ast)
  local transformer = Transformer.new({ mode = mode })
  local transformed_ast = transformer:transform(ast)
  local codegen = CodeGen.new(source)
  local output_code = codegen:generate(transformed_ast)
  return output_code, analyzer
end

local function parse_preset(config_text, preset_path)
  local ok, config = pcall(Json.decode, config_text)
  if not ok then
    error('Invalid preset JSON in ' .. preset_path .. ': ' .. tostring(config))
  end
  if type(config) ~= 'table' then
    error('Preset root must be an object')
  end
  if type(config.steps) ~= 'table' then
    error('Preset must include "steps" array')
  end
  return config
end

function Preset.run(input_filepath, preset_filepath, default_engine)
  local preset_path = preset_filepath or 'preset.json'
  local preset_text = read_file(preset_path)
  local preset = parse_preset(preset_text, preset_path)
  local source = read_file(input_filepath)

  local filename = basename(input_filepath)
  local write_step_outputs = preset.write_step_outputs == true
  local stop_on_error = preset.stop_on_error ~= false
  local preset_engine = preset.engine
  local step_results = {}

  ensure_dir('output')
  local step_outputs_requested = write_step_outputs
  if not step_outputs_requested then
    for _, st in ipairs(preset.steps) do
      if type(st) == 'table' and st.write_output == true then
        step_outputs_requested = true
        break
      end
    end
  end
  if step_outputs_requested then
    ensure_dir('output/preset_steps')
  end

  local current_source = source
  local temp_current_path = 'output/.tmp_preset_current_' .. filename

  for idx, step in ipairs(preset.steps) do
    if type(step) ~= 'table' then
      step_results[#step_results + 1] = {
        index = idx,
        status = 'skipped',
        reason = 'step is not an object'
      }
    elseif step.enabled == false then
      step_results[#step_results + 1] = {
        index = idx,
        name = step.name,
        mode = step.mode,
        status = 'skipped',
        reason = 'disabled'
      }
    else
      local mode_name = step.mode
      local scope = step.scope
      local engine = step.engine or preset_engine or default_engine or 'line'
      local internal_mode, map_err = resolve_mode_name(mode_name, scope)
      if not internal_mode then
        local item = {
          index = idx,
          name = step.name,
          mode = mode_name,
          status = 'error',
          error = map_err
        }
        step_results[#step_results + 1] = item
        if stop_on_error then
          return current_source, { all_locals = {} }, {
            report_data = {
              type = 'preset-report',
              file = input_filepath,
              preset_file = preset_path,
              generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
              result = {
                status = 'failed',
                error = map_err,
                steps = step_results
              }
            },
            report_suffix = '.preset.json'
          }
        end
      else
        local started = os.clock()
        local step_before = Safety.analyze_source(current_source)
        local source_path_for_step = input_filepath
        if internal_mode == 'rrequire' then
          source_path_for_step = temp_current_path
          write_file(source_path_for_step, current_source)
        end

        local ok, out_code, analyzer, meta = pcall(
          process_source,
          current_source,
          source_path_for_step,
          internal_mode,
          engine
        )
        local elapsed_ms = math.floor((os.clock() - started) * 1000)
        if internal_mode == 'rrequire' then
          pcall(os.remove, temp_current_path)
        end

        if not ok then
          local item = {
            index = idx,
            name = step.name,
            mode = mode_name,
            scope = scope,
            engine = engine,
            status = 'error',
            duration_ms = elapsed_ms,
            error = tostring(out_code)
          }
          step_results[#step_results + 1] = item
          if stop_on_error then
            return current_source, { all_locals = {} }, {
              report_data = {
                type = 'preset-report',
                file = input_filepath,
                preset_file = preset_path,
                generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
                result = {
                  status = 'failed',
                  error = tostring(out_code),
                  steps = step_results
                }
              },
              report_suffix = '.preset.json'
            }
          end
        else
          local guarded_output, safety_report = Safety.guard(internal_mode, current_source, out_code or current_source, step_before)
          current_source = guarded_output
          if type(current_source) ~= 'string' then
            current_source = tostring(current_source or '')
          end
          local label = step_label(idx, step)
          if step_outputs_requested and (write_step_outputs or step.write_output == true) then
            local step_out = 'output/preset_steps/' .. filename .. '.' .. label .. '.lua'
            write_file(step_out, current_source)
            write_file('output/preset_steps/' .. filename .. '.' .. label .. '.safety.json', Json.encode(safety_report, true))
            if meta and meta.report_data then
              local suffix = meta.report_suffix or '.report.json'
              local report_body = Json.encode(meta.report_data, true)
              write_file('output/preset_steps/' .. filename .. '.' .. label .. suffix, report_body)
            end
          end
          step_results[#step_results + 1] = {
            index = idx,
            name = step.name,
            mode = mode_name,
            scope = scope,
            engine = engine,
            status = 'ok',
            duration_ms = elapsed_ms,
            output_bytes = #current_source,
            safety = {
              fallback_applied = safety_report.fallback_applied,
              fallback_reason = safety_report.fallback_reason
            }
          }
        end
      end
    end
  end

  return current_source, { all_locals = {} }, {
    report_data = {
      type = 'preset-report',
      file = input_filepath,
      preset_file = preset_path,
      generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
      result = {
        status = 'ok',
        steps = step_results
      }
    },
    report_suffix = '.preset.json'
  }
end

return Preset
