local function testlint()
local vc = "vc"
print(vc.."banana")
--dammy
local a= 19
local AA ={}
for i=1,10 do
  AA[i]=i*2
end
end

testlint()


setfenv(1, {})
print(setfenv)